import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type PointerEvent,
  type TouchEvent,
} from "react"
import { Icon } from "./Icon"

type ChatRoom = {
  id: string
  name: string
  message: string
  time: string
  waiting: boolean
  unread: number
  activity: number
}

type Message = {
  id: number
  role: "customer" | "ai" | "admin"
  text: string
  waiting?: boolean
  replyTo?: string
}

export type ChatSettings = {
  enabled: boolean
  operatingHoursEnabled: boolean
  startTime: string
  endTime: string
  fallbackMessage: string
}

export type QuickMenuItem = {
  id: string
  title: string
  description: string
}

export type LorebookEntry = {
  id: number
  keywords: string
  content: string
}

export type AnswerTopic = {
  id: number
  title: string
  introduction: string
  lorebooks: LorebookEntry[]
}

const CHAT_ROOMS: ChatRoom[] = [
  { id: "luxury", name: "홍길동", message: "혹시 사다리차 추가 비용이 발생하나요?", time: "방금", waiting: true, unread: 3, activity: 15 },
  { id: "luxury2", name: "김명품", message: "엘리베이터를 사용하지 못하는데요?", time: "2분 전", waiting: true, unread: 2, activity: 14 },
  { id: "park789", name: "박철수", message: "네, 알겠습니다. 내일 뵙겠습니다.", time: "오후 3:30", waiting: false, unread: 0, activity: 13 },
  { id: "choi00", name: "최지우", message: "에어컨 이전 설치도 같이 되나요?", time: "8분 전", waiting: true, unread: 4, activity: 12 },
  { id: "jung11", name: "정현우", message: "주소 변경은 어디서 하나요?", time: "어제", waiting: false, unread: 1, activity: 7 },
  { id: "kang22", name: "강민주", message: "포장 박스는 언제 가져다 주시나요?", time: "12분 전", waiting: true, unread: 2, activity: 11 },
  { id: "lee01", name: "이서준", message: "견적서 확인했습니다.", time: "오전 10:15", waiting: false, unread: 0, activity: 10 },
  { id: "yoon44", name: "윤아름", message: "귀중품은 따로 챙겨야 하나요?", time: "18분 전", waiting: true, unread: 1, activity: 9 },
  { id: "song90", name: "송지호", message: "이사 시작 시간은 몇 시인가요?", time: "어제", waiting: false, unread: 0, activity: 8 },
  { id: "han26", name: "한유진", message: "계약금 입금 완료했습니다.", time: "어제", waiting: false, unread: 0, activity: 6 },
  { id: "oh03", name: "오도현", message: "방문 견적 일정을 변경하고 싶어요.", time: "월요일", waiting: false, unread: 1, activity: 5 },
  { id: "moon08", name: "문지안", message: "침대 분해와 조립도 부탁드려요.", time: "월요일", waiting: false, unread: 0, activity: 4 },
  { id: "lim19", name: "임지수", message: "주차 공간 사진 보내드립니다.", time: "일요일", waiting: false, unread: 0, activity: 3 },
  { id: "kim24", name: "김도윤", message: "카드 결제가 가능한가요?", time: "토요일", waiting: false, unread: 0, activity: 2 },
  { id: "jimin31", name: "이지민", message: "친절한 안내 감사합니다.", time: "금요일", waiting: false, unread: 0, activity: 1 },
]

function roomMessages(room: ChatRoom, automatedMessage?: string): Message[] {
  const messages: Message[] = [
    {
      id: 1,
      role: "customer",
      text: "이번 주 금요일 이사 예정인데, 비가 오면 어떻게 되나요?",
    },
    {
      id: 2,
      role: "ai",
      text: "우천 시에도 기본적으로 이사는 진행되며, 가구와 짐은 방수 포장 후 안전하게 운반해 드립니다.",
    },
    {
      id: 3,
      role: "customer",
      text: room.message,
      waiting: room.waiting,
    },
  ]
  if (automatedMessage) {
    messages.push({
      id: 4,
      role: "ai",
      text: automatedMessage,
    })
  }
  return messages
}

function Toggle({
  checked,
  label,
  onChange,
}: {
  checked: boolean
  label: string
  onChange: (checked: boolean) => void
}) {
  return (
    <button
      aria-label={label}
      aria-pressed={checked}
      className={`relative h-7 w-12 shrink-0 rounded-full transition ${checked ? "bg-[#346538]" : "bg-[#d8ddd9]"}`}
      onClick={() => onChange(!checked)}
      type="button"
    >
      <span
        className={`absolute left-1 top-1 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${checked ? "translate-x-5" : "translate-x-0"}`}
      />
    </button>
  )
}

export function ChatManagementHome({
  onOpenAnswerSettings,
  onOpenEntrySettings,
  onOpenList,
  onOpenSettings,
  onOpenUnreadList,
  onOpenWaitingList,
}: {
  onOpenAnswerSettings: () => void
  onOpenEntrySettings: () => void
  onOpenList: () => void
  onOpenSettings: () => void
  onOpenUnreadList: () => void
  onOpenWaitingList: () => void
}) {
  const waitingCount = CHAT_ROOMS.filter((room) => room.waiting).length
  const unreadCount = CHAT_ROOMS.reduce((total, room) => total + room.unread, 0)

  return (
    <div className="h-full overflow-y-auto bg-[#f5f6f8] px-4 pb-6 pt-5">
      <div className="mb-5">
        <p className="text-[10px] font-bold tracking-[0.12em] text-[#879189]">
          CHAT SERVICE
        </p>
        <h1 className="mt-1 text-xl font-extrabold tracking-[-0.04em] text-[#253328]">
          채팅 관리
        </h1>
      </div>

      <section className="rounded-[22px] border border-[#f2dedb] bg-white p-5 shadow-[0_8px_24px_rgba(89,54,48,.08)]">
        <div className="flex items-center gap-2 text-[#a8433b]">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#fff0ee]">
            <Icon name="alert" size={18} />
          </span>
          <h2 className="text-sm font-extrabold text-[#3a403b]">
            실시간 상담 현황
          </h2>
        </div>
        <div className="py-6 text-center">
          <strong className="text-[42px] font-extrabold tracking-[-0.06em] text-[#c34f45]">
            {waitingCount}
            <span className="ml-1 text-lg tracking-normal">건</span>
          </strong>
          <p className="mt-2 text-xs font-semibold text-[#8a615d]">
            손님 대기 중 (상담원 전환 필요)
          </p>
        </div>
        <button
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#fff0ee] text-xs font-bold text-[#b64b42]"
          onClick={onOpenWaitingList}
          type="button"
        >
          대기 상담 바로 확인
          <Icon name="arrowRight" size={15} />
        </button>
      </section>

      <div className="mt-5 space-y-3">
        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)] transition active:scale-[.99]"
          onClick={onOpenUnreadList}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="chat" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">채팅 내역</strong>
            <span className="mt-1 block text-xs text-[#858d87]">
              모든 손님 대화 목록
            </span>
          </span>
          <span className="grid h-6 min-w-6 place-items-center rounded-full bg-[#346538] px-1.5 text-[10px] font-extrabold text-white">
            {unreadCount}
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>

        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)] transition active:scale-[.99]"
          onClick={onOpenSettings}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="settings" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">채팅 운영 설정</strong>
            <span className="mt-1 block text-xs leading-5 text-[#858d87]">
              챗봇 켜기/끄기, 운영 시간, 실패 시 대응
            </span>
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>

        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)] transition active:scale-[.99]"
          onClick={onOpenEntrySettings}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="menu" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">
              첫화면/퀵메뉴 설정
            </strong>
            <span className="mt-1 block text-xs leading-5 text-[#858d87]">
              인사말과 고객용 바로가기 메뉴 구성
            </span>
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>

        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)] transition active:scale-[.99]"
          onClick={onOpenAnswerSettings}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="robot" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">
              AI챗봇 대화 내역 관리
            </strong>
            <span className="mt-1 block text-xs leading-5 text-[#858d87]">
              주제별 AI 답변과 로어북 관리
            </span>
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>
      </div>
    </div>
  )
}

export function ChatEntrySettings({
  answerTopics,
  greeting,
  onChangeGreeting,
  onChangeQuickMenus,
  onClose,
  quickMenus,
}: {
  answerTopics: AnswerTopic[]
  greeting: string
  onChangeGreeting: (greeting: string) => void
  onChangeQuickMenus: (items: QuickMenuItem[]) => void
  onClose: () => void
  quickMenus: QuickMenuItem[]
}) {
  const [greetingOpen, setGreetingOpen] = useState(false)
  const [greetingDraft, setGreetingDraft] = useState(greeting)
  const [menuOpen, setMenuOpen] = useState(false)
  const [menuQuery, setMenuQuery] = useState("")
  const [deletingMenu, setDeletingMenu] = useState<QuickMenuItem | null>(null)
  const [previewOpen, setPreviewOpen] = useState(false)
  const candidates: QuickMenuItem[] = answerTopics.map((topic) => ({
    id: `topic-${topic.id}`,
    title: topic.title,
    description: topic.introduction,
  }))
  const filteredCandidates = candidates.filter((candidate) => {
    const query = menuQuery.trim().toLocaleLowerCase()
    return (
      !query ||
      `${candidate.title} ${candidate.description}`
        .toLocaleLowerCase()
        .includes(query)
    )
  })
  const gridItems = Array.from({ length: 4 }, (_, index) => quickMenus[index])

  const registerMenu = (item: QuickMenuItem) => {
    if (quickMenus.some((menu) => menu.id === item.id) || quickMenus.length >= 4)
      return
    onChangeQuickMenus([...quickMenus, item])
    setMenuOpen(false)
    setMenuQuery("")
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white px-4">
        <h1 className="text-base font-extrabold text-[#29322b]">
          첫화면/퀵메뉴 설정
        </h1>
        <button
          aria-label="첫화면 설정 닫기"
          className="absolute right-3 grid h-10 w-10 place-items-center rounded-full text-[#525c54] hover:bg-[#f2f4f2]"
          onClick={onClose}
          type="button"
        >
          <Icon name="x" size={20} />
        </button>
      </header>

      <div className="flex-1 space-y-4 overflow-y-auto p-4 pb-24">
        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
              <Icon name="chat" size={19} />
            </span>
            <h2 className="flex-1 text-sm font-extrabold text-[#303832]">인사말</h2>
            <button
              aria-label="인사말 수정"
              className="grid h-9 w-9 place-items-center rounded-xl bg-[#f3f5f3] text-[#346538]"
              onClick={() => {
                setGreetingDraft(greeting)
                setGreetingOpen(true)
              }}
              type="button"
            >
              <Icon name="edit" size={17} />
            </button>
          </div>
          <p className="mt-4 rounded-xl bg-[#f7f8f7] p-3 text-xs leading-5 text-[#59615b]">
            {greeting}
          </p>
        </section>

        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
              <Icon name="menu" size={19} />
            </span>
            <div className="flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">
                퀵메뉴 설정
              </h2>
              <p className="mt-0.5 text-[10px] text-[#929994]">최대 4개까지 등록</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {gridItems.map((item, index) =>
              item ? (
                <div
                  className="relative aspect-square rounded-2xl border border-[#dce6dc] bg-[#f1f6f1] p-3"
                  key={item.id}
                >
                  <button
                    aria-label={`${item.title} 삭제`}
                    className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-white text-[#a34d45] shadow-sm"
                    onClick={() => setDeletingMenu(item)}
                    type="button"
                  >
                    <Icon name="x" size={13} />
                  </button>
                  <div className="flex h-full flex-col items-center justify-center text-center">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-[#346538] shadow-sm">
                      <Icon name="chat" size={19} />
                    </span>
                    <strong className="mt-3 text-xs text-[#344037]">{item.title}</strong>
                  </div>
                </div>
              ) : (
                <button
                  className="aspect-square rounded-2xl border border-dashed border-[#bfc9c0] bg-[#fafbfa] text-xs font-bold text-[#718074] hover:bg-[#f3f6f3]"
                  key={`empty-${index}`}
                  onClick={() => setMenuOpen(true)}
                  type="button"
                >
                  <span className="mx-auto mb-2 grid h-8 w-8 place-items-center rounded-full bg-[#edf3ed] text-lg text-[#346538]">
                    +
                  </span>
                  등록
                </button>
              ),
            )}
          </div>
        </section>
      </div>

      <div className="absolute inset-x-0 bottom-0 border-t border-[#e5e9e5] bg-white/95 p-3 backdrop-blur-md">
        <button
          className="mx-auto block h-11 min-w-32 rounded-full bg-[#346538] px-8 text-sm font-bold text-white shadow-[0_6px_18px_rgba(52,101,56,.24)]"
          onClick={() => setPreviewOpen(true)}
          type="button"
        >
          미리 보기
        </button>
      </div>

      {greetingOpen && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[22px] bg-white p-5 shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <div className="relative flex items-center justify-center">
              <h2 className="text-base font-extrabold text-[#303832]">인사말 수정</h2>
              <button
                aria-label="인사말 수정 닫기"
                className="absolute right-0 grid h-8 w-8 place-items-center rounded-full hover:bg-[#f2f3f2]"
                onClick={() => setGreetingOpen(false)}
                type="button"
              >
                <Icon name="x" size={17} />
              </button>
            </div>
            <textarea
              className="mt-5 h-36 w-full resize-none rounded-2xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-6 text-[#303832] outline-none focus:border-[#89a18b]"
              onChange={(event) => setGreetingDraft(event.target.value)}
              value={greetingDraft}
            />
            <button
              className="mt-4 h-12 w-full rounded-xl bg-[#346538] text-sm font-extrabold text-white disabled:bg-[#bcc5bd]"
              disabled={!greetingDraft.trim()}
              onClick={() => {
                onChangeGreeting(greetingDraft.trim())
                setGreetingOpen(false)
              }}
              type="button"
            >
              등록
            </button>
          </div>
        </div>
      )}

      {menuOpen && (
        <div className="absolute inset-0 z-40 bg-[#f5f6f8]">
          <header className="relative flex h-14 items-center justify-center border-b border-[#e5e9e5] bg-white">
            <h2 className="text-base font-extrabold text-[#303832]">퀵메뉴 조회</h2>
            <button
              aria-label="퀵메뉴 조회 닫기"
              className="absolute right-3 grid h-10 w-10 place-items-center rounded-full"
              onClick={() => {
                setMenuOpen(false)
                setMenuQuery("")
              }}
              type="button"
            >
              <Icon name="x" size={19} />
            </button>
          </header>
          <div className="p-4">
            <label className="flex items-center gap-2 rounded-full bg-white px-4 py-3 shadow-[0_3px_12px_rgba(36,58,39,.05)]">
              <Icon className="text-[#8b928d]" name="search" size={17} />
              <input
                autoFocus
                className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#9ca29e]"
                onChange={(event) => setMenuQuery(event.target.value)}
                placeholder="검색어를 입력하세요"
                value={menuQuery}
              />
            </label>
            <p className="mb-2 mt-5 px-1 text-xs font-bold text-[#69716b]">
              AI챗봇 대화 내역
            </p>
            <div className="max-h-[calc(100vh-250px)] space-y-2 overflow-y-auto">
              {filteredCandidates.map((candidate) => {
                const registered = quickMenus.some((menu) => menu.id === candidate.id)
                return (
                  <button
                    className="flex w-full items-center gap-3 rounded-2xl bg-white p-4 text-left disabled:opacity-45"
                    disabled={registered || quickMenus.length >= 4}
                    key={candidate.id}
                    onClick={() => registerMenu(candidate)}
                    type="button"
                  >
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
                      <Icon name="chat" size={17} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <strong className="block text-sm text-[#333b35]">
                        {candidate.title}
                      </strong>
                      <span className="mt-1 block truncate text-xs text-[#8a918c]">
                        {candidate.description}
                      </span>
                    </span>
                    <span className="text-xs font-bold text-[#346538]">
                      {registered ? "등록됨" : "선택"}
                    </span>
                  </button>
                )
              })}
              {!filteredCandidates.length && (
                <p className="py-16 text-center text-sm text-[#858d87]">
                  검색 결과가 없습니다.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {deletingMenu && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[22px] bg-white p-5 text-center shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#fff0ee] text-[#b64b42]">
              <Icon name="trash" size={21} />
            </span>
            <h2 className="mt-4 text-base font-extrabold text-[#303832]">
              정말 삭제하시겠습니까?
            </h2>
            <p className="mt-2 text-xs text-[#8a918c]">
              삭제된 데이터는 복구할 수 없습니다.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                className="h-11 rounded-xl bg-[#f0f2f0] text-sm font-bold text-[#646c66]"
                onClick={() => setDeletingMenu(null)}
                type="button"
              >
                취소
              </button>
              <button
                className="h-11 rounded-xl bg-[#c65249] text-sm font-bold text-white"
                onClick={() => {
                  onChangeQuickMenus(
                    quickMenus.filter((menu) => menu.id !== deletingMenu.id),
                  )
                  setDeletingMenu(null)
                }}
                type="button"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {previewOpen && (
        <div className="absolute inset-0 z-40 bg-[#f3f6f2]">
          <header className="relative flex h-14 items-center justify-center border-b border-[#e0e5df] bg-white">
            <h2 className="text-base font-extrabold text-[#303832]">미리보기</h2>
            <button
              aria-label="미리보기 닫기"
              className="absolute right-3 grid h-10 w-10 place-items-center rounded-full"
              onClick={() => setPreviewOpen(false)}
              type="button"
            >
              <Icon name="x" size={19} />
            </button>
          </header>
          <div className="p-5 pt-7">
            <div className="mb-4 flex items-center gap-3 px-1">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-[#dce9d8] text-[#346538] shadow-[0_4px_12px_rgba(36,58,39,.12)]">
                <Icon name="robot" size={20} />
              </span>
              <strong className="block text-sm text-[#59615b]">명품 이사 도우미</strong>
            </div>
            <div className="rounded-[22px] bg-white p-3 shadow-[0_8px_24px_rgba(36,58,39,.08)]">
              <div className="p-2">
                <p className="whitespace-pre-line text-sm leading-7 text-[#38413a]">
                  {greeting}
                </p>
                <div className="mt-4 space-y-2">
                  {quickMenus.map((menu) => (
                    <button
                      className="h-14 w-full rounded-xl bg-[#f2f4f1] px-4 text-sm font-bold text-[#465048]"
                      key={menu.id}
                      type="button"
                    >
                      {menu.title}
                    </button>
                  ))}
                  <button className="h-14 w-full rounded-xl bg-[#fff5e8] px-4 text-sm font-bold text-[#ad6d32]" type="button">
                    상담사 연결
                  </button>
                </div>
                <p className="mt-4 text-right text-[10px] text-[#9aa09b]">
                  상담 운영시간　평일 09:00–18:00
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const EMPTY_LOREBOOK = (): LorebookEntry => ({
  id: Date.now() + Math.random(),
  keywords: "",
  content: "",
})

export function ChatAnswerSettings({
  onChangeTopics,
  onClose,
  topics,
}: {
  onChangeTopics: (topics: AnswerTopic[]) => void
  onClose: () => void
  topics: AnswerTopic[]
}) {
  const [query, setQuery] = useState("")
  const [expandedId, setExpandedId] = useState<number | null>(topics[0]?.id ?? null)
  const [editingTopic, setEditingTopic] = useState<AnswerTopic | null | "new">(null)
  const [draft, setDraft] = useState<AnswerTopic>({
    id: 0,
    title: "",
    introduction: "",
    lorebooks: [EMPTY_LOREBOOK()],
  })
  const [deletingTopic, setDeletingTopic] = useState<AnswerTopic | null>(null)
  const filteredTopics = topics.filter((topic) => {
    const normalized = query.trim().toLocaleLowerCase()
    return (
      !normalized ||
      `${topic.title} ${topic.introduction}`
        .toLocaleLowerCase()
        .includes(normalized)
    )
  })

  const openEditor = (topic?: AnswerTopic) => {
    if (topic) {
      setEditingTopic(topic)
      setDraft({
        ...topic,
        lorebooks: topic.lorebooks.map((entry) => ({ ...entry })),
      })
    } else {
      setEditingTopic("new")
      setDraft({
        id: Date.now(),
        title: "",
        introduction: "",
        lorebooks: [EMPTY_LOREBOOK()],
      })
    }
  }

  const saveTopic = () => {
    if (!draft.title.trim() || !draft.introduction.trim()) return
    const saved = {
      ...draft,
      title: draft.title.trim(),
      introduction: draft.introduction.trim(),
    }
    onChangeTopics(
      editingTopic === "new"
        ? [saved, ...topics]
        : topics.map((topic) => (topic.id === saved.id ? saved : topic)),
    )
    setExpandedId(saved.id)
    setEditingTopic(null)
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white">
        <h1 className="text-base font-extrabold text-[#29322b]">답변 설정 관리</h1>
        <button
          aria-label="답변 설정 닫기"
          className="absolute right-3 grid h-10 w-10 place-items-center rounded-full"
          onClick={onClose}
          type="button"
        >
          <Icon name="x" size={20} />
        </button>
      </header>
      <div className="flex items-center gap-2 p-4 pb-2">
        <label className="flex min-w-0 flex-1 items-center gap-2 rounded-full bg-white px-4 py-3 shadow-[0_3px_12px_rgba(36,58,39,.05)]">
          <Icon className="text-[#8b928d]" name="search" size={17} />
          <input
            className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#9ca29e]"
            onChange={(event) => setQuery(event.target.value)}
            placeholder="검색어를 입력하세요"
            value={query}
          />
        </label>
        <button
          className="h-11 shrink-0 rounded-full bg-[#346538] px-4 text-xs font-bold text-white"
          onClick={() => openEditor()}
          type="button"
        >
          + 등록
        </button>
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto p-4 pt-2">
        {filteredTopics.map((topic) => (
          <section
            className="overflow-hidden rounded-2xl border border-white bg-white shadow-[0_3px_12px_rgba(36,58,39,.05)]"
            key={topic.id}
          >
            <div
              aria-expanded={expandedId === topic.id}
              className="flex w-full items-center gap-2 p-4 text-left"
              onClick={() =>
                setExpandedId((current) => (current === topic.id ? null : topic.id))
              }
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault()
                  setExpandedId((current) =>
                    current === topic.id ? null : topic.id,
                  )
                }
              }}
              role="button"
              tabIndex={0}
            >
              <span className="min-w-0 flex-1">
                <strong className="block text-sm text-[#303832]">{topic.title}</strong>
                <span className="mt-1 block truncate text-xs text-[#8a918c]">
                  {topic.introduction}
                </span>
              </span>
              <button
                aria-label={`${topic.title} 수정`}
                className="grid h-8 w-8 place-items-center rounded-lg bg-[#f2f5f2] text-[#346538]"
                onClick={(event) => {
                  event.stopPropagation()
                  openEditor(topic)
                }}
                type="button"
              >
                <Icon name="edit" size={15} />
              </button>
              <button
                aria-label={`${topic.title} 삭제`}
                className="grid h-8 w-8 place-items-center rounded-lg bg-[#fff0ee] text-[#b64b42]"
                onClick={(event) => {
                  event.stopPropagation()
                  setDeletingTopic(topic)
                }}
                type="button"
              >
                <Icon name="trash" size={15} />
              </button>
            </div>
            {expandedId === topic.id && (
              <div className="border-t border-[#edf0ed] bg-[#fafbfa] px-4 py-3">
                {topic.lorebooks.map((entry) => (
                  <div className="mb-3 last:mb-0" key={entry.id}>
                    <div className="flex flex-wrap gap-1">
                      {entry.keywords.split("#").filter(Boolean).map((keyword) => (
                        <span
                          className="rounded-full bg-[#e9f1e9] px-2 py-1 text-[10px] font-bold text-[#346538]"
                          key={keyword}
                        >
                          #{keyword}
                        </span>
                      ))}
                    </div>
                    <p className="mt-2 text-xs leading-5 text-[#626a64]">
                      {entry.content}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>
        ))}
        {!filteredTopics.length && (
          <p className="py-16 text-center text-sm text-[#858d87]">
            검색 결과가 없습니다.
          </p>
        )}
      </div>

      {editingTopic && (
        <div className="absolute inset-0 z-40 flex flex-col bg-[#f5f6f8]">
          <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white">
            <h2 className="text-base font-extrabold text-[#303832]">
              {editingTopic === "new" ? "답변 등록" : "답변 수정"}
            </h2>
            <button
              aria-label="답변 편집 닫기"
              className="absolute right-3 grid h-10 w-10 place-items-center rounded-full"
              onClick={() => setEditingTopic(null)}
              type="button"
            >
              <Icon name="x" size={20} />
            </button>
          </header>
          <div className="flex-1 overflow-y-auto p-4">
            <section className="space-y-3 rounded-[18px] bg-white p-4">
              <input
                className="h-12 w-full rounded-xl border border-[#dfe4df] bg-[#f7f8f7] px-3 text-sm font-semibold outline-none focus:border-[#89a18b]"
                onChange={(event) =>
                  setDraft((current) => ({ ...current, title: event.target.value }))
                }
                placeholder="주제 제목을 입력하세요"
                value={draft.title}
              />
              <textarea
                className="h-24 w-full resize-none rounded-xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-5 outline-none focus:border-[#89a18b]"
                onChange={(event) =>
                  setDraft((current) => ({
                    ...current,
                    introduction: event.target.value,
                  }))
                }
                placeholder="주제 제목과 함께 보일 짧은 소개를 입력해주세요"
                value={draft.introduction}
              />
            </section>
            <div className="mb-3 mt-5 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-[#303832]">로어북</h3>
                <p className="mt-1 text-[10px] text-[#8a918c]">
                  키워드에 따라 AI에게 전달할 내용을 설정합니다
                </p>
              </div>
              <button
                className="rounded-xl bg-[#edf3ed] px-3 py-2 text-xs font-bold text-[#346538]"
                onClick={() =>
                  setDraft((current) => ({
                    ...current,
                    lorebooks: [...current.lorebooks, EMPTY_LOREBOOK()],
                  }))
                }
                type="button"
              >
                + 등록
              </button>
            </div>
            <div className="space-y-3">
              {draft.lorebooks.map((entry, index) => (
                <section className="relative rounded-[18px] bg-white p-4" key={entry.id}>
                  <div className="mb-3 flex items-center justify-between">
                    <strong className="text-xs text-[#59615b]">
                      로어북 {index + 1}
                    </strong>
                    <button
                      aria-label={`로어북 ${index + 1} 삭제`}
                      className="grid h-8 w-8 place-items-center rounded-lg bg-[#fff0ee] text-[#b64b42]"
                      onClick={() =>
                        setDraft((current) => ({
                          ...current,
                          lorebooks: current.lorebooks.filter(
                            (item) => item.id !== entry.id,
                          ),
                        }))
                      }
                      type="button"
                    >
                      <Icon name="trash" size={15} />
                    </button>
                  </div>
                  <label className="block">
                    <span className="mb-2 block text-[10px] leading-4 text-[#7e8680]">
                      키워드를 #으로 구분해 입력해주세요. 띄어쓰기 시 #이 자동 생성됩니다.
                    </span>
                    <input
                      className="h-11 w-full rounded-xl border border-[#dfe4df] bg-[#f7f8f7] px-3 text-sm outline-none focus:border-[#89a18b]"
                      onChange={(event) => {
                        const input = event.target
                        const raw = input.value
                        const prev = entry.keywords
                        const cursor = input.selectionStart ?? raw.length
                        // 모바일: 문자가 추가된 경우에만 공백→# 변환 (삭제 시는 변환 안 함)
                        if (raw.length > prev.length && raw[cursor - 1] === " ") {
                          const before = raw.slice(0, cursor - 1).trimEnd()
                          const after = raw.slice(cursor).trimStart()
                          const separator = before.endsWith("#") ? " " : " #"
                          const keywords = `${before}${separator}${after}`
                          setDraft((current) => ({
                            ...current,
                            lorebooks: current.lorebooks.map((item) =>
                              item.id === entry.id ? { ...item, keywords } : item,
                            ),
                          }))
                          requestAnimationFrame(() => {
                            const pos = before.length + separator.length
                            input.setSelectionRange(pos, pos)
                          })
                          return
                        }
                        const keywords = raw
                        setDraft((current) => ({
                          ...current,
                          lorebooks: current.lorebooks.map((item) =>
                            item.id === entry.id ? { ...item, keywords } : item,
                          ),
                        }))
                      }}
                      onKeyDown={(event) => {
                        if (event.key !== " ") return
                        event.preventDefault()
                        const input = event.currentTarget
                        const start = input.selectionStart ?? input.value.length
                        const end = input.selectionEnd ?? start
                        const before = input.value.slice(0, start).trimEnd()
                        const after = input.value.slice(end).trimStart()
                        const separator = before.endsWith("#") ? " " : " #"
                        const keywords = `${before}${separator}${after}`
                        setDraft((current) => ({
                          ...current,
                          lorebooks: current.lorebooks.map((item) =>
                            item.id === entry.id ? { ...item, keywords } : item,
                          ),
                        }))
                        requestAnimationFrame(() => {
                          const cursor = before.length + separator.length
                          input.setSelectionRange(cursor, cursor)
                        })
                      }}
                      placeholder="#견적 #비용 #가격"
                      value={entry.keywords}
                    />
                  </label>
                  <label className="mt-4 block">
                    <span className="mb-2 block text-[10px] leading-4 text-[#7e8680]">
                      키워드 언급 시 고객에게 전달할 내용을 입력해주세요. (글자 수 제한 없음)
                    </span>
                    <textarea
                      className="h-28 w-full resize-none rounded-xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-5 outline-none focus:border-[#89a18b]"
                      onChange={(event) => {
                        const content = event.target.value
                        setDraft((current) => ({
                          ...current,
                          lorebooks: current.lorebooks.map((item) =>
                            item.id === entry.id ? { ...item, content } : item,
                          ),
                        }))
                      }}
                      placeholder="고객에게 전달할 답변을 입력하세요"
                      value={entry.content}
                    />
                  </label>
                </section>
              ))}
            </div>
          </div>
          <div className="shrink-0 border-t border-[#e5e9e5] bg-white p-3">
            <button
              className="h-12 w-full rounded-xl bg-[#346538] text-sm font-extrabold text-white disabled:bg-[#bcc5bd]"
              disabled={!draft.title.trim() || !draft.introduction.trim()}
              onClick={saveTopic}
              type="button"
            >
              {editingTopic === "new" ? "등록" : "수정"}
            </button>
          </div>
        </div>
      )}

      {deletingTopic && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[22px] bg-white p-5 text-center shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#fff0ee] text-[#b64b42]">
              <Icon name="trash" size={21} />
            </span>
            <h2 className="mt-4 text-base font-extrabold text-[#303832]">
              정말 삭제하시겠습니까?
            </h2>
            <p className="mt-2 text-xs text-[#8a918c]">
              삭제된 데이터는 복구할 수 없습니다.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                className="h-11 rounded-xl bg-[#f0f2f0] text-sm font-bold text-[#646c66]"
                onClick={() => setDeletingTopic(null)}
                type="button"
              >
                취소
              </button>
              <button
                className="h-11 rounded-xl bg-[#c65249] text-sm font-bold text-white"
                onClick={() => {
                  onChangeTopics(
                    topics.filter((topic) => topic.id !== deletingTopic.id),
                  )
                  setDeletingTopic(null)
                }}
                type="button"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function toPickerValue(time: string) {
  const [hourText, minute] = time.split(":")
  const hour24 = Number(hourText)
  return {
    period: hour24 >= 12 ? "오후" : "오전",
    hour: String(hour24 % 12 || 12).padStart(2, "0"),
    minute,
  }
}

function fromPickerValue(period: string, hour: string, minute: string) {
  const hour12 = Number(hour)
  const hour24 =
    period === "오후" ? (hour12 % 12) + 12 : hour12 === 12 ? 0 : hour12
  return `${String(hour24).padStart(2, "0")}:${minute}`
}

export function ChatOperationsSettings({
  onClose,
  onChange,
  settings,
}: {
  onClose: () => void
  onChange: (settings: ChatSettings) => void
  settings: ChatSettings
}) {
  const [ruleOpen, setRuleOpen] = useState(false)
  const [ruleDraft, setRuleDraft] = useState(settings.fallbackMessage)
  const [timeOpen, setTimeOpen] = useState(false)
  const [timeTarget, setTimeTarget] = useState<"start" | "end">("start")
  const initialTime = toPickerValue(settings.startTime)
  const [period, setPeriod] = useState(initialTime.period)
  const [hour, setHour] = useState(initialTime.hour)
  const [minute, setMinute] = useState(initialTime.minute)

  const update = (partial: Partial<ChatSettings>) =>
    onChange({ ...settings, ...partial })

  const openTimePicker = (target: "start" | "end") => {
    const selected = toPickerValue(
      target === "start" ? settings.startTime : settings.endTime,
    )
    setTimeTarget(target)
    setPeriod(selected.period)
    setHour(selected.hour)
    setMinute(selected.minute)
    setTimeOpen(true)
  }

  const saveTime = () => {
    update({
      [timeTarget === "start" ? "startTime" : "endTime"]: fromPickerValue(
        period,
        hour,
        minute,
      ),
    })
    setTimeOpen(false)
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white px-4">
        <h1 className="text-base font-extrabold text-[#29322b]">
          채팅 운영 설정
        </h1>
        <button
          aria-label="운영 설정 닫기"
          className="absolute right-3 grid h-10 w-10 place-items-center rounded-full text-[#525c54] hover:bg-[#f2f4f2]"
          onClick={onClose}
          type="button"
        >
          <Icon name="x" size={20} />
        </button>
      </header>

      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
              <Icon name="robot" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">챗봇 가동</h2>
              <p className="mt-1 text-[11px] text-[#8a918c]">
                AI가 고객 문의에 자동으로 답변합니다
              </p>
            </div>
            <Toggle
              checked={settings.enabled}
              label="챗봇 가동"
              onChange={(enabled) => update({ enabled })}
            />
          </div>
        </section>

        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
              <Icon name="clock" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">운영 시간</h2>
              <p className="mt-1 text-[11px] text-[#8a918c]">
                관리자 응대 가능 시간을 설정합니다
              </p>
            </div>
            <Toggle
              checked={settings.operatingHoursEnabled}
              label="운영 시간 사용"
              onChange={(operatingHoursEnabled) =>
                update({ operatingHoursEnabled })
              }
            />
          </div>
          <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
            <button
              className="rounded-xl bg-[#f3f5f3] px-3 py-3 text-center text-sm font-extrabold text-[#346538] disabled:text-[#a7aea8]"
              disabled={!settings.operatingHoursEnabled}
              onClick={() => openTimePicker("start")}
              type="button"
            >
              {settings.startTime}
            </button>
            <span className="text-xs font-semibold text-[#9aa19b]">~</span>
            <button
              className="rounded-xl bg-[#f3f5f3] px-3 py-3 text-center text-sm font-extrabold text-[#346538] disabled:text-[#a7aea8]"
              disabled={!settings.operatingHoursEnabled}
              onClick={() => openTimePicker("end")}
              type="button"
            >
              {settings.endTime}
            </button>
          </div>
        </section>

        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#fff5e8] text-[#9d6c2f]">
              <Icon name="help" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">대응 규칙</h2>
              <p className="mt-1 truncate text-[11px] text-[#8a918c]">
                {settings.fallbackMessage}
              </p>
            </div>
            <button
              aria-label="대응 규칙 수정"
              className="grid h-10 w-10 place-items-center rounded-xl bg-[#f3f5f3] text-[#346538]"
              onClick={() => {
                setRuleDraft(settings.fallbackMessage)
                setRuleOpen(true)
              }}
              type="button"
            >
              <Icon name="edit" size={18} />
            </button>
          </div>
        </section>
      </div>

      {timeOpen && (
        <div className="absolute inset-0 z-40 flex items-end bg-[#1f2d21]/45 backdrop-blur-[2px]">
          <div className="w-full rounded-t-[24px] bg-white px-5 pb-6 pt-4 shadow-[0_-18px_50px_rgba(25,42,28,.22)]">
            <div className="flex items-center justify-between">
              <button
                className="px-2 py-2 text-sm font-semibold text-[#828a84]"
                onClick={() => setTimeOpen(false)}
                type="button"
              >
                취소
              </button>
              <h2 className="text-sm font-extrabold text-[#303832]">
                {timeTarget === "start" ? "시작 시간" : "종료 시간"}
              </h2>
              <button
                className="px-2 py-2 text-sm font-extrabold text-[#346538]"
                onClick={saveTime}
                type="button"
              >
                완료
              </button>
            </div>
            <div className="relative mt-4 grid grid-cols-3 gap-2 overflow-hidden rounded-2xl bg-[#f5f6f5] p-3">
              <div className="pointer-events-none absolute inset-x-3 top-1/2 h-11 -translate-y-1/2 rounded-xl border-y border-[#dfe4df] bg-white/70" />
              <select
                aria-label="오전 오후"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setPeriod(event.target.value)}
                size={3}
                value={period}
              >
                {["오전", "오후"].map((value) => <option key={value}>{value}</option>)}
              </select>
              <select
                aria-label="시"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setHour(event.target.value)}
                size={3}
                value={hour}
              >
                {Array.from({ length: 12 }, (_, index) => String(index + 1).padStart(2, "0")).map((value) => <option key={value} value={value}>{value}시</option>)}
              </select>
              <select
                aria-label="분"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setMinute(event.target.value)}
                size={3}
                value={minute}
              >
                {["00", "10", "20", "30", "40", "50"].map((value) => <option key={value} value={value}>{value}분</option>)}
              </select>
            </div>
            <p className="mt-3 text-center text-[10px] text-[#8d958f]">
              각 항목을 위아래로 스크롤해 시간을 맞춰 주세요.
            </p>
          </div>
        </div>
      )}

      {ruleOpen && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div
            aria-modal="true"
            className="w-full rounded-[22px] bg-white p-5 shadow-[0_20px_50px_rgba(25,42,28,.24)]"
            role="dialog"
          >
            <div className="relative flex items-center justify-center">
              <h2 className="text-base font-extrabold text-[#303832]">대응 규칙</h2>
              <button
                aria-label="대응 규칙 닫기"
                className="absolute right-0 grid h-8 w-8 place-items-center rounded-full hover:bg-[#f2f3f2]"
                onClick={() => setRuleOpen(false)}
                type="button"
              >
                <Icon name="x" size={17} />
              </button>
            </div>
            <label className="mt-5 block">
              <span className="mb-2 block text-xs font-bold text-[#4c554e]">
                안내 문구 <span className="text-[#c34f45]">*</span>
              </span>
              <textarea
                className="h-32 w-full resize-none rounded-2xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-6 text-[#303832] outline-none placeholder:text-[#9ca39d] focus:border-[#89a18b]"
                onChange={(event) => setRuleDraft(event.target.value)}
                placeholder="현재 상담원 연결이 지연되고 있습니다. 조금만 기다려주세요."
                value={ruleDraft}
              />
            </label>
            <button
              className="mt-4 h-12 w-full rounded-xl bg-[#346538] text-sm font-extrabold text-white disabled:bg-[#bcc5bd]"
              disabled={!ruleDraft.trim()}
              onClick={() => {
                update({ fallbackMessage: ruleDraft.trim() })
                setRuleOpen(false)
              }}
              type="button"
            >
              등록
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export function ChatList({
  onSelectChat,
  onBack,
  initialFilter = "all",
}: {
  onSelectChat: (id: string) => void
  onBack?: () => void
  initialFilter?: "all" | "waiting" | "unread"
}) {
  const [searchOpen, setSearchOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [sortModalOpen, setSortModalOpen] = useState(false)
  const [sortOrder, setSortOrder] = useState<"latest" | "unread">("latest")
  const [filter, setFilter] = useState<"all" | "waiting" | "unread">(initialFilter)
  const [query, setQuery] = useState("")
  const searchRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus()
  }, [searchOpen])

  const rooms = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase()
    return CHAT_ROOMS.filter((room) =>
      filter === "waiting" ? room.waiting : filter === "unread" ? room.unread > 0 : true,
    )
      .filter((room) =>
        !normalizedQuery ||
        `${room.name} ${room.id} ${room.message}`
          .toLocaleLowerCase()
          .includes(normalizedQuery),
      )
      .sort((a, b) =>
        sortOrder === "latest"
          ? b.activity - a.activity
          : b.unread - a.unread || b.activity - a.activity,
      )
  }, [filter, query, sortOrder])

  const selectFilter = (nextFilter: "all" | "waiting" | "unread") => {
    setFilter(nextFilter)
    setMenuOpen(false)
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-[#e8ece8] bg-white px-4">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              aria-label="채팅 관리로 돌아가기"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
              onClick={onBack}
              type="button"
            >
              <span className="rotate-180"><Icon name="arrowRight" size={20} /></span>
            </button>
          )}
          <h1 className="text-xl font-extrabold tracking-[-0.03em] text-[#346538]">
            채팅
          </h1>
        </div>
        <div className="flex items-center gap-1">
          <button
            aria-label="채팅 검색"
            className="grid h-10 w-10 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
            onClick={() => setSearchOpen(true)}
            type="button"
          >
            <Icon name="search" size={22} />
          </button>
          <div className="relative">
            <button
              aria-expanded={menuOpen}
              aria-label="채팅 목록 메뉴"
              className="grid h-10 w-10 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
              onClick={() => setMenuOpen((open) => !open)}
              type="button"
            >
              <Icon name="menu" size={22} />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-11 z-30 w-36 overflow-hidden rounded-xl border border-[#e2e7e2] bg-white p-1.5 shadow-[0_12px_32px_rgba(34,53,37,.16)]">
                <button
                  className={`w-full rounded-lg px-3 py-2.5 text-left text-sm font-semibold ${filter === "all" ? "bg-[#edf3ed] text-[#346538]" : "text-[#4d554f]"}`}
                  onClick={() => selectFilter("all")}
                  type="button"
                >
                  전체
                </button>
                <button
                  className={`w-full rounded-lg px-3 py-2.5 text-left text-sm font-semibold ${filter === "waiting" ? "bg-[#fff0ee] text-[#b34c43]" : "text-[#4d554f]"}`}
                  onClick={() => selectFilter("waiting")}
                  type="button"
                >
                  대기
                </button>
                <button
                  className={`w-full rounded-lg px-3 py-2.5 text-left text-sm font-semibold ${filter === "unread" ? "bg-[#edf3ed] text-[#346538]" : "text-[#4d554f]"}`}
                  onClick={() => selectFilter("unread")}
                  type="button"
                >
                  안 읽음
                </button>
                <div className="my-1 border-t border-[#edf0ed]" />
                <button
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm font-semibold text-[#4d554f] hover:bg-[#f5f6f5]"
                  onClick={() => {
                    setMenuOpen(false)
                    setSortModalOpen(true)
                  }}
                  type="button"
                >
                  정렬
                  <span className="text-xs text-[#8c948e]">
                    {sortOrder === "latest" ? "최신 순" : "안 읽은 순"}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {searchOpen && (
        <div className="flex shrink-0 items-center gap-2 border-b border-[#e8ece8] bg-white px-4 py-2.5">
          <div className="flex flex-1 items-center gap-2 rounded-full bg-[#f2f3f5] px-4 py-2.5">
            <Icon className="shrink-0 text-[#8b928d]" name="search" size={17} />
            <input
              aria-label="고객 ID 또는 이름 검색"
              className="min-w-0 flex-1 bg-transparent text-sm text-[#29302b] outline-none placeholder:text-[#9ca29e]"
              onChange={(event) => setQuery(event.target.value)}
              placeholder="ID 또는 이름을 입력하세요"
              ref={searchRef}
              type="search"
              value={query}
            />
            {query && (
              <span className="text-xs font-semibold text-[#718074]">
                {rooms.length}건
              </span>
            )}
          </div>
          <button
            aria-label="검색 닫기"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[#626a64] hover:bg-[#f2f3f5]"
            onClick={() => {
              setSearchOpen(false)
              setQuery("")
            }}
            type="button"
          >
            <Icon name="x" size={18} />
          </button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-4 pb-5 pt-3">
        <div className="mb-2 flex items-center justify-between px-1">
          <span className="text-xs font-semibold text-[#7c847e]">
            {filter === "waiting" ? "답변 대기" : filter === "unread" ? "안 읽은 채팅" : "전체 채팅"} {rooms.length}
          </span>
          <span className="text-xs text-[#9aa09b]">
            {sortOrder === "latest" ? "최신 순" : "안 읽은 순"}
          </span>
        </div>
        {rooms.map((room) => (
          <button
            className="mb-2 flex w-full items-center gap-3 rounded-2xl border border-white bg-white p-3.5 text-left shadow-[0_3px_12px_rgba(36,58,39,.05)] transition active:scale-[.99]"
            key={room.id}
            onClick={() => onSelectChat(room.id)}
            type="button"
          >
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#edf3ed] text-sm font-extrabold text-[#346538]">
              {room.name[0]}
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-1.5">
                <strong className="truncate text-sm text-[#29302b]">{room.name}</strong>
                <span className="truncate text-xs text-[#8e9590]">({room.id})</span>
              </span>
              <span className="mt-1 block truncate text-xs text-[#737b75]">
                {room.message}
              </span>
            </span>
            <span className="flex shrink-0 flex-col items-end gap-1.5">
              <span className="text-[10px] text-[#9aa09b]">{room.time}</span>
              {room.waiting && (
                <span className="rounded-full bg-[#fff0ee] px-2 py-1 text-[10px] font-bold text-[#bd5147]">
                  대기 중
                </span>
              )}
              {room.unread > 0 && (
                <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#346538] px-1 text-[10px] font-bold text-white">
                  {room.unread}
                </span>
              )}
            </span>
          </button>
        ))}
        {rooms.length === 0 && (
          <div className="grid place-items-center py-20 text-center">
            <span className="mb-3 grid h-12 w-12 place-items-center rounded-full bg-white text-[#9aa29c]">
              <Icon name="search" size={22} />
            </span>
            <p className="text-sm font-semibold text-[#656d67]">일치하는 채팅이 없습니다</p>
            <p className="mt-1 text-xs text-[#979d98]">이름 또는 ID를 다시 확인해 주세요.</p>
          </div>
        )}
      </div>

      {sortModalOpen && (
        <div
          aria-modal="true"
          className="absolute inset-0 z-40 grid place-items-center bg-[#1f2d21]/40 p-6 backdrop-blur-[2px]"
          role="dialog"
        >
          <div className="w-full rounded-[20px] bg-white p-5 shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold text-[#29302b]">채팅방 순서 정렬</h2>
              <button
                aria-label="정렬 창 닫기"
                className="grid h-8 w-8 place-items-center rounded-full hover:bg-[#f2f3f5]"
                onClick={() => setSortModalOpen(false)}
                type="button"
              >
                <Icon name="x" size={17} />
              </button>
            </div>
            <div className="mt-4 space-y-2">
              {([
                ["latest", "최신 순", "최근 메시지를 받은 채팅부터 표시"],
                ["unread", "안 읽은 순", "읽지 않은 메시지가 많은 채팅부터 표시"],
              ] as const).map(([value, label, description]) => (
                <label
                  className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3.5 ${sortOrder === value ? "border-[#9db39f] bg-[#f1f6f1]" : "border-[#e7eae7]"}`}
                  key={value}
                >
                  <input
                    checked={sortOrder === value}
                    className="accent-[#346538]"
                    name="chat-sort"
                    onChange={() => setSortOrder(value)}
                    type="radio"
                  />
                  <span>
                    <strong className="block text-sm text-[#303832]">{label}</strong>
                    <span className="mt-0.5 block text-xs text-[#8a918c]">{description}</span>
                  </span>
                </label>
              ))}
            </div>
            <button
              className="mt-5 h-11 w-full rounded-xl bg-[#346538] text-sm font-bold text-white"
              onClick={() => setSortModalOpen(false)}
              type="button"
            >
              적용
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export function ChatDetail({
  automatedMessage,
  backTo,
  chatId,
  onBack,
}: {
  automatedMessage?: string
  backTo?: string
  chatId: string
  onBack: () => void
}) {
  const room = CHAT_ROOMS.find((item) => item.id === chatId) ?? CHAT_ROOMS[0]
  const [messages, setMessages] = useState<Message[]>(() =>
    roomMessages(room, automatedMessage),
  )
  const [draft, setDraft] = useState("")
  const [replyingTo, setReplyingTo] = useState<Message | null>(null)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [hideAi, setHideAi] = useState(false)
  const [waitingOnly, setWaitingOnly] = useState(false)
  const searchRef = useRef<HTMLInputElement>(null)
  const messageAreaRef = useRef<HTMLDivElement>(null)
  const gestureStartX = useRef<number | null>(null)

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus()
  }, [searchOpen])

  useEffect(() => {
    messageAreaRef.current?.scrollTo({
      top: messageAreaRef.current.scrollHeight,
      behavior: "smooth",
    })
  }, [messages, replyingTo])

  const visibleMessages = messages.filter((message) => {
    if (hideAi && message.role === "ai") return false
    if (waitingOnly && !message.waiting) return false
    if (
      searchQuery.trim() &&
      !message.text.toLocaleLowerCase().includes(searchQuery.trim().toLocaleLowerCase())
    ) return false
    return true
  })

  const sendMessage = (event: FormEvent) => {
    event.preventDefault()
    const text = draft.trim()
    if (!text) return
    setMessages((current) => [
      ...current,
      {
        id: Date.now(),
        role: "admin",
        text,
        replyTo: replyingTo?.text,
      },
    ])
    setDraft("")
    setReplyingTo(null)
  }

  const finishSwipe = (message: Message, endX: number) => {
    if (
      gestureStartX.current !== null &&
      gestureStartX.current - endX > 45 &&
      message.role === "customer"
    ) {
      setReplyingTo(message)
    }
    gestureStartX.current = null
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-[#e8ece8] bg-white px-3">
        <div className="flex min-w-0 items-center gap-1">
          <button
            aria-label="채팅 목록으로 돌아가기"
            className="grid h-10 w-9 shrink-0 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
            onClick={onBack}
            type="button"
          >
            <span className="rotate-180"><Icon name="arrowRight" size={21} /></span>
          </button>
          {backTo === "chatManagement" && (
            <button
              aria-label="채팅 관리로 돌아가기"
              className="flex shrink-0 items-center gap-1 rounded-full bg-[#edf3ed] px-2.5 py-1.5 text-[10px] font-bold text-[#346538]"
              onClick={onBack}
              type="button"
            >
              <span className="rotate-180 leading-none"><Icon name="arrowRight" size={12} /></span>
              채팅 관리
            </button>
          )}
          <div className="min-w-0">
            <h1 className="truncate text-[15px] font-extrabold text-[#346538]">
              {room.name}<span className="font-semibold text-[#7d887f]">({room.id})</span>
            </h1>
          </div>
          {room.waiting && (
            <span className="ml-1 flex shrink-0 items-center gap-1 rounded-full bg-[#fff0ee] px-2 py-1 text-[9px] font-bold text-[#bd5147]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#d95c50]" />
              대기 중
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center">
          <button
            aria-label="대화 내용 검색"
            className="grid h-10 w-9 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
            onClick={() => setSearchOpen(true)}
            type="button"
          >
            <Icon name="search" size={20} />
          </button>
          <div className="relative">
            <button
              aria-expanded={settingsOpen}
              aria-label="대화 설정"
              className="grid h-10 w-9 place-items-center rounded-full text-[#3f4941] hover:bg-[#f2f5f2]"
              onClick={() => setSettingsOpen((open) => !open)}
              type="button"
            >
              <Icon name="menu" size={20} />
            </button>
            {settingsOpen && (
              <div className="absolute right-0 top-11 z-30 w-48 rounded-xl border border-[#e2e7e2] bg-white p-2 shadow-[0_12px_32px_rgba(34,53,37,.16)]">
                <button
                  aria-pressed={hideAi}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-xs font-semibold text-[#4d554f] hover:bg-[#f5f6f5]"
                  onClick={() => setHideAi((value) => !value)}
                  type="button"
                >
                  AI 대화 내역 숨기기
                  <span className={`grid h-5 w-5 place-items-center rounded-md ${hideAi ? "bg-[#346538] text-white" : "border border-[#d8ddd8]"}`}>
                    {hideAi && <Icon name="check" size={13} />}
                  </span>
                </button>
                <button
                  aria-pressed={waitingOnly}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-xs font-semibold text-[#4d554f] hover:bg-[#f5f6f5]"
                  onClick={() => setWaitingOnly((value) => !value)}
                  type="button"
                >
                  대기 답변만 보기
                  <span className={`grid h-5 w-5 place-items-center rounded-md ${waitingOnly ? "bg-[#346538] text-white" : "border border-[#d8ddd8]"}`}>
                    {waitingOnly && <Icon name="check" size={13} />}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {searchOpen && (
        <div className="flex shrink-0 items-center gap-2 border-b border-[#e8ece8] bg-white px-3 py-2.5">
          <div className="flex flex-1 items-center gap-2 rounded-full bg-[#f2f3f5] px-4 py-2.5">
            <Icon className="shrink-0 text-[#8b928d]" name="search" size={16} />
            <input
              aria-label="대화 내용 검색"
              className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#9ca29e]"
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="대화 내용을 검색하세요"
              ref={searchRef}
              type="search"
              value={searchQuery}
            />
            {searchQuery && <span className="text-xs text-[#718074]">{visibleMessages.length}건</span>}
          </div>
          <button
            aria-label="대화 검색 닫기"
            className="grid h-9 w-9 place-items-center rounded-full"
            onClick={() => {
              setSearchOpen(false)
              setSearchQuery("")
            }}
            type="button"
          >
            <Icon name="x" size={18} />
          </button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4" ref={messageAreaRef}>
        <div className="mb-5 text-center">
          <span className="rounded-full bg-[#e8ebe8] px-3 py-1.5 text-[10px] font-semibold text-[#7d857f]">
            오늘
          </span>
        </div>
        <div className="space-y-4">
          {visibleMessages.map((message) => {
            const isCustomer = message.role === "customer"
            return (
              <div
                className={`flex max-w-[84%] flex-col gap-1 ${isCustomer ? "items-start" : "ml-auto items-end"}`}
                key={message.id}
                onPointerDown={(event: PointerEvent<HTMLDivElement>) => {
                  gestureStartX.current = event.clientX
                }}
                onPointerUp={(event: PointerEvent<HTMLDivElement>) =>
                  finishSwipe(message, event.clientX)
                }
                onTouchStart={(event: TouchEvent<HTMLDivElement>) => {
                  gestureStartX.current = event.touches[0].clientX
                }}
                onTouchEnd={(event: TouchEvent<HTMLDivElement>) =>
                  finishSwipe(message, event.changedTouches[0].clientX)
                }
              >
                {!isCustomer && (
                  <span className={`text-[10px] font-bold ${message.role === "ai" ? "text-[#6c7d6e]" : "text-[#346538]"}`}>
                    {message.role === "ai" ? "AI" : "관리자"}
                  </span>
                )}
                <div
                  className={`rounded-2xl p-3 text-[13px] leading-5 shadow-sm ${
                    message.waiting
                      ? "border border-[#efc4bf] bg-[#fff0ee] text-[#a44038]"
                      : isCustomer
                        ? "rounded-tl-md bg-white text-[#343b36]"
                        : message.role === "ai"
                          ? "rounded-tr-md bg-[#e8efe8] text-[#355639]"
                          : "rounded-tr-md bg-[#346538] text-white"
                  }`}
                >
                  {message.replyTo && (
                    <span className="mb-2 block rounded-lg border-l-2 border-[#d8b65d] bg-white/20 px-2 py-1 text-[11px] opacity-90">
                      {message.replyTo}
                    </span>
                  )}
                  {message.text}
                </div>
                {message.waiting && (
                  <span className="flex items-center gap-1 text-[10px] font-semibold text-[#ba554c]">
                    답변 대기 · 왼쪽으로 밀어 답장
                  </span>
                )}
              </div>
            )
          })}
          {visibleMessages.length === 0 && (
            <div className="py-16 text-center">
              <p className="text-sm font-semibold text-[#656d67]">조회된 대화가 없습니다</p>
              <p className="mt-1 text-xs text-[#979d98]">검색어나 설정을 변경해 주세요.</p>
            </div>
          )}
        </div>
      </div>

      <form
        className="shrink-0 border-t border-[#e1e6e1] bg-white px-3 pb-3 pt-2 shadow-[0_-4px_16px_rgba(36,58,39,.06)]"
        onSubmit={sendMessage}
      >
        {replyingTo && (
          <div className="mb-2 flex items-center gap-2 rounded-xl border-l-4 border-[#d6b24e] bg-[#fff8df] px-3 py-2">
            <div className="min-w-0 flex-1">
              <span className="block text-[10px] font-bold text-[#8c732d]">답장할 메시지</span>
              <span className="block truncate text-xs text-[#6f633f]">{replyingTo.text}</span>
            </div>
            <button
              aria-label="답장 취소"
              className="grid h-7 w-7 place-items-center rounded-full text-[#7a704f]"
              onClick={() => setReplyingTo(null)}
              type="button"
            >
              <Icon name="x" size={15} />
            </button>
          </div>
        )}
        <div className="flex items-center gap-2 rounded-full bg-[#f2f3f5] py-1.5 pl-4 pr-1.5">
          <input
            aria-label="메시지 입력"
            className="min-w-0 flex-1 bg-transparent py-2 text-sm text-[#29302b] outline-none placeholder:text-[#9ca29e]"
            onChange={(event) => setDraft(event.target.value)}
            placeholder="메시지를 입력하세요"
            value={draft}
          />
          <button
            aria-label="메시지 전송"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#346538] text-white transition disabled:bg-[#b8c2b9]"
            disabled={!draft.trim()}
            type="submit"
          >
            <Icon name="send" size={17} />
          </button>
        </div>
      </form>
    </div>
  )
}
