import React, { useEffect, useMemo, useRef, useState } from "react"

const A = "/assets"

type Screen = "onboarding" | "home" | "login" | "phone-login" | "signup" | "terms" | "verify" | "welcome" | "reservation" | "move" | "quote" | "quote-success" | "chat" | "profile" | "personal" | "estimates" | "reservations" | "reviews" | "notifications" | "detail" | "estimate-detail"
type EstimateStatus = "none" | "waiting-approval" | "approved" | "confirmed"
type MoveTab = "booking" | "estimate" | "done"
type TestAccount = "kimMove" | "kimCode"
type SocialProvider = "kakao" | "naver" | "apple"
type RecognizedItem = {
  id: string
  name: string
  count: number
  baseCbm: number
  size: "소형" | "중형" | "대형"
  icon: string
  needsReview?: boolean
}

const protectedScreens = new Set<Screen>([
  "move",
  "quote",
  "quote-success",
  "chat",
  "profile",
  "personal",
  "estimates",
  "reservations",
  "reviews",
  "notifications",
  "detail",
])

type IconButtonProps = {
  label: string
  onClick: () => void
  children: React.ReactNode
  className?: string
  disabled?: boolean
}

function Action({
  label,
  onClick,
  children,
  className = "",
  disabled = false,
}: IconButtonProps) {
  return (
    <div
      aria-disabled={disabled}
      aria-label={label}
      className={`action ${className} ${disabled ? "is-disabled" : ""}`}
      onClick={() => !disabled && onClick()}
      onKeyDown={(event) => !disabled && event.key === "Enter" && onClick()}
      role="button"
      tabIndex={disabled ? -1 : 0}
    >
      {children}
    </div>
  )
}

function Back({ onClick }: { onClick: () => void }) {
  return (
    <Action className="back" label="뒤로 가기" onClick={onClick}>
      <img alt="" src={`${A}/4bbcf.svg`} />
    </Action>
  )
}

function Chevron({ light = false }: { light?: boolean }) {
  return (
    <img
      alt=""
      className={light ? "chevron chevron-light" : "chevron"}
      src={`${A}/ce2ac.svg`}
    />
  )
}

function BrandMark({ className = "" }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={`brand-mark ${className}`}
      viewBox="0 0 132 130"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="brand-mark-house"
        d="M54 5a18 18 0 0 1 24 0l44 38a29 29 0 0 1 10 22v42a23 23 0 0 1-23 23H23A23 23 0 0 1 0 107V65a29 29 0 0 1 10-22L54 5Z"
      />
      <path
        className="brand-mark-smile"
        d="M35 80c17 16 45 16 62 0"
      />
    </svg>
  )
}

function useDragScroll() {
  const ref = useRef<HTMLDivElement>(null)
  const dragState = useRef({
    active: false,
    pointerId: -1,
    startX: 0,
    startY: 0,
    scrollLeft: 0,
    scrollTop: 0,
  })
  const [isDragging, setIsDragging] = useState(false)

  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragState.current.active) return
    dragState.current.active = false
    setIsDragging(false)
    if (event.currentTarget.hasPointerCapture(dragState.current.pointerId)) {
      event.currentTarget.releasePointerCapture(dragState.current.pointerId)
    }
  }

  return {
    ref,
    isDragging,
    onPointerDown: (event: React.PointerEvent<HTMLDivElement>) => {
      if (event.button !== 0) return
      dragState.current = {
        active: true,
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        scrollLeft: event.currentTarget.scrollLeft,
        scrollTop: event.currentTarget.scrollTop,
      }
      event.currentTarget.setPointerCapture(event.pointerId)
      setIsDragging(true)
    },
    onPointerMove: (event: React.PointerEvent<HTMLDivElement>) => {
      if (!dragState.current.active) return
      event.preventDefault()
      event.currentTarget.scrollLeft =
        dragState.current.scrollLeft - (event.clientX - dragState.current.startX)
      event.currentTarget.scrollTop =
        dragState.current.scrollTop - (event.clientY - dragState.current.startY)
    },
    onPointerUp: endDrag,
    onPointerCancel: endDrag,
  }
}

function Field({
  label,
  placeholder,
  value,
  onValueChange,
  formatter,
  inputMode,
  showLabel = true,
}: {
  label: string
  placeholder: string
  value?: string
  onValueChange?: (value: string) => void
  formatter?: (value: string) => string
  inputMode?: "text" | "tel" | "numeric"
  showLabel?: boolean
}) {
  const fieldRef = useRef<HTMLDivElement>(null)
  const [internalValue, setInternalValue] = useState(value ?? "")
  const displayedValue = value ?? internalValue

  useEffect(() => {
    const field = fieldRef.current
    if (field && field.innerText !== displayedValue) {
      field.innerText = displayedValue
    }
  }, [displayedValue])

  return (
    <div className={showLabel ? "field-wrap" : "field-wrap no-label"}>
      {showLabel && <div className="field-label">{label}</div>}
      <div
        aria-label={label}
        className="field"
        contentEditable
        data-placeholder={placeholder}
        inputMode={inputMode}
        onInput={(event) => {
          const rawValue = event.currentTarget.innerText.replace(/\n/g, "")
          const nextValue = formatter ? formatter(rawValue) : rawValue
          if (nextValue !== rawValue) {
            event.currentTarget.innerText = nextValue
            const selection = window.getSelection()
            const range = document.createRange()
            range.selectNodeContents(event.currentTarget)
            range.collapse(false)
            selection?.removeAllRanges()
            selection?.addRange(range)
          }
          setInternalValue(nextValue)
          onValueChange?.(nextValue)
        }}
        ref={fieldRef}
        role="textbox"
        suppressContentEditableWarning
      />
    </div>
  )
}

const quickItems = [
  { label: "영상 견적", icon: `${A}/cd80e.svg`, next: "quote" as Screen },
  {
    label: "후기",
    icon: `${A}/review-illustration.svg`,
    next: "reviews" as Screen,
  },
  { label: "상담하기", icon: `${A}/bec52.svg`, next: "chat" as Screen },
]

function Header({
  go,
  mode,
  notificationCount = 0,
  onModeChange,
}: {
  go: (screen: Screen) => void
  mode: "standard" | "easy"
  notificationCount?: number
  onModeChange: (mode: "standard" | "easy") => void
}) {
  return (
    <div className="app-header">
      <div className="brand-row">
        <Action
          className="brand-home"
          label="홈으로 이동"
          onClick={() => go("home")}
        >
          <BrandMark className="header-brand-mark" />
        </Action>
      </div>
      <div className="header-actions">
        <div className="mode-toggle">
          <Action
            className={mode === "standard" ? "mode-active" : ""}
            label="일반 모드"
            onClick={() => onModeChange("standard")}
          >
            일반
          </Action>
          <Action
            className={mode === "easy" ? "mode-active" : ""}
            label="쉬운 모드"
            onClick={() => onModeChange("easy")}
          >
            쉬운
          </Action>
        </div>
        <Action
          className="notification-button"
          label={`알림${notificationCount ? ` ${notificationCount}개` : ""}`}
          onClick={() => go("notifications")}
        >
          <img alt="" className="bell" src={`${A}/0ebe3.svg`} />
          {notificationCount > 0 && (
            <span className="notification-dot" />
          )}
        </Action>
      </div>
    </div>
  )
}

function BottomNav({
  active,
  go,
  locked = false,
  easy = false,
}: {
  active: Screen
  go: (screen: Screen) => void
  locked?: boolean
  easy?: boolean
}) {
  const items = [
    {
      label: "홈",
      icon: "b676d.svg",
      inactiveIcon: "home-outline.svg",
      next: "home" as Screen,
    },
    {
      label: "내 이사",
      icon: "05dbf.svg",
      activeIcon: "move-active.svg",
      next: "move" as Screen,
    },
    {
      label: "이사견적",
      icon: "b046e.svg",
      next: "quote" as Screen,
      center: true,
    },
    {
      label: "채팅",
      icon: "d6860.svg",
      activeIcon: "chat-active.svg",
      next: "chat" as Screen,
    },
    {
      label: "더보기",
      icon: "4caa7.svg",
      activeIcon: "more-active.svg",
      next: "profile" as Screen,
    },
  ]

  return (
    <div className={easy ? "bottom-nav easy-bottom-nav" : "bottom-nav"}>
      {items.map((item) => (
        <Action
          className={`nav-item ${item.center ? "nav-center" : ""} ${
            active === item.next ? "selected" : ""
          } ${locked && item.next !== "home" ? "nav-locked" : ""}`}
          key={item.label}
          label={item.label}
          onClick={() => go(item.next)}
        >
          <div className={item.center ? "nav-icon-center" : "nav-icon"}>
            <img
              alt=""
              src={`${A}/${
                active === item.next
                  ? "activeIcon" in item
                    ? item.activeIcon
                    : item.icon
                  : "inactiveIcon" in item
                    ? item.inactiveIcon
                    : item.icon
              }`}
            />
          </div>
          <div>{item.label}</div>
        </Action>
      ))}
    </div>
  )
}

function EasyHome({
  estimateStatus,
  loggedIn,
  go,
  notificationCount,
  onModeChange,
  userName,
}: {
  estimateStatus: EstimateStatus
  loggedIn: boolean
  go: (screen: Screen) => void
  notificationCount: number
  onModeChange: (mode: "standard" | "easy") => void
  userName: string
}) {
  const [showEasyHelp, setShowEasyHelp] = useState(false)
  const [isReadingHelp, setIsReadingHelp] = useState(false)
  const services = [
    {
      title: "영상으로 견적 받기",
      icon: `${A}/cd80e.svg`,
      next: "quote" as Screen,
      accent: "camera",
    },
    {
      title: "내 이사 확인",
      icon: `${A}/91e58.svg`,
      next: "move" as Screen,
      accent: "move",
    },
    {
      title: "상담원에게 묻기",
      icon: `${A}/mover-assistant-3d.svg`,
      next: "chat" as Screen,
      accent: "help",
    },
    {
      title: "이사 후기 남기기",
      icon: `${A}/review-illustration.svg`,
      next: "reviews" as Screen,
      accent: "review",
    },
  ]

  const statusCopy =
    estimateStatus === "confirmed"
      ? {
          eyebrow: "예약 완료",
          title: "3월 18일 오전 10시에 이사해요",
          description: "원룸 · 일반포장",
          button: "예약 자세히 보기",
          next: "detail" as Screen,
          icon: `${A}/reservation-confirmed-illustration.svg`,
        }
      : estimateStatus === "approved"
        ? {
            eyebrow: "견적 도착",
            title: "이사 견적이 준비됐어요",
            description: "비용과 작업 내용을 확인해주세요.",
            button: "견적서 보기",
            next: "move" as Screen,
            icon: `${A}/estimate-approved-illustration.svg`,
          }
        : estimateStatus === "waiting-approval"
          ? {
              eyebrow: "관리자 확인 중",
              title: "견적 요청이 접수됐어요",
              description: "담당자 확인이 끝나면 견적 정보를 알려드려요.",
              button: "진행 상황 보기",
              next: "estimates" as Screen,
              icon: `${A}/estimate-requested-illustration.svg`,
            }
          : null
  return (
    <div className="screen home-screen easy-home">
      <Header
        go={go}
        mode="easy"
        notificationCount={loggedIn ? notificationCount : 0}
        onModeChange={onModeChange}
      />
      <main className="easy-home-content">
        <div className="easy-welcome">
          <strong>
            {loggedIn ? `${userName}님, 무엇을 도와드릴까요?` : "무엇을 도와드릴까요?"}
          </strong>
        </div>

        {!loggedIn ? (
          <div className="easy-login-card">
            <div>
              <strong>로그인하면 이사 준비가 더 쉬워져요</strong>
              <span>견적과 예약을 안전하게 보관해드려요.</span>
            </div>
            <Action className="easy-login-button" label="로그인" onClick={() => go("login")}>
              로그인하기
            </Action>
          </div>
        ) : statusCopy ? (
          <div className={`easy-status-card status-${estimateStatus}`}>
            <div className="easy-status-main">
              <div className="easy-status-illustration">
                <img alt="" src={statusCopy.icon} />
              </div>
              <div className="easy-status-heading">
                <span>{statusCopy.eyebrow}</span>
                <strong>{statusCopy.title}</strong>
                <small>{statusCopy.description}</small>
              </div>
            </div>
            <Action
              className="easy-status-button"
              label={statusCopy.button}
              onClick={() => go(statusCopy.next)}
            >
              {statusCopy.button}
              <Chevron light />
            </Action>
          </div>
        ) : loggedIn ? (
          <EstimateStartCard easy go={go} />
        ) : null}

        <div className="easy-menu-zone">
          <section className="easy-service-section">
            <div className="easy-section-title">자주 쓰는 메뉴</div>
            <div className="easy-service-grid">
              {services.map((service) => (
                <Action
                  className={`easy-service-card ${service.accent}`}
                  key={service.title}
                  label={service.title}
                  onClick={() => go(service.next)}
                >
                  <div className="easy-service-icon">
                    <img alt="" src={service.icon} />
                  </div>
                  <div className="easy-service-copy">
                    <strong>{service.title}</strong>
                  </div>
                </Action>
              ))}
            </div>
          </section>

          <Action
            className="easy-help-card"
            label="쉬운 화면 사용법 보기"
            onClick={() => setShowEasyHelp(true)}
          >
            <div className="easy-help-mark">?</div>
            <div>
              <strong>화면 사용법이 궁금하신가요?</strong>
              <span>쉬운 화면 안내를 확인해 보세요</span>
            </div>
            <Chevron />
          </Action>
        </div>
      </main>
      <BottomNav active="home" easy go={go} locked={!loggedIn} />
      {showEasyHelp && (
        <>
          <div
            className="easy-help-scrim"
            onClick={() => {
              window.speechSynthesis?.cancel()
              setIsReadingHelp(false)
              setShowEasyHelp(false)
            }}
          />
          <div aria-modal="true" className="easy-help-modal" role="dialog">
            <div className="easy-help-modal-head">
              <div className="easy-help-modal-icon">?</div>
              <div>
                <span>쉬운 화면 안내</span>
                <strong>화면은 이렇게 사용해요</strong>
              </div>
            </div>
            <div className="easy-help-steps">
              <div>
                <b>1</b>
                <span><strong>위쪽 알림 카드</strong>에서 지금 해야 할 일을 확인해요.</span>
              </div>
              <div>
                <b>2</b>
                <span><strong>자주 쓰는 메뉴</strong>에서 원하는 서비스를 선택해요.</span>
              </div>
              <div>
                <b>3</b>
                <span><strong>아래쪽 메뉴</strong>로 홈, 내 이사, 채팅 화면을 이동해요.</span>
              </div>
            </div>
            <Action
              className={isReadingHelp ? "easy-help-read active" : "easy-help-read"}
              label={isReadingHelp ? "음성 안내 중지" : "화면 사용법 음성으로 듣기"}
              onClick={() => {
                if (isReadingHelp) {
                  window.speechSynthesis?.cancel()
                  setIsReadingHelp(false)
                  return
                }
                const guide = new SpeechSynthesisUtterance(
                  "쉬운 화면 사용법을 안내해 드릴게요. 위쪽 알림 카드에서 지금 해야 할 일을 확인하세요. 자주 쓰는 메뉴에서 원하는 서비스를 선택하세요. 아래쪽 메뉴로 홈, 내 이사, 이사 견적, 채팅, 더보기 화면을 이동할 수 있어요.",
                )
                guide.lang = "ko-KR"
                guide.rate = 0.9
                guide.onend = () => setIsReadingHelp(false)
                setIsReadingHelp(true)
                window.speechSynthesis?.speak(guide)
              }}
            >
              {isReadingHelp ? "음성 안내 중지" : "사용법 음성으로 듣기"}
            </Action>
            <Action
              className="easy-help-modal-close"
              label="닫기"
              onClick={() => {
                window.speechSynthesis?.cancel()
                setIsReadingHelp(false)
                setShowEasyHelp(false)
              }}
            >
              닫기
            </Action>
          </div>
        </>
      )}
    </div>
  )
}

function QuickMenu({ go }: { go: (screen: Screen) => void }) {
  return (
    <section className="section">
      <div className="section-title">빠른 메뉴</div>
      <div className="quick-grid">
        {quickItems.map((item, index) => (
          <Action
            className={`quick-item quick-${index + 1}`}
            key={item.label}
            label={item.label}
            onClick={() => go(item.next)}
          >
            <div className="quick-icon">
              <img alt="" src={item.icon} />
            </div>
            <div>{item.label}</div>
          </Action>
        ))}
      </div>
    </section>
  )
}

function Review() {
  return (
    <section className="section review-section">
      <div className="section-title">실제 고객들의 칭찬후기</div>
      <div className="review-card">
        <div className="reviewer">
          <strong>김코드</strong>
          <span>이용 2회차 · 어제</span>
        </div>
        <div className="review-meta">
          <span>원룸(반포장)</span>
          <span>평점 <b>★★★★★</b></span>
        </div>
        <div className="review-copy">
          친절하게 응대해주시고, 주의사항이나 필요한 부분 꼼꼼히 체크해주셔서
          이사 잘 할 수 있었습니다.
        </div>
      </div>
      <div className="review-card">
        <div className="reviewer">
          <strong>박이사</strong>
          <span>이용 1회차 · 3일 전</span>
        </div>
        <div className="review-meta">
          <span>아파트(일반포장)</span>
          <span>평점 <b>★★★★★</b></span>
        </div>
        <div className="review-copy">
          영상 견적 서비스 덕분에 방문 없이 바로 가격을 받을 수 있어서 너무 편했어요.
          당일 기사님도 시간 약속 철저히 지켜주시고 물건 하나도 흠집 없이 옮겨주셨습니다.
        </div>
      </div>
      <div className="review-card">
        <div className="reviewer">
          <strong>이무브</strong>
          <span>이용 3회차 · 1주 전</span>
        </div>
        <div className="review-meta">
          <span>빌라(반포장)</span>
          <span>평점 <b>★★★★☆</b></span>
        </div>
        <div className="review-copy">
          가격 대비 정말 만족스러웠어요. 다음 이사도 명품익스프레스로 할 것 같습니다.
          앱이 직관적이어서 견적 받는 것도 금방 끝났어요.
        </div>
      </div>
    </section>
  )
}

function BookingCard({ go }: { go: (screen: Screen) => void }) {
  return (
    <div className="my-booking-card">
      {/* 그린 헤더 영역 */}
      <div className="my-booking-head">
        <div className="my-booking-top">
          <div className="my-booking-status-wrap">
            <span className="my-booking-badge">예약 완료</span>
            <span className="my-booking-type">원룸 · 일반포장</span>
          </div>
          <span className="my-booking-dday">D-30</span>
        </div>
        <div className="my-booking-date">
          <b>3월 18일 (수)</b>
          <span>오전 10:00</span>
        </div>
      </div>

      <div className="my-booking-body">
        <div className="my-booking-route">
          <div className="my-booking-place from">
            <small>출발</small>
            <strong>강남구</strong>
            <span>테헤란로 123, 301호</span>
          </div>
          <div className="my-booking-route-line" aria-hidden="true">
            <div className="my-booking-dot from" />
            <div className="my-booking-line" />
            <div className="my-booking-dot to" />
          </div>
          <div className="my-booking-place to">
            <small>도착</small>
            <strong>서초구</strong>
            <span>서초대로 456, 804호</span>
          </div>
        </div>
        <Action className="my-booking-detail-btn" label="예약 상세" onClick={() => go("detail")}>
          <span>예약 상세 보기</span>
          <Chevron />
        </Action>
      </div>
    </div>
  )
}

function EstimateStartCard({
  easy = false,
  go,
}: {
  easy?: boolean
  go: (screen: Screen) => void
}) {
  const [showGuide, setShowGuide] = useState(false)

  return (
    <>
      <div className={easy ? "estimate-start-card easy" : "estimate-start-card"}>
        <div className="estimate-start-main">
          <div className="estimate-start-illustration">
            <img alt="" src={`${A}/cd80e.svg`} />
          </div>
          <div>
            <span>{easy ? "이사 견적" : "첫 이사 견적"}</span>
            <strong>
              {easy ? "이사를 준비하고 계신가요?" : "첫 이사 견적을 시작해보세요"}
            </strong>
            <small>
              {easy
                ? "집 안을 영상으로 찍어 올리면 예상 이사 비용을 알려드려요."
                : "영상을 올리면 AI가 짐의 양과 예상 비용을 계산해요."}
            </small>
          </div>
        </div>
        {!easy && (
          <>
            <div className="estimate-start-flow" aria-label="영상 견적 진행 과정">
              {["영상 촬영", "AI 분석", "예상 견적"].map((label, index) => (
                <React.Fragment key={label}>
                  {index > 0 && <span>→</span>}
                  <div>
                    <b>{index + 1}</b>
                    <small>{label}</small>
                  </div>
                </React.Fragment>
              ))}
            </div>
            <div className="estimate-start-note">약 3분 · 견적 확인 전에는 비용이 발생하지 않아요</div>
          </>
        )}
        <Action
          className="estimate-start-button"
          label="영상 견적 시작"
          onClick={() => go("quote")}
        >
          {easy ? "영상 찍고 견적 받기" : "영상 견적 시작"}
        </Action>
        <Action
          className="estimate-guide-button"
          label="영상 촬영 방법 보기"
          onClick={() => setShowGuide(true)}
        >
          {easy ? "사용 방법 보기" : "촬영 방법 보기"}
        </Action>
      </div>
      {showGuide && (
        <>
          <div className="estimate-guide-scrim" onClick={() => setShowGuide(false)} />
          <div aria-modal="true" className="estimate-guide-modal" role="dialog">
            <div className="estimate-guide-head">
              <div className="estimate-guide-icon">
                <img alt="" src={`${A}/cd80e.svg`} />
              </div>
              <div>
                <span>영상 견적 촬영 안내</span>
                <strong>이렇게 촬영해 주세요</strong>
              </div>
            </div>
            <div className="estimate-guide-steps">
              {[
                "현관부터 방을 차례대로 촬영해요.",
                "큰 가구와 가전이 잘 보이게 촬영해요.",
                "빠진 공간이 없는지 확인하고 올려요.",
              ].map((copy, index) => (
                <div key={copy}>
                  <b>{index + 1}</b>
                  <span>{copy}</span>
                </div>
              ))}
            </div>
            <Action
              className="estimate-guide-start"
              label="영상 견적 시작하기"
              onClick={() => {
                setShowGuide(false)
                go("quote")
              }}
            >
              영상 견적 시작하기
            </Action>
            <Action
              className="estimate-guide-close"
              label="닫기"
              onClick={() => setShowGuide(false)}
            >
              닫기
            </Action>
          </div>
        </>
      )}
    </>
  )
}

function Home({
  estimateStatus,
  loggedIn,
  go,
  mode,
  notificationCount = 0,
  onModeChange,
  userName = "김무브",
}: {
  estimateStatus: EstimateStatus
  loggedIn: boolean
  go: (screen: Screen) => void
  mode: "standard" | "easy"
  notificationCount?: number
  onModeChange: (mode: "standard" | "easy") => void
  userName?: string
}) {
  if (mode === "easy") {
    return (
      <EasyHome
        estimateStatus={estimateStatus}
        go={go}
        loggedIn={loggedIn}
        notificationCount={notificationCount}
        onModeChange={onModeChange}
        userName={userName}
      />
    )
  }

  return (
    <div className="screen home-screen">
      <Header
        go={go}
        mode={mode}
        notificationCount={loggedIn ? notificationCount : 0}
        onModeChange={onModeChange}
      />
      <main className="home-content">
        {loggedIn ? (
          <>
            <div className="home-greeting">{userName}님</div>
            {estimateStatus === "confirmed" ? (
              <BookingCard go={go} />
            ) : estimateStatus === "approved" ? (
              <Action
                className="home-estimate-status ready"
                label="도착한 견적 확인"
                onClick={() => go("move")}
              >
                <div className="home-estimate-main">
                  <div className="home-estimate-visual">
                    <img alt="" src={`${A}/estimate-approved-illustration.svg`} />
                  </div>
                  <div className="home-estimate-copy">
                    <span>견적 도착</span>
                    <strong>이사 견적이 준비됐어요</strong>
                    <small>비용과 작업 내용을 확인해주세요.</small>
                  </div>
                </div>
                <div className="home-estimate-cta">
                  견적서 보기
                  <svg
                    aria-hidden="true"
                    fill="none"
                    height="16"
                    viewBox="0 0 16 16"
                    width="16"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="m6 3.5 4.5 4.5L6 12.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7" />
                  </svg>
                </div>
              </Action>
            ) : estimateStatus === "waiting-approval" ? (
              <Action
                className="home-estimate-status ready pending"
                label="견적 요청 상태 확인"
                onClick={() => go("estimates")}
              >
                <div className="home-estimate-main">
                  <div className="home-estimate-visual">
                    <img alt="" src={`${A}/estimate-requested-illustration.svg`} />
                  </div>
                  <div className="home-estimate-copy">
                    <span>관리자 확인 중</span>
                    <strong>견적 요청이 접수됐어요</strong>
                    <small>담당자 확인이 끝나면 견적 정보를 알려드려요.</small>
                  </div>
                </div>
                <div className="home-estimate-cta">
                  진행 상황 보기
                  <Chevron light />
                </div>
              </Action>
            ) : (
              <EstimateStartCard go={go} />
            )}
          </>
        ) : (
          <>
            <div className="login-hero">
              <div>
                로그인하고
                <br />더 많은 서비스를 이용해보세요
              </div>
              <Action
                className="primary"
                label="로그인"
                onClick={() => go("login")}
              >
                로그인
              </Action>
            </div>
            <Action
              className="promo"
              label="영상 견적 시작"
              onClick={() => go("quote")}
            >
              <div>
                <small>회원 혜택 ✦</small>
                <strong>영상 찍고 견적 받자</strong>
                <span>촬영부터 확인까지 간편하게</span>
              </div>
              <div className="promo-flow">
                <span>▣</span>
                <img alt="" src={`${A}/03a65.svg`} />
                <span>⇧</span>
                <img alt="" src={`${A}/2edc2.svg`} />
                <span>▤</span>
              </div>
            </Action>
          </>
        )}
        <QuickMenu go={go} />
        <Review />
      </main>
      <BottomNav active="home" go={go} locked={!loggedIn} />
    </div>
  )
}

function Onboarding({ go }: { go: (screen: Screen) => void }) {
  const slides = [
    {
      art: `${A}/bd644.png`,
      artClass: "onboarding-art onboarding-art-main",
      alt: "이삿짐을 배송하는 기사와 트럭",
      copy: (
        <>
          신속하지만 정확하게
          <br />
          신뢰있는 이사
        </>
      ),
    },
    {
      art: `${A}/moving-dolly-3d.svg`,
      artClass: "onboarding-art onboarding-art-service",
      alt: "가구를 안전하게 운반하는 이사 카트",
      copy: (
        <>
          짐부터 일정까지 꼼꼼하게
          <br />
          믿고 맡기는 이사 준비
        </>
      ),
    },
    {
      art: `${A}/cd80e.svg`,
      artClass: "onboarding-art onboarding-art-icon onboarding-art-video",
      alt: "영상 견적 카메라",
      copy: (
        <>
          영상만 찍으면 빠르게
          <br />
          AI가 분석하는 이사 견적
        </>
      ),
    },
  ]
  const [slide, setSlide] = useState(0)

  useEffect(() => {
    const timer = window.setInterval(() => {
      setSlide((current) => (current + 1) % slides.length)
    }, 3500)
    return () => window.clearInterval(timer)
  }, [slides.length])

  const current = slides[slide]

  return (
    <div className="screen onboarding">
      <div className="onboarding-main">
        <div className="onboarding-slide" key={current.art}>
          <img
            alt={current.alt}
            className={current.artClass}
            src={current.art}
          />
          <div className="onboarding-title">{current.copy}</div>
        </div>
        <div className="brand-name">명품익스프레스</div>
        <div className="pager">
          {slides.map((item, index) => (
            <Action
              className={
                index === slide ? "pager-dot pager-active" : "pager-dot"
              }
              key={item.art}
              label={`${index + 1}번째 온보딩 보기`}
              onClick={() => setSlide(index)}
            >
              <span />
            </Action>
          ))}
        </div>
      </div>
      <div className="onboarding-actions">
        <Action className="outline" label="로그인" onClick={() => go("login")}>
          로그인
        </Action>
        <Action
          className="primary"
          label="회원가입"
          onClick={() => go("signup")}
        >
          회원가입
        </Action>
      </div>
      <Action
        className="browse"
        label="로그인하지 않고 둘러보기"
        onClick={() => go("home")}
      >
        로그인하지 않고 둘러보기
      </Action>
    </div>
  )
}

function LoginSheet({
  background,
  go,
  onLogin,
  onDismiss,
}: {
  background: React.ReactNode
  go: (screen: Screen) => void
  onLogin: (account: TestAccount, provider: SocialProvider) => void
  onDismiss: () => void
}) {
  const dragStart = useRef<number | null>(null)
  const [dragY, setDragY] = useState(0)

  const finishDrag = (clientY: number) => {
    const distance =
      dragStart.current === null ? 0 : Math.max(0, clientY - dragStart.current)
    dragStart.current = null
    if (distance > 70) {
      onDismiss()
      return
    }
    setDragY(0)
  }

  return (
    <div className="screen login-scene">
      {background}
      <div className="scrim" onClick={onDismiss} />
      <div
        className="login-sheet"
        style={{ transform: `translateY(${dragY}px)` }}
      >
        <div
          aria-label="로그인 선택 화면 닫기"
          className="sheet-grabber"
          onPointerCancel={() => {
            dragStart.current = null
            setDragY(0)
          }}
          onPointerDown={(event) => {
            dragStart.current = event.clientY
            event.currentTarget.setPointerCapture(event.pointerId)
          }}
          onPointerMove={(event) => {
            if (dragStart.current !== null) {
              setDragY(Math.max(0, event.clientY - dragStart.current))
            }
          }}
          onPointerUp={(event) => finishDrag(event.clientY)}
          role="button"
          tabIndex={0}
        >
          <div className="sheet-handle" />
        </div>
        <div className="sheet-title">로그인 방법 선택</div>
        <div className="social-row">
          <Action
            className="social kakao"
            label="카카오 로그인"
            onClick={() => onLogin("kimCode", "kakao")}
          >
            <img alt="카카오" src={`${A}/2a814.svg`} />
          </Action>
          <Action
            className="social naver"
            label="네이버 로그인"
            onClick={() => onLogin("kimMove", "naver")}
          >
            <img alt="네이버" src={`${A}/4a055.svg`} />
          </Action>
          <Action
            className="social apple"
            label="애플 로그인"
            onClick={() => onLogin("kimMove", "apple")}
          >
            <img alt="애플" src={`${A}/38175.png`} />
          </Action>
        </div>
        <Action
          className="phone-button"
          label="휴대전화로 로그인"
          onClick={() => go("phone-login")}
        >
          <img alt="" src={`${A}/1513d.svg`} />
          <span>휴대전화로 로그인</span>
        </Action>
        <div className="account-help">
          계정이 기억나지 않나요?　<u>계정 찾기</u>
        </div>
      </div>
    </div>
  )
}

function PhoneLogin({
  go,
  onLogin,
}: {
  go: (screen: Screen) => void
  onLogin: (phone: string) => void
}) {
  const [phone, setPhone] = useState("")
  const [code, setCode] = useState("")
  const [sent, setSent] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const timerRef = useRef<number | null>(null)

  const phoneDigits = phone.replace(/\D/g, "")
  const phoneReady = phoneDigits.length === 11
  const loginReady = sent && code.length === 6

  const startTimer = () => {
    if (timerRef.current) window.clearInterval(timerRef.current)
    setSeconds(180)
    timerRef.current = window.setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          window.clearInterval(timerRef.current!)
          return 0
        }
        return s - 1
      })
    }, 1000)
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current)
    }
  }, [])

  const sendCode = () => {
    setSent(true)
    setCode("")
    startTimer()
  }

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0")
  const ss = String(seconds % 60).padStart(2, "0")

  return (
    <FormPage title="휴대전화 로그인" onBack={() => go("login")}>
      <div className="phone-login-group">
        <Field
          formatter={(input) => {
            const numbers = input.replace(/\D/g, "").slice(0, 11)
            if (numbers.length <= 3) return numbers
            if (numbers.length <= 7) {
              return `${numbers.slice(0, 3)}-${numbers.slice(3)}`
            }
            return `${numbers.slice(0, 3)}-${numbers.slice(3, 7)}-${numbers.slice(7)}`
          }}
          inputMode="tel"
          label="휴대폰 번호"
          onValueChange={setPhone}
          placeholder="휴대폰 번호를 입력해주세요"
          showLabel={false}
          value={phone}
        />
        <Action
          className={`phone-send-button ${phoneReady ? "active" : ""}`}
          disabled={!phoneReady}
          label="인증하기"
          onClick={sendCode}
        >
          {sent ? "재인증" : "인증하기"}
        </Action>
      </div>

      {sent && (
        <div className="phone-code-group">
          <div className="phone-code-label">
            <span>인증번호</span>
            <span className={`phone-timer ${seconds === 0 ? "expired" : ""}`}>
              {seconds === 0 ? "시간 만료" : `${mm}:${ss}`}
            </span>
          </div>
          <Field
            formatter={(input) => input.replace(/\D/g, "").slice(0, 6)}
            inputMode="numeric"
            label="인증번호"
            onValueChange={setCode}
            placeholder="인증번호 6자리"
            showLabel={false}
            value={code}
          />
          <div className="phone-code-hint">
            {phone} 으로 인증번호가 발송되었어요.
          </div>
        </div>
      )}

      <Action
        className="form-submit next-button"
        disabled={!loginReady}
        label="로그인"
        onClick={() => onLogin(phoneDigits)}
      >
        로그인
      </Action>
      <div className="form-links">
        <Action label="회원가입" onClick={() => go("signup")}>
          회원가입
        </Action>
        <span />
        <Action label="계정 찾기" onClick={() => go("verify")}>
          계정 찾기
        </Action>
      </div>
    </FormPage>
  )
}

function FormPage({
  title,
  onBack,
  children,
  extraClass,
}: {
  title?: string
  onBack: () => void
  children: React.ReactNode
  extraClass?: string
}) {
  return (
    <div className="screen form-page">
      <div className="form-head">
        <Back onClick={onBack} />
        {title && <div className="form-title">{title}</div>}
      </div>
      <div className={`form-content${extraClass ? ` ${extraClass}` : ""}`}>{children}</div>
    </div>
  )
}

function Signup({
  go,
  termsAccepted,
  name,
  phone,
  onNameChange,
  onPhoneChange,
}: {
  go: (screen: Screen) => void
  termsAccepted: boolean
  name: string
  phone: string
  onNameChange: (value: string) => void
  onPhoneChange: (value: string) => void
}) {
  const ready =
    name.trim().length > 0 &&
    phone.replace(/\D/g, "").length === 11 &&
    termsAccepted
  return (
    <FormPage onBack={() => go("onboarding")}>
      <div className="signup-copy">
        본인인증을 위해
        <br />
        이름과 전화번호를 입력해주세요.
      </div>
      <Field
        label="이름"
        placeholder="이름을 입력해주세요."
        onValueChange={onNameChange}
        value={name}
      />
      <Field
        formatter={(input) => {
          const numbers = input.replace(/\D/g, "").slice(0, 11)
          if (numbers.length <= 3) return numbers
          if (numbers.length <= 7) {
            return `${numbers.slice(0, 3)}-${numbers.slice(3)}`
          }
          return `${numbers.slice(0, 3)}-${numbers.slice(3, 7)}-${numbers.slice(7)}`
        }}
        inputMode="tel"
        label="휴대폰 번호"
        placeholder="휴대폰 번호를 입력해주세요."
        onValueChange={onPhoneChange}
        value={phone}
      />
      <div className="signup-bottom">
        <div className="terms-row">
          <span className={termsAccepted ? "terms-checked" : ""}>
            {termsAccepted ? "✓" : ""}
          </span>
          <u>본인인증을 위한 개인정보 수집</u>
          <Action
            className="terms-arrow"
            label="개인정보 수집 내용 보기"
            onClick={() => go("terms")}
          >
            <img alt="" src={`${A}/ce2ac.svg`} />
          </Action>
        </div>
        <Action
          className="form-submit next-button"
          disabled={!ready}
          label="다음"
          onClick={() => go("verify")}
        >
          다음
        </Action>
      </div>
    </FormPage>
  )
}

function Terms({
  go,
  onAccept,
}: {
  go: (screen: Screen) => void
  onAccept: () => void
}) {
  const contentRef = useRef<HTMLDivElement>(null)
  const [readToEnd, setReadToEnd] = useState(false)

  useEffect(() => {
    const content = contentRef.current
    if (content && content.scrollHeight <= content.clientHeight + 1) {
      setReadToEnd(true)
    }
  }, [])

  return (
    <FormPage title="개인정보 수집 안내" onBack={() => go("signup")}>
      <div
        className="terms-content designed-scroll"
        onScroll={(event) => {
          const target = event.currentTarget
          if (
            target.scrollTop + target.clientHeight >=
            target.scrollHeight - 12
          ) {
            setReadToEnd(true)
          }
        }}
        ref={contentRef}
      >
        <div className="terms-heading">
          본인인증을 위한 개인정보 수집 및 이용
        </div>
        <p>
          명품익스프레스는 회원가입과 본인인증을 위해 아래와 같이 개인정보를
          수집하고 이용합니다.
        </p>
        <div className="terms-block">
          <strong>수집하는 개인정보 항목</strong>
          <p>이름, 휴대폰 번호, 본인인증 결과값</p>
        </div>
        <div className="terms-block">
          <strong>개인정보의 수집 및 이용 목적</strong>
          <p>회원 식별, 본인인증, 서비스 가입 및 고객 상담</p>
        </div>
        <div className="terms-block">
          <strong>보유 및 이용 기간</strong>
          <p>
            회원 탈퇴 시까지 보관하며, 관계 법령에 따라 보존할 필요가 있는 경우
            해당 기간 동안 보관합니다.
          </p>
        </div>
        <div className="terms-notice">
          개인정보 수집 및 이용에 동의하지 않을 수 있으나, 동의하지 않을 경우
          회원가입과 본인인증을 진행할 수 없습니다.
        </div>
      </div>
      <Action
        className="terms-accept primary"
        disabled={!readToEnd}
        label={
          readToEnd ? "내용을 확인했어요" : "아래로 내려 내용을 확인해주세요"
        }
        onClick={onAccept}
      >
        {readToEnd ? "내용을 확인했어요" : "아래로 내려 내용을 확인해주세요"}
      </Action>
    </FormPage>
  )
}

function Verify({ go, name }: { go: (screen: Screen) => void; name?: string }) {
  const [digits, setDigits] = useState(["", "", "", "", "", ""])
  const [seconds, setSeconds] = useState(180)
  const timerRef = useRef<number | null>(null)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    timerRef.current = window.setInterval(() => {
      setSeconds((s) => (s > 0 ? s - 1 : 0))
    }, 1000)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [])

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0")
  const ss = String(seconds % 60).padStart(2, "0")
  const code = digits.join("")

  const handleDigit = (i: number, val: string) => {
    const d = val.replace(/\D/g, "").slice(-1)
    const next = [...digits]
    next[i] = d
    setDigits(next)
    if (d && i < 5) inputRefs.current[i + 1]?.focus()
  }

  const handleKey = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !digits[i] && i > 0) {
      inputRefs.current[i - 1]?.focus()
    }
  }

  const handlePaste = (e: React.ClipboardEvent) => {
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6)
    if (!pasted) return
    e.preventDefault()
    const next = Array.from({ length: 6 }, (_, i) => pasted[i] ?? "")
    setDigits(next)
    inputRefs.current[Math.min(pasted.length, 5)]?.focus()
  }

  return (
    <FormPage extraClass="verify-page" onBack={() => go("signup")}>
      <div className="signup-copy">
        {name ? `${name}님,` : ""}
        {name ? <br /> : null}
        인증번호를 입력해 주세요
      </div>
      <div className="verify-help">
        인증번호 문자 메시지가 <b>010</b>으로 발송되었습니다.
      </div>
      <div className="otp-row" onPaste={handlePaste}>
        {digits.map((d, i) => (
          <input
            className={`otp-box${d ? " otp-filled" : ""}`}
            inputMode="numeric"
            key={i}
            maxLength={1}
            onChange={(e) => handleDigit(i, e.target.value)}
            onFocus={(e) => e.target.select()}
            onKeyDown={(e) => handleKey(i, e)}
            ref={(el) => { inputRefs.current[i] = el }}
            type="text"
            value={d}
          />
        ))}
      </div>
      <div className="otp-meta">
        <span className={`otp-timer${seconds === 0 ? " expired" : ""}`}>
          {seconds === 0 ? "시간 만료" : `${mm}:${ss}`}
        </span>
        <Action className="otp-resend" label="재발송" onClick={() => { setSeconds(180); setDigits(["","","","","",""]); inputRefs.current[0]?.focus() }}>
          재발송
        </Action>
      </div>
      <Action
        className={`form-submit verify-submit ${code.length === 6 ? "primary" : "next-button is-disabled"}`}
        disabled={code.length !== 6}
        label="인증 완료"
        onClick={() => go("welcome")}
      >
        인증 완료
      </Action>
    </FormPage>
  )
}

function Welcome({ onStart, name }: { onStart: () => void; name?: string }) {
  const particles = [
    "6514c.svg",
    "6a3f5.svg",
    "a82d3.svg",
    "04e05.svg",
    "b2424.svg",
    "dca9e.svg",
    "e0c5f.svg",
    "48dcd.svg",
    "1429b.svg",
    "97ffe.svg",
    "63c36.svg",
  ]

  return (
    <div className="screen welcome">
      <div className="welcome-stage">
        <img
          alt="달리는 상자 캐릭터"
          className="welcome-box"
          src={`${A}/415ab.png`}
        />
        {particles.map((particle, index) => (
          <img
            alt=""
            className={`welcome-particle particle-${index + 1}`}
            key={particle}
            src={`${A}/${particle}`}
          />
        ))}
      </div>
      <div className="welcome-copy">{name || "무브"}님, 환영합니다</div>
      <Action className="welcome-button" label="시작하기" onClick={onStart}>
        시작하기
      </Action>
    </div>
  )
}

function QuoteSuccess({
  go,
  mode,
}: {
  go: (screen: Screen) => void
  mode: "standard" | "easy"
}) {
  const [isReading, setIsReading] = useState(false)

  useEffect(() => {
    return () => window.speechSynthesis?.cancel()
  }, [])

  const successArt = (
    <svg
      aria-hidden="true"
      className="quote-success-art"
      viewBox="0 0 180 150"
    >
      <ellipse className="quote-success-art-shadow" cx="88" cy="135" rx="58" ry="8" />
      <path className="quote-success-art-side" d="m88 50 47 22v48l-47 17Z" />
      <path className="quote-success-art-front" d="m41 72 47-22v87l-47-17Z" />
      <path className="quote-success-art-top" d="m41 72 47 22 47-22-47-22Z" />
      <path className="quote-success-art-tape" d="m72 58 47 22v17l-12 5V86L60 64Z" />
      <circle className="quote-success-art-badge" cx="132" cy="45" r="24" />
      <path className="quote-success-art-check" d="m121 45 8 8 15-17" />
    </svg>
  )

  if (mode === "easy") {
    return (
      <div className="screen easy-quote-success">
        <div className="easy-success-utility">
          <Action
            className={isReading ? "easy-voice-guide active" : "easy-voice-guide"}
            label={isReading ? "음성 안내 중지" : "완료 화면 음성으로 듣기"}
            onClick={() => {
              if (isReading) {
                window.speechSynthesis?.cancel()
                setIsReading(false)
                return
              }
              const guide = new SpeechSynthesisUtterance(
                "이사 요청을 잘 보냈어요. 명품익스프레스 담당자가 이사 내용을 확인합니다. 견적이 준비되면 알림으로 알려드릴게요.",
              )
              guide.lang = "ko-KR"
              guide.rate = 0.88
              guide.onend = () => setIsReading(false)
              setIsReading(true)
              window.speechSynthesis?.speak(guide)
            }}
          >
            <svg aria-hidden="true" fill="none" height="24" viewBox="0 0 24 24" width="24">
              <path d="M5 10v4h3l4 3V7L8 10H5Z" fill="currentColor" />
              <path d="M15 9.5c.7.6 1 1.4 1 2.5s-.3 1.9-1 2.5M17.5 7c1.3 1.3 2 3 2 5s-.7 3.7-2 5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.7" />
            </svg>
            <strong>{isReading ? "음성 안내 중" : "음성으로 듣기"}</strong>
            {isReading && <span>끄기</span>}
          </Action>
        </div>
        <div className="easy-quote-success-content">
          <div className="easy-quote-success-main">
            <div className="easy-quote-success-art">{successArt}</div>
            <strong>이사 요청을 잘 보냈어요</strong>
            <div className="easy-quote-success-guide">
              <div className="easy-success-guide-row">
                <b>1</b>
                <span>담당자가 이사 내용을 확인해요</span>
              </div>
              <div className="easy-success-guide-row">
                <b>2</b>
                <span>견적이 준비되면 알려드려요</span>
              </div>
            </div>
          </div>
        </div>
        <div className="easy-quote-success-actions">
          <Action className="easy-success-primary" label="요청 내역 확인하기" onClick={() => go("move")}>
            요청 내역 확인하기
          </Action>
          <Action className="easy-success-home" label="홈으로 돌아가기" onClick={() => go("home")}>
            홈으로 돌아가기
          </Action>
        </div>
      </div>
    )
  }

  return (
    <div className="screen quote-success">
      <section className="quote-success-main">
        {successArt}
        <strong>이사 요청을 보냈어요</strong>
        <div className="quote-success-flow">
          <span className="is-current">요청 접수</span>
          <i />
          <span>담당자 확인</span>
          <i />
          <span>견적 안내</span>
        </div>
      </section>
      <div className="quote-success-actions">
        <Action className="quote-success-primary" label="요청 내역 보기" onClick={() => go("move")}>
          요청 내역 보기
        </Action>
        <Action className="quote-success-home" label="홈으로 이동" onClick={() => go("home")}>
          홈으로
        </Action>
      </div>
    </div>
  )
}

const MOCK_ADDRESSES = [
  { road: "서울 강남구 테헤란로 123", jibun: "강남구 역삼동 123-45" },
  { road: "서울 강남구 테헤란로 152", jibun: "강남구 역삼동 678-9" },
  { road: "서울 강남구 강남대로 396", jibun: "강남구 역삼동 831-2" },
  { road: "서울 서초구 서초대로 456", jibun: "서초구 서초동 456-78" },
  { road: "서울 서초구 반포대로 201", jibun: "서초구 반포동 201-3" },
  { road: "서울 송파구 올림픽로 300", jibun: "송파구 방이동 300-1" },
  { road: "서울 마포구 합정로 100", jibun: "마포구 합정동 100-22" },
  { road: "서울 용산구 이태원로 200", jibun: "용산구 이태원동 200-5" },
  { road: "서울 성동구 왕십리로 50", jibun: "성동구 성수동 50-11" },
  { road: "서울 영등포구 여의대로 24", jibun: "영등포구 여의도동 24-3" },
  { road: "경기 성남시 분당구 판교역로 235", jibun: "성남시 삼평동 235-6" },
  { road: "경기 수원시 영통구 광교중앙로 145", jibun: "수원시 이의동 145-2" },
]

function AddressInput({ label, onComplete, onAddressLabel }: { label: string; onComplete?: (done: boolean) => void; onAddressLabel?: (addr: string) => void }) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<typeof MOCK_ADDRESSES>([])
  const [selected, setSelected] = useState<(typeof MOCK_ADDRESSES)[0] | null>(null)
  const [detail, setDetail] = useState("")
  const [showResults, setShowResults] = useState(false)

  const search = () => {
    const q = query.trim()
    if (!q) return
    const filtered = MOCK_ADDRESSES.filter(
      (a) => a.road.includes(q) || a.jibun.includes(q),
    )
    setResults(filtered.length ? filtered : [])
    setShowResults(true)
  }

  const pick = (addr: (typeof MOCK_ADDRESSES)[0]) => {
    setSelected(addr)
    setShowResults(false)
    setQuery(addr.road)
    onComplete?.(true)
    onAddressLabel?.(addr.road)
  }

  const reset = () => {
    setSelected(null)
    setDetail("")
    setQuery("")
    setResults([])
    setShowResults(false)
    onComplete?.(false)
    onAddressLabel?.("")
  }

  return (
    <div className="addr-wrap">
      <div className="addr-label">{label}</div>
      {selected ? (
        <div className="addr-selected">
          <div className="addr-selected-road">{selected.road}</div>
          <div className="addr-selected-jibun">{selected.jibun}</div>
          <Action className="addr-reset" label="주소 다시 검색" onClick={reset}>
            변경
          </Action>
        </div>
      ) : (
        <div className="addr-search-row">
          <input
            aria-label={`${label} 주소 검색`}
            className="addr-input"
            onChange={(e) => {
              setQuery(e.target.value)
              setShowResults(false)
            }}
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), search())}
            placeholder="도로명 또는 지번 주소 입력"
            type="text"
            value={query}
          />
          <Action className="addr-search-btn" label="검색" onClick={search}>
            검색
          </Action>
        </div>
      )}
      {showResults && (
        <div className="addr-results designed-scroll">
          {results.length === 0 ? (
            <div className="addr-no-result">검색 결과가 없어요. 다른 주소로 검색해보세요.</div>
          ) : (
            results.map((addr) => (
              <Action
                className="addr-result-item"
                key={addr.road}
                label={addr.road}
                onClick={() => pick(addr)}
              >
                <div className="addr-result-road">{addr.road}</div>
                <div className="addr-result-jibun">{addr.jibun}</div>
              </Action>
            ))
          )}
        </div>
      )}
      {selected && (
        <div className="addr-detail-wrap">
          <div
            aria-label="상세주소"
            className="addr-detail-input"
            contentEditable
            data-placeholder="상세주소 입력 (동, 호수 등)"
            onInput={(e) => setDetail(e.currentTarget.innerText.replace(/\n/g, ""))}
            role="textbox"
            suppressContentEditableWarning
          />
          {detail.trim().length === 0 && (
            <div className="addr-detail-hint">예) 101동 202호, 2층</div>
          )}
        </div>
      )}
    </div>
  )
}

const quoteSteps = [
  {
    title: "집 안을 촬영한 영상을 올려주세요",
    subtitle: "AI가 가구와 짐을 찾아 부피를 계산해요.",
    type: "upload",
  },
  {
    title: "AI가 영상을 분석하고 있어요",
    subtitle: "촬영한 영상을 바탕으로 짐의 종류와 부피를 확인합니다.",
    type: "analysis",
  },
  {
    title: "이사 정보를 알려주세요",
    subtitle: "주거 형태와 이사 방식을 선택해주세요.",
    type: "options",
  },
  {
    title: "출발지와 도착지는 어디인가요?",
    subtitle: "정확한 주소를 입력해주세요.",
    type: "address",
  },
  {
    title: "이사 날짜를 선택해주세요",
    subtitle: "정확한 견적을 위해 가능한 일정을 알려주세요.",
    type: "calendar",
  },
  {
    title: "예상 견적을 확인해주세요",
    subtitle: "영상 분석과 입력 정보를 바탕으로 계산했어요.",
    type: "summary",
  },
]

const recognizedItemOptions = [
  { name: "냉장고", icon: "item-fridge.svg", baseCbm: 1.8 },
  { name: "침대", icon: "item-bed.svg", baseCbm: 2.4 },
  { name: "소파", icon: "item-sofa.svg", baseCbm: 2.1 },
  { name: "이사박스", icon: "item-box.svg", baseCbm: 0.3 },
  { name: "세탁기", icon: "item-washer.svg", baseCbm: 1.2 },
  { name: "테이블", icon: "item-table.svg", baseCbm: 0.85 },
]

const itemSizeFactor = { 소형: 0.75, 중형: 1, 대형: 1.25 }

function Quote({
  go,
  mode,
  onBack,
  onRequestComplete,
}: {
  go: (screen: Screen) => void
  mode: "standard" | "easy"
  onBack: () => void
  onRequestComplete: () => void
}) {
  const [step, setStep] = useState(0)
  const [videoReady, setVideoReady] = useState(false)
  const [videoName, setVideoName] = useState("")
  const [analysisDone, setAnalysisDone] = useState(false)
  const [dateReady, setDateReady] = useState(false)
  const [dateSkipped, setDateSkipped] = useState(false)
  const [showDateSkipModal, setShowDateSkipModal] = useState(false)
  const [fromReady, setFromReady] = useState(false)
  const [toReady, setToReady] = useState(false)
  const [optionsReady, setOptionsReady] = useState(false)
  const [dateLabel, setDateLabel] = useState("")
  const [fromLabel, setFromLabel] = useState("")
  const [toLabel, setToLabel] = useState("")
  const [optionsLabel, setOptionsLabel] = useState("")
  const videoInputRef = useRef<HTMLInputElement>(null)
  const [recognizedItems, setRecognizedItems] = useState<RecognizedItem[]>([
    { id: "fridge", name: "냉장고", count: 1, baseCbm: 1.8, size: "중형", icon: "item-fridge.svg" },
    { id: "bed", name: "침대", count: 1, baseCbm: 2.4, size: "중형", icon: "item-bed.svg" },
    { id: "sofa", name: "소파", count: 1, baseCbm: 2.1, size: "중형", icon: "item-sofa.svg", needsReview: true },
    { id: "boxes", name: "이사박스", count: 12, baseCbm: 0.3, size: "중형", icon: "item-box.svg" },
    { id: "washer", name: "세탁기", count: 1, baseCbm: 1.2, size: "중형", icon: "item-washer.svg" },
    { id: "table", name: "테이블", count: 2, baseCbm: 0.85, size: "중형", icon: "item-table.svg", needsReview: true },
  ])
  const [editDraft, setEditDraft] = useState<RecognizedItem | null>(null)
  const [addingItem, setAddingItem] = useState(false)
  const [voiceGuideEnabled, setVoiceGuideEnabled] = useState(false)
  const [isVoiceGuideSpeaking, setIsVoiceGuideSpeaking] = useState(false)

  const recognizedCount = recognizedItems.reduce((sum, item) => sum + item.count, 0)
  const recognizedCbm = recognizedItems.reduce(
    (sum, item) => sum + item.baseCbm * itemSizeFactor[item.size] * item.count,
    0,
  )

  useEffect(() => {
    if (step !== 1 || analysisDone) return
    const timer = window.setTimeout(() => setAnalysisDone(true), 1800)
    return () => window.clearTimeout(timer)
  }, [analysisDone, step])

  const canProceed = (() => {
    if (step === 0) return videoReady
    if (step === 1) return analysisDone
    if (step === 2) return optionsReady
    if (step === 3) return fromReady && toReady
    if (step === 4) return dateReady
    return true
  })()

  const data = quoteSteps[step]
  const isLast = step === quoteSteps.length - 1
  const easyVoiceGuides = [
    "영상 올리기 단계입니다. 집 안 전체가 보이도록 촬영한 동영상을 올려주세요. 동영상 선택 버튼을 누르면 됩니다.",
    analysisDone
      ? "영상 분석이 끝났습니다. 찾은 짐 목록을 확인해주세요. 빠진 짐이 있거나 정보가 다르면 해당 품목을 눌러 수정할 수 있습니다."
      : "짐 확인 단계입니다. 올려주신 영상에서 가구와 짐을 찾고 있습니다. 잠시 기다려주세요.",
    "이사 정보 단계입니다. 현재 사는 집의 종류와 원하는 포장 방식을 차례로 선택해주세요.",
    "주소 입력 단계입니다. 출발할 곳과 도착할 곳의 주소를 차례로 입력해주세요.",
    "날짜 선택 단계입니다. 달력에서 이사할 날짜를 고르고, 아래에서 시간을 선택해주세요. 날짜를 아직 모르면 날짜를 모르겠어요 버튼을 누르세요.",
    "견적 확인 단계입니다. 예상 금액과 입력한 이사 정보를 확인해주세요. 바꿀 내용이 있으면 수정 버튼을 누르세요.",
  ]
  const easyNextLabels = [
    "영상 분석하기",
    "인식 품목 확인",
    "주소 입력하기",
    "날짜 선택하기",
    "견적 확인하기",
    "이사 요청하기",
  ]
  const nextLabel = mode === "easy" ? easyNextLabels[step] : isLast ? "이사 요청" : "다음"

  useEffect(() => {
    if (mode !== "easy" || !voiceGuideEnabled || !window.speechSynthesis) {
      return
    }

    window.speechSynthesis.cancel()
    const guide = new SpeechSynthesisUtterance(easyVoiceGuides[step])
    guide.lang = "ko-KR"
    guide.rate = 0.88
    guide.onstart = () => setIsVoiceGuideSpeaking(true)
    guide.onend = () => setIsVoiceGuideSpeaking(false)
    guide.onerror = () => setIsVoiceGuideSpeaking(false)
    window.speechSynthesis.speak(guide)

    return () => {
      window.speechSynthesis.cancel()
      setIsVoiceGuideSpeaking(false)
    }
  }, [analysisDone, mode, step, voiceGuideEnabled])

  const summaryRows: { icon: React.ReactNode; label: string; value: string; goStep: number }[] = [
    {
      icon: (
        <svg fill="none" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg">
          <rect height="14" rx="2" stroke="currentColor" strokeWidth="1.5" width="16" x="2" y="4"/>
          <path d="M2 8h16" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M6 2v2M14 2v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <rect fill="currentColor" height="2.5" rx="0.5" width="2.5" x="6" y="11"/>
          <rect fill="currentColor" height="2.5" rx="0.5" width="2.5" x="10.5" y="11"/>
        </svg>
      ),
      label: "이사일",
      value: dateSkipped ? "일정 미정" : dateLabel || "—",
      goStep: 4,
    },
    {
      icon: (
        <svg fill="none" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 2C7.24 2 5 4.24 5 7c0 4 5 11 5 11s5-7 5-11c0-2.76-2.24-5-5-5z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
          <circle cx="10" cy="7" fill="currentColor" r="2"/>
          <path d="M7 18h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
      label: "출발지",
      value: fromLabel || "—",
      goStep: 3,
    },
    {
      icon: (
        <svg fill="none" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 2C7.24 2 5 4.24 5 7c0 4 5 11 5 11s5-7 5-11c0-2.76-2.24-5-5-5z" stroke="var(--green)" strokeWidth="1.5" strokeLinejoin="round"/>
          <circle cx="10" cy="7" fill="var(--green)" r="2"/>
          <path d="M7 18h6" stroke="var(--green)" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M14 6l3-3m0 0h-2m2 0v2" stroke="var(--green)" strokeWidth="1.3" strokeLinecap="round"/>
        </svg>
      ),
      label: "도착지",
      value: toLabel || "—",
      goStep: 3,
    },
    {
      icon: (
        <svg fill="none" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg">
          <path d="M2 10L10 3l8 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <rect height="8" rx="1" stroke="currentColor" strokeWidth="1.5" width="12" x="4" y="10"/>
          <rect height="4" rx="0.5" stroke="currentColor" strokeWidth="1.3" width="3.5" x="8.25" y="14"/>
        </svg>
      ),
      label: "이사 유형",
      value: optionsLabel || "—",
      goStep: 2,
    },
  ]

  return (
    <div className={mode === "easy" ? "screen flow-screen easy-quote" : "screen flow-screen"}>
      <div className="flow-head">
        <Back onClick={() => (step ? setStep(step - 1) : onBack())} />
        <div className="progress">
          <i style={{ width: `${((step + 1) / quoteSteps.length) * 100}%` }} />
        </div>
        <span>
          {step + 1}/{quoteSteps.length}
        </span>
      </div>
      <div className="flow-body">
        {mode !== "easy" && <div className="flow-kicker">이사 견적</div>}
        {mode === "easy" && (
          <div className="easy-quote-utility">
            <Action
              className={
                voiceGuideEnabled
                  ? "easy-voice-guide active"
                  : "easy-voice-guide"
              }
              label={voiceGuideEnabled ? "음성 안내 끄기" : "음성 안내 켜기"}
              onClick={() => {
                if (voiceGuideEnabled) {
                  window.speechSynthesis?.cancel()
                  setIsVoiceGuideSpeaking(false)
                  setVoiceGuideEnabled(false)
                  return
                }
                setVoiceGuideEnabled(true)
              }}
            >
              <svg
                aria-hidden="true"
                fill="none"
                height="24"
                viewBox="0 0 24 24"
                width="24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path d="M5 10v4h3l4 3V7L8 10H5Z" fill="currentColor" />
                <path
                  d="M15 9.5c.7.6 1 1.4 1 2.5s-.3 1.9-1 2.5M17.5 7c1.3 1.3 2 3 2 5s-.7 3.7-2 5"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeWidth="1.7"
                />
              </svg>
              <strong>
                {voiceGuideEnabled
                  ? isVoiceGuideSpeaking
                    ? "음성 안내 중"
                    : "음성 안내 켜짐"
                  : "음성으로 듣기"}
              </strong>
              {voiceGuideEnabled && <span>끄기</span>}
            </Action>
          </div>
        )}
        <div className="flow-title">
          {mode === "easy" && data.type === "options"
            ? "이사 정보를 선택해주세요"
            : data.title}
        </div>
        <div className="flow-subtitle">
          {mode === "easy" && data.type === "options"
            ? "집 종류와 포장 방법을 하나씩 선택해주세요."
            : data.subtitle}
        </div>
        {data.type === "upload" && (
          <div className={videoReady ? "video-upload-card uploaded" : "video-upload-card"}>
            <input
              accept="video/mp4,video/quicktime,video/*"
              className="video-file-input"
              onChange={(event) => {
                const file = event.target.files?.[0]
                if (!file) return
                setVideoName(file.name)
                setVideoReady(true)
                setAnalysisDone(false)
              }}
              ref={videoInputRef}
              type="file"
            />
            <div className="video-upload-illustration">
              <img alt="" src={`${A}/cd80e.svg`} />
            </div>
            {videoReady ? (
              <>
                <strong>{videoName}</strong>
                <span>영상 업로드가 완료됐어요</span>
                <Action className="video-upload-change" label="다른 영상 선택" onClick={() => videoInputRef.current?.click()}>
                  다른 영상 선택
                </Action>
              </>
            ) : (
              <>
                <strong>집 안 전체가 보이도록 촬영해주세요</strong>
                <span>MP4, MOV 파일 · 최대 5분</span>
                <Action className="video-upload-button" label="동영상 선택" onClick={() => videoInputRef.current?.click()}>
                  동영상 선택
                </Action>
              </>
            )}
          </div>
        )}
        {data.type === "calendar" && (
          <>
            <Calendar
              onDateChange={(ready) => {
                setDateReady(ready)
                if (ready) setDateSkipped(false)
              }}
              onDateLabel={setDateLabel}
            />
            <Action className="calendar-skip" label="이사 날짜 건너뛰기" onClick={() => setShowDateSkipModal(true)}>
              아직 날짜를 모르겠어요
            </Action>
          </>
        )}
        {data.type === "address" && (
          <div className="flow-stack">
            <AddressInput label="출발지" onComplete={setFromReady} onAddressLabel={setFromLabel} />
            <AddressInput label="도착지" onComplete={setToReady} onAddressLabel={setToLabel} />
          </div>
        )}
        {data.type === "options" && (
          <OptionGrid
            easy={mode === "easy"}
            onChange={setOptionsReady}
            onOptionsLabel={setOptionsLabel}
          />
        )}
        {data.type === "analysis" && (
          analysisDone ? (
            <div className="analysis-result-card">
              <div className="analysis-result-head">
                <div>
                  <span>AI 영상 분석 완료</span>
                  <strong>총 {recognizedCount}개 품목을 찾았어요</strong>
                </div>
                <b>{recognizedCbm.toFixed(1)} CBM</b>
              </div>
              <div className="analysis-review-notice">
                <strong>확인이 필요한 품목이 있어요</strong>
                <span>품목을 눌러 종류, 크기, 수량을 수정할 수 있어요.</span>
              </div>
              <div className="recognized-items designed-scroll">
                {recognizedItems.map((item) => (
                  <Action
                    className={item.needsReview ? "recognized-item needs-review" : "recognized-item"}
                    key={item.id}
                    label={`${item.name} 수정`}
                    onClick={() => {
                      setAddingItem(false)
                      setEditDraft({ ...item })
                    }}
                  >
                    <div className="recognized-item-icon">
                      <img alt="" src={`${A}/${item.icon}`} />
                    </div>
                    <div className="recognized-item-copy">
                      <strong>
                        {item.name}
                        {item.needsReview && <em>확인 필요</em>}
                      </strong>
                      <span>{item.size} · {item.count}개</span>
                    </div>
                    <b>{(item.baseCbm * itemSizeFactor[item.size] * item.count).toFixed(1)} CBM</b>
                  </Action>
                ))}
              </div>
              <Action
                className="recognized-add"
                label="빠진 품목 추가"
                onClick={() => {
                  setAddingItem(true)
                  setEditDraft({
                    id: `item-${Date.now()}`,
                    name: "테이블",
                    count: 1,
                    baseCbm: 0.85,
                    size: "중형",
                    icon: "item-table.svg",
                  })
                }}
              >
                + 빠진 품목 추가하기
              </Action>
            </div>
          ) : (
            <div className="analysis-card">
              <div className="scan-box">
                <img alt="" src={`${A}/91e58.svg`} />
                <i />
              </div>
              <strong>영상 속 가구와 짐을 찾고 있어요</strong>
              <span>잠시만 기다려주세요</span>
            </div>
          )
        )}
        {data.type === "summary" && (
          <>
            <div className="estimate-result-card">
              <span>{dateSkipped ? "예상 견적 범위" : "AI 예상 견적"}</span>
              <strong>{dateSkipped ? "400,000 ~ 480,000원" : "410,000원"}</strong>
              <small>
                {dateSkipped
                  ? "이사 날짜에 따라 비용이 달라질 수 있어요."
                  : "선택한 일정과 영상 분석 결과를 반영했어요."}
              </small>
            </div>
            <div className="summary-card">
              {summaryRows.map((row) => (
                <div className="summary-row" key={row.label}>
                  <div className="summary-row-left">
                    <span className="summary-icon">{row.icon}</span>
                    <div className="summary-row-text">
                      <span className="summary-label">{row.label}</span>
                      <b className="summary-value">{row.value}</b>
                    </div>
                  </div>
                  <Action className="summary-edit" label={`${row.label} 수정`} onClick={() => setStep(row.goStep)}>수정</Action>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      <Action
        className={`flow-next ${canProceed ? "primary" : "flow-next-disabled"}`}
        disabled={!canProceed}
        label={nextLabel}
        onClick={() => {
          if (isLast) {
            onRequestComplete()
            return
          }
          setStep(step + 1)
        }}
      >
        {nextLabel}
      </Action>
      {showDateSkipModal && (
        <>
          <div className="date-skip-scrim" onClick={() => setShowDateSkipModal(false)} />
          <div
            aria-describedby="date-skip-description"
            aria-labelledby="date-skip-title"
            aria-modal="true"
            className="date-skip-modal"
            role="dialog"
          >
            <div className="date-skip-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path d="M7 3v3M17 3v3M4 9h16" />
                <rect x="4" y="5" width="16" height="16" rx="3" />
                <path d="M9 15h6" />
              </svg>
            </div>
            <strong id="date-skip-title">날짜를 아직 모르시나요?</strong>
            <span id="date-skip-description">
              날짜 없이도 견적을 먼저 확인할 수 있어요.<br />
              실제 비용은 이사 날짜에 따라 달라질 수 있습니다.
            </span>
            <div className="date-skip-actions">
              <Action className="date-skip-cancel" label="날짜 선택" onClick={() => setShowDateSkipModal(false)}>
                날짜 선택
              </Action>
              <Action
                className="date-skip-confirm"
                label="날짜 없이 견적 보기"
                onClick={() => {
                  setDateSkipped(true)
                  setDateReady(false)
                  setDateLabel("")
                  setShowDateSkipModal(false)
                  setStep(5)
                }}
              >
                날짜 없이 진행
              </Action>
            </div>
          </div>
        </>
      )}
      {editDraft && (
        <>
          <div className="item-edit-scrim" onClick={() => setEditDraft(null)} />
          <div aria-modal="true" className="item-edit-sheet" role="dialog">
            <div className="item-edit-head">
              <div>
                <span>{addingItem ? "누락 품목 추가" : "인식 품목 수정"}</span>
                <strong>{editDraft.name}</strong>
              </div>
              <Action className="item-edit-close" label="닫기" onClick={() => setEditDraft(null)}>
                ×
              </Action>
            </div>
            <div className="item-edit-label">품목 종류</div>
            <div className="item-type-grid">
              {recognizedItemOptions.map((option) => (
                <Action
                  className={editDraft.name === option.name ? "item-type active" : "item-type"}
                  key={option.name}
                  label={option.name}
                  onClick={() => setEditDraft({
                    ...editDraft,
                    name: option.name,
                    icon: option.icon,
                    baseCbm: option.baseCbm,
                  })}
                >
                  <img alt="" src={`${A}/${option.icon}`} />
                  <span>{option.name}</span>
                </Action>
              ))}
            </div>
            <div className="item-edit-label">크기</div>
            <div className="item-size-row">
              {(["소형", "중형", "대형"] as const).map((size) => (
                <Action
                  className={editDraft.size === size ? "item-size active" : "item-size"}
                  key={size}
                  label={`${size} 선택`}
                  onClick={() => setEditDraft({ ...editDraft, size })}
                >
                  {size}
                </Action>
              ))}
            </div>
            <div className="item-count-row">
              <div>
                <strong>수량</strong>
                <span>인식된 개수를 확인해주세요.</span>
              </div>
              <div className="item-stepper">
                <Action
                  className="item-stepper-button"
                  label="수량 줄이기"
                  onClick={() => setEditDraft({ ...editDraft, count: Math.max(1, editDraft.count - 1) })}
                >
                  −
                </Action>
                <b>{editDraft.count}</b>
                <Action
                  className="item-stepper-button"
                  label="수량 늘리기"
                  onClick={() => setEditDraft({ ...editDraft, count: editDraft.count + 1 })}
                >
                  +
                </Action>
              </div>
            </div>
            <div className="item-edit-estimate">
              <span>예상 부피</span>
              <strong>
                {(editDraft.baseCbm * itemSizeFactor[editDraft.size] * editDraft.count).toFixed(1)} CBM
              </strong>
            </div>
            <div className="item-edit-actions">
              {!addingItem && (
                <Action
                  className="item-delete"
                  label="품목 삭제"
                  onClick={() => {
                    setRecognizedItems((items) => items.filter((item) => item.id !== editDraft.id))
                    setEditDraft(null)
                  }}
                >
                  삭제
                </Action>
              )}
              <Action
                className="item-save"
                label={addingItem ? "품목 추가" : "수정 완료"}
                onClick={() => {
                  const saved = { ...editDraft, needsReview: false }
                  setRecognizedItems((items) =>
                    addingItem
                      ? [...items, saved]
                      : items.map((item) => item.id === saved.id ? saved : item),
                  )
                  setEditDraft(null)
                }}
              >
                {addingItem ? "품목 추가" : "수정 완료"}
              </Action>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function Calendar({ onDateChange, onDateLabel }: { onDateChange?: (hasDate: boolean) => void; onDateLabel?: (label: string) => void }) {
  const today = useMemo(() => new Date(), [])
  const [viewYear, setViewYear] = useState(today.getFullYear())
  const [viewMonth, setViewMonth] = useState(today.getMonth())
  const [selectedDay, setSelectedDay] = useState<number | null>(null)
  const [selectedHour, setSelectedHour] = useState(10)
  const [selectedMinute, setSelectedMinute] = useState(0)
  const [showTimePicker, setShowTimePicker] = useState(false)

  const isCurrentMonth =
    viewYear === today.getFullYear() && viewMonth === today.getMonth()

  const firstDow = new Date(viewYear, viewMonth, 1).getDay()
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate()
  const daysInPrev = new Date(viewYear, viewMonth, 0).getDate()
  const totalCells = Math.ceil((firstDow + daysInMonth) / 7) * 7

  const cells = Array.from({ length: totalCells }, (_, i) => {
    if (i < firstDow) return { day: daysInPrev - firstDow + 1 + i, out: true }
    const d = i - firstDow + 1
    if (d > daysInMonth) return { day: d - daysInMonth, out: true }
    return { day: d, out: false }
  })

  const isPast = (day: number) =>
    isCurrentMonth && day < today.getDate()

  const goPrev = () => {
    if (isCurrentMonth) return
    if (viewMonth === 0) { setViewYear(viewYear - 1); setViewMonth(11) }
    else setViewMonth(viewMonth - 1)
    setSelectedDay(null)
    onDateChange?.(false)
  }
  const goNext = () => {
    if (viewMonth === 11) { setViewYear(viewYear + 1); setViewMonth(0) }
    else setViewMonth(viewMonth + 1)
    setSelectedDay(null)
    onDateChange?.(false)
  }

  const ampm = selectedHour < 12 ? "오전" : "오후"
  const displayHour = selectedHour === 0 ? 12 : selectedHour > 12 ? selectedHour - 12 : selectedHour
  const timeLabel = `${ampm} ${displayHour}:${String(selectedMinute).padStart(2, "0")}`

  const timeSlotGroups = [
    {
      key: "morning",
      label: "오전",
      slots: [
        { hour: 8, minute: 0 },
        { hour: 10, minute: 0 },
      ],
    },
    {
      key: "afternoon",
      label: "오후",
      slots: [
        { hour: 13, minute: 0 },
        { hour: 15, minute: 0 },
        { hour: 17, minute: 0 },
      ],
    },
  ]

  const monthNames = ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"]

  return (
    <div className="calendar">
      <div className="calendar-head">
        <b>{viewYear}년 {monthNames[viewMonth]}</b>
        <div className="calendar-arrows">
          <Action
            className={`previous${isCurrentMonth ? " nav-disabled" : ""}`}
            label="이전 달"
            onClick={goPrev}
          >
            <Chevron />
          </Action>
          <Action label="다음 달" onClick={goNext}>
            <Chevron />
          </Action>
        </div>
      </div>
      <div className="week">
        {["일","월","화","수","목","금","토"].map((d) => (
          <span key={d}>{d}</span>
        ))}
      </div>
      <div className="days">
        {cells.map((cell, i) => {
          if (cell.out) return <span className="muted" key={i}>{cell.day}</span>
          const past = isPast(cell.day)
          const picked = selectedDay === cell.day
          return (
            <span
              className={picked ? "picked" : past ? "muted" : "selectable"}
              key={i}
              onClick={() => { if (!past) { setSelectedDay(cell.day); onDateChange?.(true); const mm = String(viewMonth + 1).padStart(2, "0"); const dd = String(cell.day).padStart(2, "0"); onDateLabel?.(`${viewYear}. ${mm}. ${dd} ${ampm} ${displayHour}:${String(selectedMinute).padStart(2, "0")}`) } }}
            >
              {cell.day}
            </span>
          )
        })}
      </div>
      {selectedDay !== null && (
        <Action className="time-row" label="시간 변경" onClick={() => setShowTimePicker(true)}>
          <b>{timeLabel}</b>
          <span>시간 변경 <Chevron /></span>
        </Action>
      )}

      {showTimePicker && (
        <>
          <div className="cal-scrim" onClick={() => setShowTimePicker(false)} />
          <div className="cal-time-sheet">
            <div className="cal-time-head">
              <strong>시간 선택</strong>
              <Action label="닫기" onClick={() => setShowTimePicker(false)}>×</Action>
            </div>
            <div className="cal-time-groups designed-scroll">
              {timeSlotGroups.map((group) => (
                <div className={`cal-time-group ${group.key}`} key={group.key}>
                  <div className="cal-time-period">
                    <strong>{group.label}</strong>
                  </div>
                  <div className="cal-time-slots">
                    {group.slots.map(({ hour, minute }) => {
                      const ap = hour < 12 ? "오전" : "오후"
                      const dh = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
                      const fullLabel = `${ap} ${dh}:${String(minute).padStart(2, "0")}`
                      const shortLabel = `${dh}:${String(minute).padStart(2, "0")}`
                      const active =
                        hour === selectedHour && minute === selectedMinute
                      return (
                        <Action
                          className={
                            active ? "cal-time-slot active" : "cal-time-slot"
                          }
                          key={`${hour}-${minute}`}
                          label={fullLabel}
                          onClick={() => {
                            setSelectedHour(hour)
                            setSelectedMinute(minute)
                            setShowTimePicker(false)
                            if (selectedDay !== null) {
                              const mm = String(viewMonth + 1).padStart(2, "0")
                              const dd = String(selectedDay).padStart(2, "0")
                              onDateLabel?.(
                                `${viewYear}. ${mm}. ${dd} ${fullLabel}`,
                              )
                            }
                          }}
                        >
                          {shortLabel}
                        </Action>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

const houseTypes = ["원룸 / 오피스텔", "아파트", "빌라 / 주택", "사무실"]
const packTypes = ["일반포장", "반포장"]
const packDescriptions = ["직접 포장", "큰 짐은 업체가 포장"]
const easyHouseIcons = [
  "easy-home-studio.svg",
  "easy-home-apartment.svg",
  "easy-home-house.svg",
  "easy-home-office.svg",
]
const easyPackIcons = ["easy-pack-standard.svg", "easy-pack-partial.svg"]

const houseIcons = [
  // 원룸/오피스텔: 작은 건물 + 창문
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><rect height="16" rx="2" stroke="currentColor" strokeWidth="1.6" width="14" x="6" y="8"/><rect height="4" rx="0.5" stroke="currentColor" strokeWidth="1.4" width="4" x="11" y="14"/><path d="M6 12h14" stroke="currentColor" strokeWidth="1.4"/><path d="M13 8V5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  // 아파트: 고층 격자 건물
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><rect height="18" rx="1.5" stroke="currentColor" strokeWidth="1.6" width="16" x="5" y="6"/><path d="M5 10h16M5 14h16M5 18h16" stroke="currentColor" strokeWidth="1.2"/><path d="M11 6v18M15 6v18" stroke="currentColor" strokeWidth="1.2"/></svg>,
  // 빌라/주택: 지붕 있는 집
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><path d="M3 13L13 5l10 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><rect height="10" rx="1" stroke="currentColor" strokeWidth="1.6" width="14" x="6" y="13"/><rect height="5" rx="0.5" stroke="currentColor" strokeWidth="1.4" width="4" x="11" y="18"/></svg>,
  // 사무실: 빌딩 + 문
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><rect height="19" rx="1.5" stroke="currentColor" strokeWidth="1.6" width="18" x="4" y="5"/><rect height="3" rx="0.4" stroke="currentColor" strokeWidth="1.2" width="3" x="8" y="9"/><rect height="3" rx="0.4" stroke="currentColor" strokeWidth="1.2" width="3" x="14" y="9"/><rect height="3" rx="0.4" stroke="currentColor" strokeWidth="1.2" width="3" x="8" y="14"/><rect height="3" rx="0.4" stroke="currentColor" strokeWidth="1.2" width="3" x="14" y="14"/><path d="M11 24v-5h4v5" stroke="currentColor" strokeWidth="1.4"/></svg>,
]

const packIcons = [
  // 일반포장: 박스 + 테이프
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><rect height="14" rx="1.5" stroke="currentColor" strokeWidth="1.6" width="16" x="5" y="9"/><path d="M5 13h16" stroke="currentColor" strokeWidth="1.4"/><path d="M10 9V6h6v3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M10 13v4M16 13v4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>,
  // 반포장: 열린 박스 + 물건
  <svg fill="none" height="26" viewBox="0 0 26 26" width="26" xmlns="http://www.w3.org/2000/svg"><path d="M5 13v9h16v-9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 9l2 4h16l2-4H3z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/><path d="M10 9V6h6v3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M10 17h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>,
]

function OptionGrid({
  easy = false,
  onChange,
  onOptionsLabel,
}: {
  easy?: boolean
  onChange?: (valid: boolean) => void
  onOptionsLabel?: (label: string) => void
}) {
  const [house, setHouse] = useState<number | null>(null)
  const [pack, setPack] = useState<number | null>(null)

  const pickHouse = (i: number) => {
    setHouse(i)
    onChange?.(pack !== null)
    if (pack !== null) onOptionsLabel?.(`${houseTypes[i]} · ${packTypes[pack]}`)
  }
  const pickPack = (i: number) => {
    setPack(i)
    onChange?.(house !== null)
    if (house !== null) onOptionsLabel?.(`${houseTypes[house]} · ${packTypes[i]}`)
  }

  if (easy) {
    return (
      <div className="easy-option-flow">
        <div className="easy-option-section">
          <div className="easy-option-list house-options">
            {houseTypes.map((label, i) => (
              <Action
                className={
                  house === i
                    ? "easy-option-card active"
                    : "easy-option-card"
                }
                key={label}
                label={label}
                onClick={() => pickHouse(i)}
              >
                <span>
                  <img alt="" src={`${A}/${easyHouseIcons[i]}`} />
                </span>
                <strong>{label}</strong>
                {house === i && <b>✓</b>}
              </Action>
            ))}
          </div>
        </div>
        <div className="easy-option-section">
          <div className="easy-option-list pack-options">
            {packTypes.map((label, i) => (
              <Action
                className={
                  pack === i
                    ? "easy-option-card pack active"
                    : "easy-option-card pack"
                }
                key={label}
                label={`${label}, ${packDescriptions[i]}`}
                onClick={() => pickPack(i)}
              >
                <span>
                  <img alt="" src={`${A}/${easyPackIcons[i]}`} />
                </span>
                <div>
                  <strong>{label}</strong>
                  <small>{packDescriptions[i]}</small>
                </div>
                <b>{pack === i ? "✓" : ""}</b>
              </Action>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="option-groups">
      <div className="option-group">
        <div className="option-grid">
          {houseTypes.map((label, i) => (
            <Action
              className={house === i ? "option active" : "option"}
              key={label}
              label={label}
              onClick={() => pickHouse(i)}
            >
              <span>
                <img alt="" src={`${A}/${easyHouseIcons[i]}`} />
              </span>
              {label}
              {house === i && <b>✓</b>}
            </Action>
          ))}
        </div>
      </div>
      <div className="option-group">
        <div className="option-grid">
          {packTypes.map((label, i) => (
            <Action
              className={pack === i ? "option active" : "option"}
              key={label}
              label={label}
              onClick={() => pickPack(i)}
            >
              <span>
                <img alt="" src={`${A}/${easyPackIcons[i]}`} />
              </span>
              {label}
              {pack === i && <b>✓</b>}
            </Action>
          ))}
        </div>
      </div>
    </div>
  )
}

function Move({
  estimateStatus,
  go,
  mode,
  notificationCount,
  onConfirmEstimate,
  onModeChange,
  onTabChange,
  tab,
}: {
  estimateStatus: EstimateStatus
  go: (screen: Screen) => void
  mode: "standard" | "easy"
  notificationCount: number
  onConfirmEstimate: () => void
  onModeChange: (mode: "standard" | "easy") => void
  onTabChange: (tab: MoveTab) => void
  tab: MoveTab
}) {
  const [showQuoteDoc, setShowQuoteDoc] = useState(false)
  const [quoteZoom, setQuoteZoom] = useState(75)
  const quoteDocumentDrag = useDragScroll()
  const confirmed = estimateStatus === "confirmed"

  const estimateItems = [
    ["냉장고", "1", "침대", "1", "소파", "1", "이사박스", "12"],
    ["세탁기", "1", "옷장", "1", "테이블", "1", "행거", "2"],
    ["TV", "1", "서랍장", "1", "의자", "2", "화분", "3"],
    ["전자레인지", "1", "책장", "1", "책상", "1", "생활짐", "1식"],
  ]

  return (
    <div className="screen page-with-nav">
      <Header
        go={go}
        mode={mode}
        notificationCount={notificationCount}
        onModeChange={onModeChange}
      />
      <main className="sub-content">
        <div className="move-sticky-nav">
          <div className="page-title">내 이사</div>
          <div className="tabs">
            <Action className={`action${tab === "booking" ? " tab-active" : ""}`} label="예약 정보" onClick={() => onTabChange("booking")}>예약 정보</Action>
            <Action className={`action${tab === "estimate" ? " tab-active" : ""}`} label="견적 정보" onClick={() => onTabChange("estimate")}>견적 정보</Action>
            <Action className={`action${tab === "done" ? " tab-active" : ""}`} label="완료" onClick={() => onTabChange("done")}>완료</Action>
          </div>
        </div>

        {tab === "booking" && (
          confirmed ? (
            <>
              <BookingCard go={go} />
              <div className="info-card">
                <div className="info-icon">✓</div>
                <div>
                  <strong>이사 준비 체크리스트</strong>
                  <span>꼭 챙겨야 할 항목을 확인해보세요</span>
                </div>
                <Chevron />
              </div>
            </>
          ) : (
            <div className="booking-empty-state">
              <svg
                aria-hidden="true"
                fill="none"
                height="36"
                viewBox="0 0 36 36"
                width="36"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect height="25" rx="4" stroke="currentColor" strokeWidth="1.6" width="28" x="4" y="7" />
                <path d="M4 14h28M11 4v6M25 4v6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
                <path d="M13 22h10" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
              </svg>
              <strong>아직 확정된 예약이 없어요</strong>
              <span>도착한 견적을 확정하면 예약 일정이 표시돼요.</span>
              {estimateStatus !== "none" && (
                <Action
                  className="booking-empty-link"
                  label="견적 정보 확인"
                  onClick={() => onTabChange("estimate")}
                >
                  견적 정보 확인
                  <Chevron />
                </Action>
              )}
            </div>
          )
        )}

        {tab === "estimate" && estimateStatus === "waiting-approval" && (
          <div className="move-state-card waiting">
            <span>관리자 확인 중</span>
            <strong>견적 요청을 검토하고 있어요.</strong>
            <small>담당자가 요청을 확인하면 견적서를 보여드려요.</small>
          </div>
        )}

        {tab === "estimate" && estimateStatus === "none" && (
          <div className="move-state-card">
            <span>견적 없음</span>
            <strong>아직 요청한 견적이 없습니다.</strong>
            <small>영상 견적을 요청하면 진행 상태를 확인할 수 있습니다.</small>
            <Action className="move-state-action" label="새 견적 받기" onClick={() => go("quote")}>
              새 견적 받기
            </Action>
          </div>
        )}

        {tab === "estimate" && (estimateStatus === "approved" || confirmed) && (
          <div className="move-estimate-section">
            {/* 견적 확정 카드 */}
            <div className="move-estimate-card">
              <div className="move-estimate-badge">진행중 견적</div>
              <div className="move-estimate-company">명품익스프레스</div>
              <div className="move-estimate-price">
                <b>410,000원</b>
                <span>포장 · 운송 · 정리 포함</span>
              </div>
              <div className="move-estimate-meta">
                <span>🏠 원룸 · 일반포장</span>
                <span>📅 2026. 03. 18 오전 10:00</span>
                <span>📍 강남구 → 서초구</span>
              </div>
              <div className="move-estimate-actions">
                <Action className="move-quote-btn" label="견적서 확인" onClick={() => setShowQuoteDoc(true)}>
                  <svg fill="none" height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg"><rect height="12" rx="1.5" stroke="currentColor" strokeWidth="1.4" width="10" x="3" y="2"/><path d="M6 6h4M6 9h4M6 12h2" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3"/></svg>
                  견적서 확인
                </Action>
                <Action
                  className={`move-confirm-btn${confirmed ? " confirmed" : ""}`}
                  disabled={confirmed}
                  label="견적 확정"
                  onClick={onConfirmEstimate}
                >
                  {confirmed ? "✓ 확정 완료" : "견적 확정"}
                </Action>
              </div>
            </div>

            {/* 상세 견적 내역 */}
            <div className="move-estimate-detail">
              <div className="move-estimate-detail-title">상세 견적 내역</div>
              <div className="receipt-section-label">기본 이사 요금</div>
              <div className="receipt-rule" />
              {[
                { label: "기본 운송비", sub: "기본 거리 10km 포함", value: "250,000원" },
                { label: "포장·인력 등 작업비", value: "140,000원" },
                { label: "도착지 사다리차 비용 (8층)", value: "20,000원" },
              ].map((row) => (
                <div className="receipt-row" key={row.label}>
                  <div className="receipt-row-label">
                    <span>{row.label}</span>
                    {row.sub && <small>{row.sub}</small>}
                  </div>
                  <b>{row.value}</b>
                </div>
              ))}
              <div className="receipt-total-row">
                <span>최종 견적 금액</span>
                <b>410,000원</b>
              </div>
            </div>

            {/* 진행 중인 다른 견적 */}
            <div className="mini-title" style={{ marginTop: 24 }}>다른 진행 중 견적</div>
            <div className="empty-card">현재 진행 중인 추가 견적이 없습니다.</div>
          </div>
        )}

        {tab === "done" && (
          <div className="move-done-section">
            <div className="move-done-card">
              <div className="move-done-head">
                <span className="move-done-status">이사 완료</span>
                <small>2025. 11. 04</small>
              </div>
              <strong className="move-done-company">명품익스프레스</strong>
              <div className="move-done-route">
                <span>마포구 합정동</span>
                <svg fill="none" height="14" viewBox="0 0 20 14" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M1 7h18M13 1l6 6-6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6"/></svg>
                <span>서대문구 홍은동</span>
              </div>
              <div className="move-done-meta">원룸 · 반포장 · 320,000원</div>
              <div className="move-done-actions">
                <Action className="move-done-detail-btn" label="상세 보기" onClick={() => go("detail")}>
                  상세 보기
                </Action>
                <Action className="move-done-review-btn" label="리뷰 작성" onClick={() => go("reviews")}>
                  <svg fill="none" height="14" viewBox="0 0 16 16" width="14" xmlns="http://www.w3.org/2000/svg"><path d="M11 2l3 3-8 8H3v-3L11 2z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4"/></svg>
                  리뷰 작성
                </Action>
              </div>
            </div>

            <Action className="move-done-more" label="예약 내역 전체 보기" onClick={() => go("reservations")}>
              예약 내역 전체 보기
              <Chevron />
            </Action>
          </div>
        )}
      </main>

      {/* 견적서 문서 모달 */}
      {showQuoteDoc && (
        <>
          <div className="scrim" onClick={() => setShowQuoteDoc(false)} style={{ zIndex: 60 }} />
          <div className="quote-doc-sheet">
            <div className="quote-doc-head">
              <div className="quote-doc-head-left">
                <strong>명품익스프레스</strong>
                <span>QT-20260310-0042</span>
              </div>
              <div className="quote-doc-tools">
                <div className="quote-zoom-controls" aria-label="견적서 배율 조절">
                  <Action
                    className="quote-zoom-button"
                    disabled={quoteZoom <= 50}
                    label="견적서 축소"
                    onClick={() => setQuoteZoom((zoom) => Math.max(50, zoom - 25))}
                  >
                    −
                  </Action>
                  <Action
                    className="quote-zoom-value"
                    label="견적서 배율 100%로 초기화"
                    onClick={() => setQuoteZoom(100)}
                  >
                    {quoteZoom}%
                  </Action>
                  <Action
                    className="quote-zoom-button"
                    disabled={quoteZoom >= 150}
                    label="견적서 확대"
                    onClick={() => setQuoteZoom((zoom) => Math.min(150, zoom + 25))}
                  >
                    +
                  </Action>
                </div>
                <Action className="quote-doc-close" label="닫기" onClick={() => setShowQuoteDoc(false)}>×</Action>
              </div>
            </div>
            <div
              className={quoteDocumentDrag.isDragging ? "quote-doc-body designed-scroll is-dragging" : "quote-doc-body designed-scroll"}
              onPointerCancel={quoteDocumentDrag.onPointerCancel}
              onPointerDown={quoteDocumentDrag.onPointerDown}
              onPointerMove={quoteDocumentDrag.onPointerMove}
              onPointerUp={quoteDocumentDrag.onPointerUp}
              ref={quoteDocumentDrag.ref}
            >
              <div className="quote-pan-hint">손가락이나 마우스로 문서를 끌어 이동하세요</div>
              <div
                className="vendor-estimate"
                style={{ "--quote-zoom": quoteZoom / 100 } as React.CSSProperties}
              >
                <div className="vendor-estimate-top">
                  <div className="vendor-brand">
                    <strong>명품 익스프레스</strong>
                    <span>포장이사 전문업체 관허 2015-7호</span>
                    <span>(피해보상)보증보험 가입</span>
                  </div>
                  <div className="vendor-doc-title">
                    <strong>견적서 / 계약서</strong>
                    <span>(ESTIMATE REPORT)</span>
                  </div>
                  <div className="vendor-registration">
                    <div><b>등록 번호</b><span>398-51-00044</span></div>
                    <div><b>사무실전화</b><span>062) 252-0303</span></div>
                    <div><b>대표자전화</b><span>010-9445-8224</span></div>
                  </div>
                </div>

                <div className="vendor-customer-grid">
                  <b>업체명</b><span>명품 익스프레스</span>
                  <b>담당자</b><span>김선국 (님)</span>
                  <b>TEL</b><span>010-9445-8224</span>
                  <b>견적일</b><span>2026. 03. 10.</span>
                  <b>출발지</b><span>서울 강남구 테헤란로 123, 301호</span>
                  <b>작업일</b><span>2026. 03. 18.</span>
                  <b>도착지</b><span>서울 서초구 서초대로 456, 804호</span>
                  <b>운송일</b><span>2026. 03. 18.</span>
                </div>

                <div className="vendor-items">
                  <div className="vendor-items-groups">
                    <b>전자기기</b><b>가구</b><b>생활용품</b><b>기타</b>
                  </div>
                  <div className="vendor-items-head">
                    {Array.from({ length: 4 }).map((_, index) => (
                      <React.Fragment key={index}>
                        <b>품목</b><b>수량</b>
                      </React.Fragment>
                    ))}
                  </div>
                  {estimateItems.map((row, index) => (
                    <div className="vendor-items-row" key={index}>
                      {row.map((cell, cellIndex) => <span key={cellIndex}>{cell}</span>)}
                    </div>
                  ))}
                  {Array.from({ length: Math.max(0, 8 - estimateItems.length) }).map((_, index) => (
                    <div className="vendor-items-row" key={`empty-${index}`}>
                      {Array.from({ length: 8 }).map((__, cellIndex) => <span key={cellIndex} />)}
                    </div>
                  ))}
                </div>

                <div className="vendor-work-grid">
                  <b className="vendor-vertical-label">옵션 비용</b>
                  <div className="vendor-options">
                    <span>피아노　일반 □ / 그랜드 □　₩ 0</span>
                    <span>돌침대　분해 □ / 조립 □　₩ 0</span>
                    <span>벽걸이TV　탈착 ■ / 설치 ■　₩ 20,000</span>
                    <span>에어컨　탈착 □ / 설치 □　₩ 0</span>
                  </div>
                  <div className="vendor-work-details">
                    <div><b>작업내용</b><span>포장 □　/　일반 ■　/　보관 □</span></div>
                    <div><b>운반방법</b><span>승강기 전 ■ / 후 ■　·　계단작업 전 □ / 후 □</span></div>
                    <div><b>이사물량</b><span>1 톤(ton)</span></div>
                    <div><b>비고</b><span>파손주의 품목 별도 포장</span></div>
                  </div>
                </div>

                <div className="vendor-cost-grid">
                  <div className="vendor-cost-column">
                    <b>A. 작업 비용</b>
                    <div><span>이사비용</span><strong>₩ 390,000</strong></div>
                    <div><span>사다리비용</span><strong>₩ 0</strong></div>
                    <div className="vendor-cost-total"><span>총 비용</span><strong>₩ 410,000</strong></div>
                  </div>
                  <div className="vendor-cost-column">
                    <b>B. 별도 비용</b>
                    <div><span>출발지 사다리(3)층</span><strong>₩ 0</strong></div>
                    <div><span>도착지 사다리(8)층</span><strong>₩ 20,000</strong></div>
                    <div className="vendor-cost-total"><span>사다리 소계</span><strong>₩ 20,000</strong></div>
                  </div>
                </div>

                <div className="vendor-payment-grid">
                  <b>계약금 10%</b><span>₩ 41,000</span>
                  <b className="vendor-balance-label">잔금</b><span className="vendor-balance-value">₩ 369,000</span>
                  <div className="vendor-payment-note">※ 현장 상황 및 고객 요청사항 변경 시 비용이 조정될 수 있습니다.</div>
                </div>

                <div className="vendor-sign-grid">
                  <b>견적 담당자</b><span>김선국　(서명) / H.P　010-9445-8224</span>
                  <b>고객 확인</b><span>김무브　(서명)</span>
                </div>
              </div>
            </div>
            <div className="quote-doc-footer">
              <Action className="outline quote-doc-action" label="PDF 다운로드" onClick={() => setShowQuoteDoc(false)}>
                <svg fill="none" height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M8 2v8M5 7l3 3 3-3" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"/><path d="M3 12h10" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5"/></svg>
                PDF 다운로드
              </Action>
              <Action
                className="primary quote-doc-action"
                disabled={confirmed}
                label="견적 확정"
                onClick={() => {
                  onConfirmEstimate()
                  setShowQuoteDoc(false)
                }}
              >
                {confirmed ? "예약 완료" : "견적 확정"}
              </Action>
            </div>
          </div>
        </>
      )}

      <BottomNav active="move" easy={mode === "easy"} go={go} />
    </div>
  )
}

type ChatAction = {
  label: string
  screen?: Screen
  prompt?: string
}

type ChatMessage = {
  id: number
  role: "user" | "bot"
  text: string
  attachment?: string
  actions?: ChatAction[]
  time: string
}

function Chat({
  estimateStatus,
  go,
  onBack,
  userName,
}: {
  estimateStatus: EstimateStatus
  go: (screen: Screen) => void
  onBack: () => void
  userName: string
}) {
  const topics = [
    "이사 견적 알아보기",
    "예약 및 일정 확인",
    "영상 분석 견적",
    "이사 준비 체크리스트",
    "결제 및 환불 문의",
    "상담사 연결",
  ]
  const [draft, setDraft] = useState("")
  const [attachment, setAttachment] = useState("")
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [typing, setTyping] = useState(false)
  const inputRef = useRef<HTMLDivElement>(null)
  const endRef = useRef<HTMLDivElement>(null)
  const replyTimerRef = useRef<number | null>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" })
  }, [messages, typing])

  useEffect(() => {
    return () => {
      if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current)
    }
  }, [])

  const getTime = () =>
    new Intl.DateTimeFormat("ko-KR", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date())

  const getReply = (value: string, fileName?: string) => {
    if (fileName) {
      return {
        text: `${fileName} 파일을 확인 요청에 첨부했어요.\n개인정보가 포함된 문서는 필요한 부분만 남기고 가려서 보내주세요.`,
        actions: [
          { label: "첨부 관련 문의", prompt: "첨부한 파일로 어떤 상담을 받을 수 있나요?" },
          { label: "상담사 연결", prompt: "상담사 연결 요청" },
        ],
      }
    }

    if (value.includes("상담사")) {
      return {
        text:
          value.includes("요청")
            ? "상담사 연결 요청을 접수했어요.\n운영시간에는 순서대로 상담이 시작되며, 답변이 오면 알림으로 알려드릴게요."
            : "상담사에게 직접 문의할 수 있어요.\n상담 운영시간은 평일 09:00–18:00이며, 운영시간 외 요청은 다음 영업일에 확인합니다.",
        actions: value.includes("요청")
          ? [{ label: "자주 묻는 질문 보기", prompt: "자주 묻는 질문을 알려주세요" }]
          : [{ label: "상담사 연결 요청", prompt: "상담사 연결 요청" }],
      }
    }

    if (value.includes("예약") || value.includes("일정")) {
      if (estimateStatus === "confirmed") {
        return {
          text: `${userName}님의 이사 예약은 2026년 3월 18일 오전 10시로 확정되어 있어요.\n출발지는 강남구, 도착지는 서초구입니다.`,
          actions: [{ label: "예약 정보 보기", screen: "move" as Screen }],
        }
      }
      return {
        text: "아직 확정된 예약은 없어요.\n도착한 견적서를 확인하고 확정하면 예약 일정이 생성됩니다.",
        actions: [
          { label: "견적 정보 보기", screen: "move" as Screen },
          { label: "예약 과정 안내", prompt: "견적 확정 후 예약 과정이 궁금해요" },
        ],
      }
    }

    if (value.includes("영상") || value.includes("분석") || value.includes("CBM")) {
      return {
        text: "집 안을 촬영한 영상을 올리면 AI가 가구와 짐의 부피를 분석해 예상 CBM과 견적을 계산해요.\n영상은 방 전체가 끊기지 않게 천천히 촬영하면 더 정확합니다.",
        actions: [
          { label: "영상 견적 시작", screen: "quote" as Screen },
          { label: "촬영 방법 보기", prompt: "영상을 어떻게 촬영해야 하나요?" },
        ],
      }
    }

    if (value.includes("견적") || value.includes("비용")) {
      if (estimateStatus === "approved") {
        return {
          text: "담당자가 확인한 견적이 준비되어 있어요.\n현재 견적 금액은 410,000원이며, 견적서의 작업 내용과 별도 비용을 확인한 뒤 확정할 수 있습니다.",
          actions: [{ label: "견적서 보기", screen: "move" as Screen }],
        }
      }
      if (estimateStatus === "waiting-approval") {
        return {
          text: "요청하신 견적을 담당자가 확인하고 있어요.\n견적이 준비되면 홈 알림과 견적내역에서 바로 알려드릴게요.",
          actions: [{ label: "견적내역 보기", screen: "estimates" as Screen }],
        }
      }
      if (estimateStatus === "confirmed") {
        return {
          text: "410,000원 견적을 확정해 예약이 완료된 상태예요.\n확정된 작업 내용은 예약 정보와 견적서에서 다시 확인할 수 있습니다.",
          actions: [{ label: "예약 정보 보기", screen: "move" as Screen }],
        }
      }
      return {
        text: "영상 견적을 요청하면 AI 예상 견적을 바탕으로 담당자가 상세 내용을 확인해요.",
        actions: [{ label: "새 견적 받기", screen: "quote" as Screen }],
      }
    }

    if (value.includes("준비") || value.includes("체크리스트") || value.includes("촬영")) {
      return {
        text: "이사 전에는 귀중품 별도 보관, 냉장고 음식 정리, 주소 이전, 가전 설치 일정을 먼저 확인해주세요.\n이사 전날에는 주차 공간과 엘리베이터 예약도 확인하는 것이 좋아요.",
        actions: [
          { label: "예약 일정 확인", prompt: "내 예약 일정 확인" },
          { label: "추가 준비 팁", prompt: "이사 당일 준비 팁도 알려주세요" },
        ],
      }
    }

    if (value.includes("결제") || value.includes("환불") || value.includes("예약금")) {
      return {
        text: "견적 확정 후 안내된 예약금을 결제하면 예약이 최종 접수돼요.\n취소·환불 가능 금액은 작업일과 취소 시점에 따라 달라질 수 있어 상담사 확인이 필요합니다.",
        actions: [
          { label: "상담사에게 문의", prompt: "결제 및 환불 상담사 연결 요청" },
          { label: "예약 정보 보기", screen: "move" as Screen },
        ],
      }
    }

    if (value.includes("자주 묻는")) {
      return {
        text: "많이 묻는 내용은 견적 산정 방식, 영상 촬영 방법, 예약 변경, 사다리차와 추가 비용, 취소·환불 기준이에요.\n궁금한 항목을 메시지로 입력해주세요.",
        actions: [
          { label: "추가 비용", prompt: "추가 비용이 발생하는 경우를 알려주세요" },
          { label: "예약 변경", prompt: "예약 일정을 변경하고 싶어요" },
        ],
      }
    }

    return {
      text: "문의 내용을 확인했어요.\n견적, 예약 일정, 영상 분석, 결제·환불 중 어떤 도움이 필요한지 조금 더 자세히 알려주세요.",
      actions: [
        { label: "견적 문의", prompt: "이사 견적 알아보기" },
        { label: "예약 문의", prompt: "예약 및 일정 확인" },
        { label: "상담사 연결", prompt: "상담사 연결" },
      ],
    }
  }

  const ask = (value: string) => {
    const text = value.trim()
    const currentAttachment = attachment
    if (!text && !currentAttachment) return
    const userMessage: ChatMessage = {
      id: Date.now(),
      role: "user",
      text: text || "파일을 첨부했어요.",
      attachment: currentAttachment || undefined,
      time: getTime(),
    }
    setMessages((current) => [...current, userMessage])
    setDraft("")
    setAttachment("")
    if (inputRef.current) inputRef.current.innerText = ""
    setTyping(true)
    if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current)
    replyTimerRef.current = window.setTimeout(() => {
      const reply = getReply(text, currentAttachment)
      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          role: "bot",
          text: reply.text,
          actions: reply.actions,
          time: getTime(),
        },
      ])
      setTyping(false)
    }, 650)
  }

  const pickAttachment = async () => {
    const picker = (window as Window & {
      showOpenFilePicker?: () => Promise<Array<{ name: string }>>
    }).showOpenFilePicker
    if (!picker) {
      setAttachment("첨부 파일")
      return
    }
    try {
      const [file] = await picker.call(window)
      if (file) setAttachment(file.name)
    } catch {
      // The user closed the native file picker without choosing a file.
    }
  }

  return (
    <div className="screen chat-screen">
      <div className="chat-header">
        <Back onClick={onBack} />
        <div className="chat-header-title">
          <strong>명품 상담</strong>
          <span>AI 이사 도우미</span>
        </div>
        <span />
      </div>
      <main className="chat-content">
        <div className="chat-start-label">명품 상담을 시작했어요</div>
        <div className="chat-bot-row">
          <div className="chat-avatar">
            <img
              alt="명품 이사 도우미 캐릭터"
              src={`${A}/mover-assistant-3d.svg`}
            />
          </div>
          <div className="chat-bot-name">명품 이사 도우미</div>
        </div>
        <div className="chat-menu-card">
          <div className="chat-greeting">
            안녕하세요, 명품익스프레스입니다.
            <br />
            궁금하신 내용을 선택해주세요.
          </div>
          <div className="chat-topic-list">
            {topics.map((topic, index) => (
              <Action
                className={
                  index === topics.length - 1
                    ? "chat-topic chat-topic-accent"
                    : "chat-topic"
                }
                key={topic}
                label={topic}
                onClick={() => ask(topic)}
              >
                {topic}
              </Action>
            ))}
          </div>
          <div className="chat-hours">상담 운영시간　평일 09:00–18:00</div>
        </div>
        {messages.length > 0 && <div className="chat-restart-label">상담 내용</div>}
        <div className="chat-thread" aria-live="polite">
          {messages.map((message) => (
            <div
              className={message.role === "user" ? "chat-message-wrap user" : "chat-message-wrap bot"}
              key={message.id}
            >
              {message.role === "bot" && (
                <div className="chat-mini-avatar">
                  <img alt="" src={`${A}/mover-assistant-3d.svg`} />
                </div>
              )}
              <div className="chat-message-content">
                <div className={`message ${message.role}`}>{message.text}</div>
                {message.attachment && (
                  <div className="chat-file-message">
                    <img alt="" src={`${A}/paperclip.svg`} />
                    <span>{message.attachment}</span>
                  </div>
                )}
                {message.actions && (
                  <div className="chat-quick-replies">
                    {message.actions.map((action) => (
                      <Action
                        key={action.label}
                        label={action.label}
                        onClick={() => {
                          if (action.screen) {
                            go(action.screen)
                            return
                          }
                          if (action.prompt) ask(action.prompt)
                        }}
                      >
                        {action.label}
                      </Action>
                    ))}
                  </div>
                )}
                <small className="chat-message-time">{message.time}</small>
              </div>
            </div>
          ))}
          {typing && (
            <div className="chat-message-wrap bot">
              <div className="chat-mini-avatar">
                <img alt="" src={`${A}/mover-assistant-3d.svg`} />
              </div>
              <div className="chat-typing" aria-label="답변 작성 중">
                <i />
                <i />
                <i />
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
      </main>
      <div className="chat-input">
        {attachment && (
          <div className="chat-attachment-chip">
            <img alt="" src={`${A}/paperclip.svg`} />
            <span>{attachment}</span>
            <Action label="첨부 파일 제거" onClick={() => setAttachment("")}>
              ×
            </Action>
          </div>
        )}
        <div className="chat-input-row">
          <Action
            className="chat-attach"
            label="파일 첨부"
            onClick={pickAttachment}
          >
            <img alt="" src={`${A}/paperclip.svg`} />
          </Action>
          <div
            aria-label="상담 내용 입력"
            className="chat-editor designed-scroll"
            contentEditable
            data-placeholder="상담할 내용을 입력해주세요"
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault()
                ask(draft)
              }
            }}
            onInput={(event) => setDraft(event.currentTarget.innerText)}
            ref={inputRef}
            role="textbox"
            suppressContentEditableWarning
          />
          <Action
            className="chat-send"
            disabled={!draft.trim() && !attachment}
            label="메시지 보내기"
            onClick={() => ask(draft)}
          >
            <img alt="" src={`${A}/send.svg`} />
          </Action>
        </div>
      </div>
    </div>
  )
}

function Profile({
  go,
  logout,
  mode,
  notificationCount,
  onModeChange,
  phone,
  userName = "김무브",
}: {
  go: (screen: Screen) => void
  logout: () => void
  mode: "standard" | "easy"
  notificationCount: number
  onModeChange: (mode: "standard" | "easy") => void
  phone: string
  userName?: string
}) {
  const menus = [
    {
      title: "견적내역",
      description: "받은 견적을 모아봐요",
      next: "estimates" as Screen,
    },
    {
      title: "예약내역",
      description: "지난 예약을 확인해요",
      next: "reservations" as Screen,
    },
    {
      title: "후기",
      description: "이용 후기를 작성해요",
      next: "reviews" as Screen,
    },
  ]
  return (
    <div className="screen page-with-nav">
      <Header
        go={go}
        mode={mode}
        notificationCount={notificationCount}
        onModeChange={onModeChange}
      />
      <main className="sub-content profile-content">
        <div className="page-title">더보기</div>
        <Action
          className="profile-card"
          label="내 정보 수정"
          onClick={() => go("personal")}
        >
          <div className="avatar">{userName.charAt(0)}</div>
          <div>
            <strong>{userName}님</strong>
            <span>{phone}</span>
          </div>
          <Chevron light />
        </Action>
        <div className="menu-list">
          {menus.map((item) => (
            <Action
              key={item.title}
              label={item.title}
              onClick={() => go(item.next)}
            >
              <div>
                <strong>{item.title}</strong>
                <span>{item.description}</span>
              </div>
              <Chevron />
            </Action>
          ))}
        </div>
        <Action className="logout" label="로그아웃" onClick={logout}>
          로그아웃
        </Action>
      </main>
      <BottomNav active="profile" easy={mode === "easy"} go={go} />
    </div>
  )
}

function PersonalInfo({
  go,
  onPhoneChange,
  phone,
  userName = "김무브",
}: {
  go: (screen: Screen) => void
  onPhoneChange: (phone: string) => void
  phone: string
  userName?: string
}) {
  const [showPhoneChange, setShowPhoneChange] = useState(false)
  const [nextPhone, setNextPhone] = useState("")
  const [verificationCode, setVerificationCode] = useState("")
  const [codeSent, setCodeSent] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const timerRef = useRef<number | null>(null)
  const phoneModalDragStart = useRef<number | null>(null)
  const [phoneModalDragY, setPhoneModalDragY] = useState(0)
  const nextPhoneReady = nextPhone.replace(/\D/g, "").length === 11
  const verificationReady = codeSent && verificationCode.length === 6

  const startPhoneTimer = () => {
    if (timerRef.current) window.clearInterval(timerRef.current)
    setSeconds(180)
    timerRef.current = window.setInterval(() => {
      setSeconds((current) => {
        if (current <= 1) {
          window.clearInterval(timerRef.current!)
          return 0
        }
        return current - 1
      })
    }, 1000)
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current)
    }
  }, [])

  const sendPhoneChangeCode = () => {
    setCodeSent(true)
    setVerificationCode("")
    startPhoneTimer()
  }

  const closePhoneChange = () => {
    if (timerRef.current) window.clearInterval(timerRef.current)
    phoneModalDragStart.current = null
    setPhoneModalDragY(0)
    setShowPhoneChange(false)
    setNextPhone("")
    setVerificationCode("")
    setCodeSent(false)
    setSeconds(0)
  }

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0")
  const ss = String(seconds % 60).padStart(2, "0")

  const finishPhoneModalDrag = (clientY: number) => {
    const distance =
      phoneModalDragStart.current === null
        ? 0
        : Math.max(0, clientY - phoneModalDragStart.current)
    phoneModalDragStart.current = null
    if (distance > 70) {
      closePhoneChange()
      return
    }
    setPhoneModalDragY(0)
  }

  return (
    <FormPage
      extraClass="personal-page-content"
      title="내 정보 수정"
      onBack={() => go("profile")}
    >
      <div className="personal-profile">
        <div className="personal-avatar-wrap">
          <div className="avatar">{userName.charAt(0)}</div>
          <div className="personal-verified-mark">✓</div>
        </div>
        <strong>{userName}님</strong>
        <span>본인인증 완료 · 일반 회원</span>
      </div>

      <div className="personal-section-label">기본 정보</div>
      <div className="personal-settings-card">
        <div className="personal-setting-row">
          <span>이름</span>
          <strong>{userName}</strong>
        </div>
        <div className="personal-setting-row personal-phone-row">
          <div className="personal-phone-copy">
            <span>휴대폰 번호</span>
            <span>{phone}</span>
          </div>
          <Action
            className="personal-change-button"
            label="휴대폰 번호 변경"
            onClick={() => setShowPhoneChange(true)}
          >
            변경
          </Action>
        </div>
      </div>

      <div className="linked-login-card">
        <strong>간편 로그인</strong>
        <div className="linked-login-provider">
          <img
            alt="네이버"
            className="linked-login-logo"
            src={`${A}/4a055.svg`}
          />
          <Chevron />
        </div>
      </div>

      <div className="account-meta">
        <div>
          <strong>가입일</strong>
          <b>2026. 02. 16</b>
        </div>
      </div>
      <Action
        className="withdraw-link"
        label="회원 탈퇴"
        onClick={() => undefined}
      >
        회원 탈퇴
      </Action>

      {showPhoneChange && (
        <>
          <Action
            className="personal-modal-scrim"
            label="휴대폰 번호 변경 닫기"
            onClick={closePhoneChange}
          />
          <div
            aria-labelledby="phone-change-title"
            aria-modal="true"
            className="personal-modal"
            role="dialog"
            style={{
              transform: `translate(-50%, ${phoneModalDragY}px)`,
            }}
          >
            <div
              aria-label="휴대폰 번호 변경 화면 닫기"
              className="sheet-grabber personal-sheet-grabber"
              onKeyDown={(event) => {
                if (event.key === "Enter") closePhoneChange()
              }}
              onPointerCancel={() => {
                phoneModalDragStart.current = null
                setPhoneModalDragY(0)
              }}
              onPointerDown={(event) => {
                phoneModalDragStart.current = event.clientY
                event.currentTarget.setPointerCapture(event.pointerId)
              }}
              onPointerMove={(event) => {
                if (phoneModalDragStart.current !== null) {
                  setPhoneModalDragY(
                    Math.max(0, event.clientY - phoneModalDragStart.current),
                  )
                }
              }}
              onPointerUp={(event) => finishPhoneModalDrag(event.clientY)}
              role="button"
              tabIndex={0}
            >
              <div className="sheet-handle" />
            </div>
            <div className="personal-modal-head">
              <div>
                <strong id="phone-change-title">휴대폰 번호 변경</strong>
                <span>새 번호로 본인인증을 진행해요.</span>
              </div>
              <Action
                className="personal-modal-close"
                label="닫기"
                onClick={closePhoneChange}
              >
                ×
              </Action>
            </div>
            <div className="phone-login-group phone-change-login-group">
              <Field
                formatter={(input) => {
                  const numbers = input.replace(/\D/g, "").slice(0, 11)
                  if (numbers.length <= 3) return numbers
                  if (numbers.length <= 7) {
                    return `${numbers.slice(0, 3)}-${numbers.slice(3)}`
                  }
                  return `${numbers.slice(0, 3)}-${numbers.slice(3, 7)}-${numbers.slice(7)}`
                }}
                inputMode="tel"
                label="새 휴대폰 번호"
                onValueChange={(value) => {
                  setNextPhone(value)
                  setCodeSent(false)
                  setVerificationCode("")
                  setSeconds(0)
                }}
                placeholder="새 휴대폰 번호를 입력해주세요"
                showLabel={false}
                value={nextPhone}
              />
              <Action
                className={`phone-send-button ${nextPhoneReady ? "active" : ""}`}
                disabled={!nextPhoneReady}
                label="인증하기"
                onClick={sendPhoneChangeCode}
              >
                {codeSent ? "재인증" : "인증하기"}
              </Action>
            </div>
            {codeSent && (
              <div className="phone-code-group">
                <div className="phone-code-label">
                  <span>인증번호</span>
                  <span
                    className={`phone-timer ${seconds === 0 ? "expired" : ""}`}
                  >
                    {seconds === 0 ? "시간 만료" : `${mm}:${ss}`}
                  </span>
                </div>
                <Field
                  formatter={(input) => input.replace(/\D/g, "").slice(0, 6)}
                  inputMode="numeric"
                  label="인증번호"
                  onValueChange={setVerificationCode}
                  placeholder="인증번호 6자리"
                  showLabel={false}
                  value={verificationCode}
                />
                <div className="phone-code-hint">
                  {nextPhone} 으로 인증번호가 발송되었어요.
                </div>
              </div>
            )}
            <Action
              className="form-submit next-button phone-change-confirm"
              disabled={!verificationReady}
              label="인증하고 휴대폰 번호 변경"
              onClick={() => {
                onPhoneChange(nextPhone)
                closePhoneChange()
              }}
            >
              인증하고 변경
            </Action>
          </div>
        </>
      )}
    </FormPage>
  )
}

function EstimateHistory({
  estimateStatus,
  go,
  onBack,
}: {
  estimateStatus: EstimateStatus
  go: (screen: Screen) => void
  onBack: () => void
}) {
  const [filter, setFilter] = useState<"all" | "reviewing" | "expired">("all")
  const [filterOpen, setFilterOpen] = useState(false)
  const filterDragStart = useRef<number | null>(null)
  const [filterDragY, setFilterDragY] = useState(0)
  const [filterDragging, setFilterDragging] = useState(false)
  const estimates = [
    {
      status: "reviewing" as const,
      statusLabel: "검토 중",
      date: "2026. 06. 10",
      route: "서초구 → 마포구",
      meta: "투룸 · 반포장",
    },
    {
      status: "expired" as const,
      statusLabel: "만료",
      date: "2026. 01. 24",
      route: "강남구 → 송파구",
      meta: "원룸 · 일반포장",
    },
  ]
  const filteredEstimates =
    filter === "all"
      ? estimates
      : estimates.filter((estimate) => estimate.status === filter)
  const filterLabel =
    filter === "all" ? "전체" : filter === "reviewing" ? "검토 중" : "만료"

  useEffect(() => {
    if (!filterOpen) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = previousOverflow
    }
  }, [filterOpen])

  const closeFilterSheet = () => {
    filterDragStart.current = null
    setFilterDragging(false)
    setFilterDragY(0)
    setFilterOpen(false)
  }
  const finishFilterDrag = (clientY: number) => {
    const distance =
      filterDragStart.current === null
        ? 0
        : Math.max(0, clientY - filterDragStart.current)
    filterDragStart.current = null
    setFilterDragging(false)
    if (distance > 70) {
      closeFilterSheet()
      return
    }
    setFilterDragY(0)
  }

  return (
    <FormPage
      extraClass="estimate-history-page"
      title="견적내역"
      onBack={onBack}
    >
      {estimateStatus !== "none" && (
        <Action
          className="estimate-arrived-card"
          label="도착한 견적 상세"
          onClick={() => go("estimate-detail")}
        >
          <div className="estimate-arrived-top">
            <span>견적 도착</span>
            <b>
              <svg aria-hidden="true" viewBox="0 0 20 20">
                <circle cx="10" cy="10" r="7.5" />
                <path d="M10 5.7v4.7l3.2 1.8" />
              </svg>
              2일 13시간 남음
            </b>
          </div>
          <div className="estimate-arrived-route">
            <strong>서초구 → 강동구</strong>
            <Chevron />
          </div>
          <small>5월 2일 (토) 이사 · 380,000원</small>
        </Action>
      )}

      <div className="estimate-list-head">
        <div>
          <strong>견적 목록</strong>
          <span>{estimates.length}</span>
        </div>
        <div className="estimate-filter-wrap">
          <Action
            className={
              filterOpen
                ? "estimate-filter-button open"
                : "estimate-filter-button"
            }
            label="견적 목록 필터 선택"
            onClick={() => {
              if (filterOpen) {
                closeFilterSheet()
                return
              }
              setFilterOpen(true)
            }}
          >
            {filterLabel}
            <Chevron />
          </Action>
          {filterOpen && (
            <>
              <Action
                className="reservation-filter-dismiss"
                label="견적 목록 필터 닫기"
                onClick={closeFilterSheet}
              />
              <div
                className={`reservation-filter-menu ${filterDragging ? "dragging" : ""}`}
                role="menu"
                style={{
                  transform: `translate(-50%, ${filterDragY}px)`,
                }}
              >
                <div
                  aria-label="필터 선택 화면 닫기"
                  className="reservation-filter-handle"
                  onKeyDown={(event) => {
                    if (event.key === "Enter") closeFilterSheet()
                  }}
                  onPointerCancel={() => {
                    filterDragStart.current = null
                    setFilterDragging(false)
                    setFilterDragY(0)
                  }}
                  onPointerDown={(event) => {
                    filterDragStart.current = event.clientY
                    setFilterDragging(true)
                    event.currentTarget.setPointerCapture(event.pointerId)
                  }}
                  onPointerMove={(event) => {
                    if (filterDragStart.current !== null) {
                      setFilterDragY(
                        Math.max(0, event.clientY - filterDragStart.current),
                      )
                    }
                  }}
                  onPointerUp={(event) => finishFilterDrag(event.clientY)}
                  role="button"
                  tabIndex={0}
                >
                  <span />
                </div>
                <div className="reservation-filter-options">
                  {[
                    { key: "all" as const, label: "전체" },
                    { key: "reviewing" as const, label: "검토 중" },
                    { key: "expired" as const, label: "만료" },
                  ].map((item) => (
                    <Action
                      className={filter === item.key ? "selected" : ""}
                      key={item.key}
                      label={`${item.label} 견적 보기`}
                      onClick={() => {
                        setFilter(item.key)
                        closeFilterSheet()
                      }}
                    >
                      {item.label}
                      {filter === item.key && <span>✓</span>}
                    </Action>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="estimate-history-list">
        {filteredEstimates.map((estimate) => (
          <Action
            className={`estimate-history-row ${estimate.status}`}
            key={`${estimate.status}-${estimate.date}`}
            label={`${estimate.date} ${estimate.route} 견적 상세`}
            onClick={() => go("estimate-detail")}
          >
            <div className="estimate-history-main">
              <div className="estimate-history-meta">
                <span>{estimate.statusLabel}</span>
                <small>{estimate.date}</small>
              </div>
              <strong>{estimate.route}</strong>
              <small>{estimate.meta}</small>
            </div>
            <Chevron />
          </Action>
        ))}
        {filteredEstimates.length === 0 && (
          <div className="past-reservation-empty">
            해당하는 견적 내역이 없어요.
          </div>
        )}
      </div>
    </FormPage>
  )
}

function ReservationHistory({
  backTo,
  go,
  hasUpcomingReservation,
}: {
  backTo: Screen
  go: (screen: Screen) => void
  hasUpcomingReservation: boolean
}) {
  const [pastFilter, setPastFilter] = useState<"all" | "completed" | "cancelled">("all")
  const [filterOpen, setFilterOpen] = useState(false)
  const filterDragStart = useRef<number | null>(null)
  const [filterDragY, setFilterDragY] = useState(0)
  const [filterDragging, setFilterDragging] = useState(false)

  useEffect(() => {
    if (!filterOpen) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = previousOverflow
    }
  }, [filterOpen])

  const pastReservations = [
    {
      status: "completed" as const,
      statusLabel: "완료",
      date: "2025. 11. 02",
      route: "송파구 → 성동구",
      meta: "원룸 · 반포장",
      year: "2025년",
    },
    {
      status: "completed" as const,
      statusLabel: "완료",
      date: "2025. 02. 14",
      route: "마포구 → 용산구",
      meta: "원룸 · 일반포장",
      year: "2025년",
    },
    {
      status: "cancelled" as const,
      statusLabel: "취소",
      date: "2024. 08. 21",
      route: "강동구 → 광진구",
      meta: "원룸",
      year: "2024년",
    },
  ]
  const filteredReservations = pastReservations.filter(
    (reservation) => pastFilter === "all" || reservation.status === pastFilter,
  )
  const years = [...new Set(filteredReservations.map((reservation) => reservation.year))]
  const filterLabel =
    pastFilter === "all" ? "전체" : pastFilter === "completed" ? "완료" : "취소"
  const closeFilterSheet = () => {
    filterDragStart.current = null
    setFilterDragging(false)
    setFilterDragY(0)
    setFilterOpen(false)
  }
  const finishFilterDrag = (clientY: number) => {
    const distance =
      filterDragStart.current === null
        ? 0
        : Math.max(0, clientY - filterDragStart.current)
    filterDragStart.current = null
    setFilterDragging(false)
    if (distance > 70) {
      closeFilterSheet()
      return
    }
    setFilterDragY(0)
  }

  return (
    <FormPage
      extraClass="reservation-history-page"
      title="예약내역"
      onBack={() => go(backTo)}
    >
      {hasUpcomingReservation ? (
        <Action
          className="upcoming-reservation-card"
          label="다가오는 예약 상세"
          onClick={() => go("detail")}
        >
          <div className="upcoming-reservation-top">
            <div>
              <span>확정</span>
              <b>D-30</b>
            </div>
          </div>
          <div className="upcoming-reservation-route">
            <strong>강남구 → 서초구</strong>
            <Chevron />
          </div>
          <small>3월 18일 (수) 오전 10:00 · 원룸 일반포장</small>
        </Action>
      ) : (
        <div className="reservation-empty">
          <strong>예정된 예약이 없습니다.</strong>
          <span>견적을 확정하면 예약 일정이 여기에 표시됩니다.</span>
        </div>
      )}
      <div className="reservation-past-head">
        <div className="reservation-past-title">
          <strong>지난 이사</strong>
          <span>{pastReservations.length}</span>
        </div>
        <div className="reservation-filter-wrap">
          <Action
            className={`reservation-filter-button ${filterOpen ? "open" : ""}`}
            label="지난 이사 필터 선택"
            onClick={() => {
              if (filterOpen) {
                closeFilterSheet()
                return
              }
              setFilterOpen(true)
            }}
          >
            {filterLabel}
            <Chevron />
          </Action>
          {filterOpen && (
            <>
              <Action
                className="reservation-filter-dismiss"
                label="지난 이사 필터 닫기"
                onClick={closeFilterSheet}
              />
              <div
                className={`reservation-filter-menu ${filterDragging ? "dragging" : ""}`}
                role="menu"
                style={{
                  transform: `translate(-50%, ${filterDragY}px)`,
                }}
              >
                <div
                  aria-label="필터 선택 화면 닫기"
                  className="reservation-filter-handle"
                  onKeyDown={(event) => {
                    if (event.key === "Enter") closeFilterSheet()
                  }}
                  onPointerCancel={() => {
                    filterDragStart.current = null
                    setFilterDragging(false)
                    setFilterDragY(0)
                  }}
                  onPointerDown={(event) => {
                    filterDragStart.current = event.clientY
                    setFilterDragging(true)
                    event.currentTarget.setPointerCapture(event.pointerId)
                  }}
                  onPointerMove={(event) => {
                    if (filterDragStart.current !== null) {
                      setFilterDragY(
                        Math.max(0, event.clientY - filterDragStart.current),
                      )
                    }
                  }}
                  onPointerUp={(event) => finishFilterDrag(event.clientY)}
                  role="button"
                  tabIndex={0}
                >
                  <span />
                </div>
                <div className="reservation-filter-options">
                  {[
                    { key: "all" as const, label: "전체" },
                    { key: "completed" as const, label: "완료" },
                    { key: "cancelled" as const, label: "취소" },
                  ].map((item) => (
                    <Action
                      className={pastFilter === item.key ? "selected" : ""}
                      key={item.key}
                      label={`${item.label} 이사 보기`}
                      onClick={() => {
                        setPastFilter(item.key)
                        closeFilterSheet()
                      }}
                    >
                      {item.label}
                      {pastFilter === item.key && <span>✓</span>}
                    </Action>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      <div className="past-reservation-list">
        {years.map((year) => (
          <section className="past-reservation-year" key={year}>
            <div className="past-reservation-year-label">{year}</div>
            {filteredReservations
              .filter((reservation) => reservation.year === year)
              .map((reservation) => (
                <Action
                  className={`past-booking ${reservation.status}`}
                  key={`${reservation.date}-${reservation.route}`}
                  label={`${reservation.date} ${reservation.route} 예약 상세`}
                  onClick={() => go("detail")}
                >
                  <div className="past-booking-main">
                    <div className="past-booking-meta">
                      <span>{reservation.statusLabel}</span>
                      <small>{reservation.date}</small>
                    </div>
                    <strong>{reservation.route}</strong>
                    <small>{reservation.meta}</small>
                  </div>
                  <Chevron />
                </Action>
              ))}
          </section>
        ))}
        {filteredReservations.length === 0 && (
          <div className="past-reservation-empty">해당하는 예약 내역이 없어요.</div>
        )}
      </div>
    </FormPage>
  )
}

function ReviewHistory({
  backTo,
  go,
}: {
  backTo: Screen
  go: (screen: Screen) => void
}) {
  const [writing, setWriting] = useState(false)
  const [rating, setRating] = useState(5)
  const [submitted, setSubmitted] = useState(false)
  const [reviewText, setReviewText] = useState("")
  const [reviewPhotos, setReviewPhotos] = useState<{ id: string; name: string; src: string }[]>([])
  const reviewPhotoInputRef = useRef<HTMLInputElement>(null)

  return (
    <FormPage
      extraClass="review-history-page"
      title="후기"
      onBack={() => {
        if (writing) {
          setWriting(false)
          return
        }
        go(backTo)
      }}
    >
      {!writing ? (
        <>
          <Action
            className="review-prompt"
            label="3월 18일 이사 후기 작성"
            onClick={() => setWriting(true)}
          >
            <div className="review-prompt-meta">
              <span>후기 작성</span>
              <small>3월 18일 이사</small>
            </div>
            <strong>
              강남구 <i>→</i> 서초구
            </strong>
            <p>서비스는 만족스러우셨나요?</p>
            <Chevron />
          </Action>
          <div className="history-label review-history-label">
            <strong>내가 쓴 후기</strong>
            <span>{submitted ? 2 : 1}</span>
          </div>
          {submitted && (
            <div className="my-review submitted-review">
              <div className="my-review-head">
                <span>
                  {"★".repeat(rating)}
                  {"☆".repeat(5 - rating)}
                </span>
                <small>방금 전</small>
              </div>
              <strong>강남구 → 서초구</strong>
              <div className="my-review-copy">
                <p>{reviewText || "친절하고 안전하게 이사를 마쳤어요."}</p>
                <Chevron />
              </div>
              <small className="my-review-type">원룸 · 일반포장</small>
              {reviewPhotos.length > 0 && (
                <div className="my-review-photos">
                  {reviewPhotos.map((photo) => (
                    <img alt={photo.name} key={photo.id} src={photo.src} />
                  ))}
                </div>
              )}
            </div>
          )}
          <div className="my-review">
            <div className="my-review-head">
              <span>★★★★★</span>
              <small>2025. 11. 03</small>
            </div>
            <strong>송파구 → 성동구</strong>
            <div className="my-review-copy">
              <p>친절하게 응대해주시고 꼼꼼히 챙겨주셔서 편하게 이사했습니다.</p>
              <Chevron />
            </div>
            <small className="my-review-type">원룸 · 반포장</small>
          </div>
        </>
      ) : (
        <div className="review-compose">
          <div className="compose-title">이사 서비스는 어떠셨나요?</div>
          <div className="review-auto-info">
            <div>
              <span>예약 정보에서 자동 적용</span>
              <strong>강남구 → 서초구</strong>
            </div>
            <div className="review-auto-tags">
              <span>이용 3회차</span>
              <span>원룸(일반포장)</span>
              <span>2026. 03. 18</span>
            </div>
          </div>
          <div className="rating-row">
            {[1, 2, 3, 4, 5].map((star) => (
              <Action
                key={star}
                label={`${star}점`}
                onClick={() => setRating(star)}
              >
                <span className={star <= rating ? "rated" : ""}>★</span>
              </Action>
            ))}
          </div>
          <div
            aria-label="후기 내용"
            className="review-editor"
            contentEditable
            data-placeholder="이사 경험을 자세히 들려주세요."
            onInput={(event) => setReviewText(event.currentTarget.innerText)}
            role="textbox"
            suppressContentEditableWarning
          />
          <div className="review-photo-head">
            <div>
              <strong>사진 첨부</strong>
              <span>선택 · 최대 5장</span>
            </div>
            <b>{reviewPhotos.length}/5</b>
          </div>
          <input
            accept="image/jpeg,image/png,image/webp"
            className="review-photo-input"
            multiple
            onChange={(event) => {
              const remaining = 5 - reviewPhotos.length
              const files = Array.from(event.target.files ?? []).slice(0, remaining)
              files.forEach((file, index) => {
                const reader = new FileReader()
                reader.onload = () => {
                  if (typeof reader.result !== "string") return
                  setReviewPhotos((photos) => [
                    ...photos,
                    {
                      id: `${file.name}-${file.lastModified}-${Date.now()}-${index}`,
                      name: file.name,
                      src: reader.result,
                    },
                  ].slice(0, 5))
                }
                reader.readAsDataURL(file)
              })
              event.currentTarget.value = ""
            }}
            ref={reviewPhotoInputRef}
            type="file"
          />
          <div className="review-photo-grid">
            {reviewPhotos.map((photo) => (
              <div className="review-photo-preview" key={photo.id}>
                <img alt={photo.name} src={photo.src} />
                <Action
                  className="review-photo-remove"
                  label={`${photo.name} 삭제`}
                  onClick={() => setReviewPhotos((photos) => photos.filter((item) => item.id !== photo.id))}
                >
                  ×
                </Action>
              </div>
            ))}
            {reviewPhotos.length < 5 && (
              <Action
                className="review-photo-add"
                label="후기 사진 추가"
                onClick={() => reviewPhotoInputRef.current?.click()}
              >
                <img alt="" src={`${A}/cd80e.svg`} />
                <span>사진 추가</span>
              </Action>
            )}
          </div>
          <div className="review-photo-help">
            이삿짐 상태나 서비스 현장을 담은 사진을 추가하면 더 유용한 후기가 돼요.
          </div>
          <Action
            className="form-submit primary"
            label="후기 등록"
            onClick={() => {
              setSubmitted(true)
              setWriting(false)
            }}
          >
            후기 등록
          </Action>
        </div>
      )}
      {submitted && <div className="save-toast">후기가 등록되었어요.</div>}
    </FormPage>
  )
}

function NotificationIllustration({ type }: { type: string }) {
  if (type === "예약/일정 정보") {
    return (
      <svg aria-hidden="true" fill="none" viewBox="0 0 44 44">
        <rect fill="#EEF4F0" height="44" rx="13" width="44" />
        <rect fill="white" height="25" rx="4" width="27" x="8.5" y="10.5" />
        <path d="M8.5 16.5h27" stroke="#346538" strokeWidth="3" />
        <path d="M15 8.5v4M29 8.5v4" stroke="#346538" strokeLinecap="round" strokeWidth="2" />
        <path d="m16 26 3 3 8-8" stroke="#F5831A" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
      </svg>
    )
  }

  if (type === "견적 정보") {
    return (
      <svg aria-hidden="true" fill="none" viewBox="0 0 44 44">
        <rect fill="#F3F0FF" height="44" rx="13" width="44" />
        <path d="M9 12a3 3 0 0 1 3-3h18l5 5v20a3 3 0 0 1-3 3H12a3 3 0 0 1-3-3V12Z" fill="white" />
        <path d="M30 9v4a2 2 0 0 0 2 2h3" fill="#DCD8F6" />
        <path d="M15 19h11M15 23h8M15 27h10" stroke="#7568D9" strokeLinecap="round" strokeWidth="2" />
        <circle cx="32.5" cy="31.5" fill="#F5831A" r="7.5" />
        <path d="m29 31.5 2.2 2.2 4.3-4.4" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
      </svg>
    )
  }

  if (type === "결제 정보") {
    return (
      <svg aria-hidden="true" fill="none" viewBox="0 0 44 44">
        <rect fill="#FFFBF0" height="44" rx="13" width="44" />
        <rect fill="#F5C65D" height="22" rx="5" width="29" x="7.5" y="12" />
        <path d="M7.5 18h29" stroke="#D99A2B" strokeWidth="3" />
        <circle cx="31.5" cy="31.5" fill="#65BFA8" r="7.5" />
        <path d="m28 31.5 2.2 2.2 4.3-4.4" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
      </svg>
    )
  }

  return (
    <svg aria-hidden="true" fill="none" viewBox="0 0 44 44">
      <rect fill="#F0F7FF" height="44" rx="13" width="44" />
      <path d="M7.5 13.5c0-2.2 1.8-4 4-4h15c2.2 0 4 1.8 4 4v10c0 2.2-1.8 4-4 4H18l-6 5v-5h-.5c-2.2 0-4-1.8-4-4v-10Z" fill="#6CA8E8" />
      <circle cx="15" cy="18.5" fill="white" r="1.5" />
      <circle cx="20" cy="18.5" fill="white" r="1.5" />
      <circle cx="25" cy="18.5" fill="white" r="1.5" />
      <path d="M25 30h8.5c1.7 0 3-1.3 3-3v-8c0-1.7-1.3-3-3-3h-1" stroke="#7568D9" strokeLinecap="round" strokeWidth="2" />
    </svg>
  )
}

function Notifications({
  go,
  onBack,
  unread,
  setUnread,
}: {
  go: (screen: Screen) => void
  onBack: () => void
  unread: Set<number>
  setUnread: React.Dispatch<React.SetStateAction<Set<number>>>
}) {
  const alerts = [
    {
      id: 1,
      type: "예약/일정 정보",
      title: "이사 예약이 확정되었어요",
      body: "3월 18일 오전 10시 예약과 방문 주소를 확인해주세요.",
      time: "14시간 전",
    },
    {
      id: 2,
      type: "이야기",
      title: "새로운 이야기가 등록됐어요",
      body: "이사 전날 꼭 확인해야 할 준비 체크리스트를 살펴보세요.",
      time: "하루 전",
    },
    {
      id: 3,
      type: "견적 정보",
      title: "새로운 견적이 도착했어요",
      body: "회원님의 이사 조건에 맞는 업체 견적을 비교해보세요.",
      time: "2일 전",
    },
    {
      id: 4,
      type: "예약/일정 정보",
      title: "이사 일정이 가까워지고 있어요",
      body: "이사까지 30일 남았어요. 준비 체크리스트를 확인해주세요.",
      time: "3일 전",
    },
    {
      id: 5,
      type: "결제 정보",
      title: "예약금 결제가 완료되었어요",
      body: "결제 내역과 남은 결제 일정을 확인할 수 있어요.",
      time: "5일 전",
    },
    {
      id: 6,
      type: "이야기",
      title: "새로운 이사 팁이 도착했어요",
      body: "주소 이전과 공과금 정산을 미리 준비해보세요.",
      time: "7일 전",
    },
  ]
  const categories = [
    "전체알림",
    "예약/일정 정보",
    "견적 정보",
    "결제 정보",
    "이야기",
  ]
  const [filter, setFilter] = useState("전체알림")
  const [filterOpen, setFilterOpen] = useState(false)
  const visibleAlerts =
    filter === "전체알림"
      ? alerts
      : alerts.filter((alert) => alert.type === filter)

  const readAlert = (id: number) => {
    setUnread((current) => {
      const next = new Set(current)
      next.delete(id)
      return next
    })
  }

  return (
    <div className="screen notifications-screen">
      <div className="notification-header">
        <Back onClick={onBack} />
        <div>알림</div>
        <Action label="모두 읽음" onClick={() => setUnread(new Set())}>
          모두읽음
        </Action>
      </div>
      <div className="notification-controls">
        <span>읽지 않은 알림 {unread.size}건</span>
        <Action label="알림 종류 선택" onClick={() => setFilterOpen(true)}>
          {filter}
          <Chevron />
        </Action>
      </div>
      <div className="notification-day">어제</div>
      <div className="notification-feed">
        {visibleAlerts.map((alert) => (
          <Action
            className={
              unread.has(alert.id)
                ? "notification-row unread"
                : "notification-row"
            }
            key={alert.id}
            label={alert.title}
            onClick={() => readAlert(alert.id)}
          >
            <div className="notification-type-icon">
              <NotificationIllustration type={alert.type} />
            </div>
            <div className="notification-copy">
              <strong>{alert.title}</strong>
              <p>{alert.body}</p>
              <small>{alert.time}</small>
            </div>
            {unread.has(alert.id) && <i />}
          </Action>
        ))}
      </div>
      {filterOpen && (
        <>
          <div
            className="notification-sheet-scrim"
            onClick={() => setFilterOpen(false)}
          />
          <div className="notification-filter-sheet">
            <div className="notification-sheet-head">
              <strong>보고싶은 알림 선택</strong>
              <Action
                label="알림 선택 닫기"
                onClick={() => setFilterOpen(false)}
              >
                ×
              </Action>
            </div>
            <div className="notification-categories">
              {categories.map((category) => (
                <Action
                  className={filter === category ? "selected" : ""}
                  key={category}
                  label={category}
                  onClick={() => {
                    setFilter(category)
                    setFilterOpen(false)
                  }}
                >
                  <span>{category}</span>
                  {filter === category && <b>✓</b>}
                </Action>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function Detail({
  backTo,
  go,
  onCancelReservation,
}: {
  backTo: Screen
  go: (screen: Screen) => void
  onCancelReservation: () => void
}) {
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [paymentOpen, setPaymentOpen] = useState(false)
  const [requestEditing, setRequestEditing] = useState(false)
  const [requestText, setRequestText] = useState(
    "냉장고는 전날 비워둘게요. 도착지 주차는 지하 2층에 가능합니다.",
  )
  const [detailToast, setDetailToast] = useState("")

  const showDetailToast = (message: string) => {
    setDetailToast(message)
    window.setTimeout(() => setDetailToast(""), 2200)
  }

  return (
    <FormPage
      extraClass="reservation-detail-page"
      title="예약 상세"
      onBack={() => go(backTo)}
    >
      <div className="reservation-detail-hero">
        <span>확정 · D-30</span>
        <strong>안전하고 편안한 이사를 준비할게요</strong>
        <small>예약 번호 ME-20260318-1042</small>
      </div>

      <div className="reservation-info-card">
        <div className="reservation-address-row">
          <i className="reservation-address-dot from" />
          <div>
            <span>출발지</span>
            <strong>서울 강남구 테헤란로 123, 301호</strong>
          </div>
        </div>
        <div className="reservation-address-row">
          <i className="reservation-address-dot to" />
          <div>
            <span>도착지</span>
            <strong>서울 서초구 서초대로 456, 804호</strong>
          </div>
        </div>
        <div className="reservation-info-row">
          <span>이사 일시</span>
          <b>2026. 03. 18 (수) 오전 10:00</b>
        </div>
        <div className="reservation-info-row">
          <span>이사 유형</span>
          <b>원룸 · 일반포장</b>
        </div>
        <div className="reservation-payment">
          <Action
            className="reservation-payment-toggle"
            label={`결제 금액 상세 ${paymentOpen ? "접기" : "펼치기"}`}
            onClick={() => setPaymentOpen((current) => !current)}
          >
            <span>결제 금액</span>
            <div>
              <b>410,000원</b>
              <svg
                aria-hidden="true"
                className={paymentOpen ? "open" : ""}
                viewBox="0 0 24 24"
              >
                <path d="m7 10 5 5 5-5" />
              </svg>
            </div>
          </Action>
          {paymentOpen && (
            <div className="reservation-payment-details">
              <div>
                <span>기본 운반 (원룸)</span>
                <b>250,000원</b>
              </div>
              <div>
                <span>일반포장</span>
                <b>120,000원</b>
              </div>
              <div>
                <span>사다리차 (도착지)</span>
                <b>40,000원</b>
              </div>
              <div className="reservation-payment-status">
                <span>계약금</span>
                <b>41,000원 · 결제 완료</b>
              </div>
              <div>
                <span>잔금</span>
                <b>369,000원 · 이사 당일 결제</b>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="reservation-request-section">
        <div className="reservation-section-head">
          <strong>요청사항</strong>
          <Action
            label={requestEditing ? "요청사항 저장" : "요청사항 수정"}
            onClick={() => {
              if (requestEditing) showDetailToast("요청사항을 저장했어요.")
              setRequestEditing((current) => !current)
            }}
          >
            {requestEditing ? "저장" : "수정"}
          </Action>
        </div>
        {requestEditing ? (
          <div
            aria-label="요청사항"
            className="reservation-request-card editing"
            contentEditable
            onInput={(event) =>
              setRequestText(event.currentTarget.textContent ?? "")
            }
            role="textbox"
            suppressContentEditableWarning
          >
            {requestText}
          </div>
        ) : (
          <p className="reservation-request-card">{requestText}</p>
        )}
      </div>

      <div className="reservation-detail-actions">
        <Action
          className="reservation-contact-button"
          label="업체에 문의하기"
          onClick={() => go("chat")}
        >
          업체에 문의하기
        </Action>
        <div className="reservation-secondary-actions">
          <Action label="예약 취소" onClick={() => setShowCancelModal(true)}>
            예약 취소
          </Action>
        </div>
      </div>
      {detailToast && <div className="save-toast">{detailToast}</div>}
      {showCancelModal && (
        <>
          <div
            className="reservation-cancel-scrim"
            onClick={() => setShowCancelModal(false)}
          />
          <div
            aria-describedby="reservation-cancel-description"
            aria-labelledby="reservation-cancel-title"
            aria-modal="true"
            className="reservation-cancel-modal"
            role="dialog"
          >
            <div className="reservation-cancel-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path d="M12 8.2v4.6M12 16.2h.01" />
                <path d="M10.3 4.7 3.5 16.5A2 2 0 0 0 5.2 19h13.6a2 2 0 0 0 1.7-2.5L13.7 4.7a2 2 0 0 0-3.4 0Z" />
              </svg>
            </div>
            <strong id="reservation-cancel-title">
              예약을 취소하시겠어요?
            </strong>
            <span id="reservation-cancel-description">
              취소하면 확정된 일정이 사라지며<br />
              다시 예약하려면 견적을 새로 확정해야 해요.
            </span>
            <div className="reservation-cancel-summary">
              <span>취소할 예약</span>
              <b>3월 18일 오전 10:00</b>
            </div>
            <div className="reservation-cancel-actions">
              <Action
                className="reservation-cancel-back"
                label="예약 취소하지 않고 돌아가기"
                onClick={() => setShowCancelModal(false)}
              >
                유지하기
              </Action>
              <Action
                className="reservation-cancel-confirm"
                label="예약 취소 확인"
                onClick={onCancelReservation}
              >
                예약 취소
              </Action>
            </div>
          </div>
        </>
      )}
    </FormPage>
  )
}

function DetectedItemIcon({ kind }: { kind: string }) {
  return (
    <svg
      aria-hidden="true"
      fill="none"
      height="20"
      viewBox="0 0 24 24"
      width="20"
      xmlns="http://www.w3.org/2000/svg"
    >
      {kind === "sofa" && (
        <>
          <path d="M5 11V8.5A2.5 2.5 0 0 1 7.5 6h9A2.5 2.5 0 0 1 19 8.5V11" />
          <path d="M4 10.5A2 2 0 0 0 2 12.5V17h20v-4.5a2 2 0 0 0-2-2M5 17v2m14-2v2" />
        </>
      )}
      {kind === "bed" && (
        <>
          <path d="M3 18V7m0 7h18v4M7 14V9h8a4 4 0 0 1 4 4v1" />
          <path d="M3 10h4" />
        </>
      )}
      {kind === "tv" && (
        <>
          <rect height="12" rx="1.5" width="18" x="3" y="4" />
          <path d="m9 20 3-4 3 4M7 20h10" />
        </>
      )}
      {kind === "table" && (
        <>
          <path d="M4 8h16M6 8v11m12-11v11M8 5h8" />
          <path d="M3 12h3m12 0h3" />
        </>
      )}
      {kind === "wardrobe" && (
        <>
          <rect height="18" rx="1.5" width="14" x="5" y="3" />
          <path d="M12 3v18m-2-9h.01m4 0h.01" />
        </>
      )}
      {kind === "box" && (
        <>
          <path d="m4 7 8-4 8 4-8 4-8-4Z" />
          <path d="M4 7v10l8 4 8-4V7M12 11v10" />
        </>
      )}
    </svg>
  )
}

function EstimateDetail({
  estimateStatus,
  go,
  onBack,
  onConfirmEstimate,
}: {
  estimateStatus: EstimateStatus
  go: (screen: Screen) => void
  onBack: () => void
  onConfirmEstimate: () => void
}) {
  const [aiStep, setAiStep] = useState<"idle" | "uploading" | "analyzing" | "done">("done")
  const [detailTab, setDetailTab] = useState<"quote" | "analysis" | "move">("quote")
  const [showVendorEstimate, setShowVendorEstimate] = useState(false)
  const [vendorZoom, setVendorZoom] = useState(75)
  const vendorDocumentDrag = useDragScroll()
  const confirmed = estimateStatus === "confirmed"

  const detectedItems = [
    { icon: "item-sofa.svg", name: "소파 3인용", count: 1, cbm: "1.2" },
    { icon: "item-bed.svg", name: "퀸 침대 프레임", count: 1, cbm: "1.8" },
    { icon: "item-tv.svg", name: "TV 55인치", count: 1, cbm: "0.4" },
    { icon: "item-table.svg", name: "식탁 + 의자 4개", count: 1, cbm: "0.9" },
    { icon: "item-wardrobe.svg", name: "장롱 (3단)", count: 1, cbm: "1.6" },
    { icon: "item-box.svg", name: "기타 박스류", count: 12, cbm: "1.8" },
  ]
  const vendorEstimateItems = [
    ["냉장고", "1", "침대", "1", "이사박스", "12", "화분", "3"],
    ["세탁기", "1", "소파", "1", "생활짐", "1식", "행거", "2"],
    ["TV", "1", "테이블", "1", "의류", "1식", "기타", "1식"],
  ]

  return (
    <FormPage
      extraClass="estimate-detail-page"
      title="견적 상세"
      onBack={onBack}
    >
      {/* 상태 헤더 */}
      <div className="detail-status estimate-detail-status">
        <div className="estimate-detail-status-top">
          <span>{confirmed ? "예약 완료" : "견적 도착"}</span>
          <small>QT-20260310-0042</small>
        </div>
        <div className="estimate-detail-primary">
          <div>
            <strong>명품익스프레스</strong>
            <p>강남구 → 서초구</p>
          </div>
          <b>410,000원</b>
        </div>
        <div className="estimate-detail-date">2026. 03. 18 (월) · 오전 10:00</div>
      </div>

      <div className="estimate-detail-tabs">
        {[
          { key: "quote" as const, label: "견적 금액" },
          { key: "analysis" as const, label: "AI 분석" },
          { key: "move" as const, label: "이사 정보" },
        ].map((tab) => (
          <Action
            className={detailTab === tab.key ? "active" : ""}
            key={tab.key}
            label={tab.label}
            onClick={() => setDetailTab(tab.key)}
          >
            {tab.label}
          </Action>
        ))}
      </div>

      {/* AI 동영상 견적 섹션 */}
      {detailTab === "analysis" && <div className="ai-estimate-section">
        <div className="ai-estimate-header">
          <div className="ai-estimate-logo">
            <img alt="" src={`${A}/cd80e.svg`} />
          </div>
          <div>
            <b>AI 동영상 부피 견적</b>
            <span>촬영 영상에서 가구·가전을 인식해 CBM을 자동 계산했어요.</span>
          </div>
        </div>

        {/* 업로드 + 흐름 */}
        {aiStep === "idle" && (
          <Action className="ai-upload-zone" label="동영상 업로드" onClick={() => { setAiStep("uploading"); setTimeout(() => setAiStep("analyzing"), 1200); setTimeout(() => setAiStep("done"), 2800) }}>
            <svg fill="none" height="32" viewBox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 22V10M10 16l6-6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8"/>
              <rect height="24" rx="4" stroke="currentColor" strokeDasharray="4 3" strokeWidth="1.4" width="24" x="4" y="4"/>
            </svg>
            <span>동영상 파일을 업로드하세요</span>
            <small>MP4, MOV · 최대 500MB</small>
          </Action>
        )}

        {aiStep === "uploading" && (
          <div className="ai-progress-state">
            <div className="ai-progress-spinner" />
            <span>동영상 업로드 중...</span>
          </div>
        )}

        {aiStep === "analyzing" && (
          <div className="ai-progress-state analyzing">
            <div className="ai-progress-spinner green" />
            <span>AI가 공간을 분석하고 있어요...</span>
            <small>가구·가전 인식 · 부피 계산 중</small>
          </div>
        )}

        {aiStep === "done" && (
          <>
            {/* CBM 결과 */}
            <div className="ai-cbm-result">
              <div className="ai-cbm-main">
                <span>총 산출 부피</span>
                <b>7.7 CBM</b>
              </div>
              <div className="ai-cbm-sub">
                <div><small>인식 품목</small><b>6종</b></div>
                <div className="ai-cbm-divider" />
                <div><small>분석 시간</small><b>38초</b></div>
                <div className="ai-cbm-divider" />
                <div><small>정확도</small><b>94%</b></div>
              </div>
            </div>

            {/* 인식된 품목 리스트 */}
            <div className="ai-items-label">인식된 품목</div>
            <div className="ai-items-list">
              {detectedItems.map((item) => (
                <div className="ai-item-row" key={item.name}>
                  <span className="ai-item-icon"><img alt="" src={`${A}/${item.icon}`} /></span>
                  <span className="ai-item-name">{item.name}</span>
                  <span className="ai-item-count">×{item.count}</span>
                  <b className="ai-item-cbm">{item.cbm} CBM</b>
                </div>
              ))}
            </div>

            <Action className="ai-reupload" label="재업로드" onClick={() => setAiStep("idle")}>
              <svg fill="none" height="13" viewBox="0 0 16 16" width="13" xmlns="http://www.w3.org/2000/svg"><path d="M2 8a6 6 0 1 0 1.2-3.6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5"/><path d="M2 4v4h4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"/></svg>
              다시 업로드
            </Action>
          </>
        )}
      </div>}

      {/* 영수증 */}
      {detailTab === "quote" && <>
      <section className="estimate-receipt" aria-labelledby="estimate-receipt-title">
        <div className="estimate-receipt-header">
          <div>
            <small>PREMIUM EXPRESS</small>
            <h2 id="estimate-receipt-title">이사 견적서</h2>
          </div>
          <span>선택 완료</span>
        </div>
        <div className="estimate-receipt-meta">
          <span>No. QT-20260310-0042</span>
          <span>2026. 03. 10 발행</span>
        </div>
        <div className="estimate-receipt-rule" />
        {[
          { label: "기본 운송비", value: "250,000" },
          { label: "포장·인력 등 작업비", value: "140,000" },
          { label: "도착지 사다리차 비용 (8층)", value: "20,000" },
        ].map((r) => (
          <div className="estimate-receipt-row" key={r.label}>
            <span>{r.label}</span>
            <b>{r.value}원</b>
          </div>
        ))}
        <div className="estimate-receipt-total">
          <span>최종 견적 금액<small>부가세 포함</small></span>
          <b>410,000원</b>
        </div>
        <div className="estimate-receipt-foot">
          <svg fill="none" height="13" viewBox="0 0 16 16" width="13" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3"/><path d="M8 5v3.5L10 10" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3"/></svg>
          CBM 기반 자동 산출 · 7.7 CBM
        </div>
      </section>
      <Action
        className="estimate-document-button"
        label="업체 견적서 원본 보기"
        onClick={() => setShowVendorEstimate(true)}
      >
        <img alt="" src={`${A}/vendor-document-illustration.svg`} />
        <div>
          <strong>업체 견적서 원본</strong>
          <span>명품익스프레스가 발행한 상세 견적서를 확인해요.</span>
        </div>
        <Chevron />
      </Action>
      </>}

      {/* 이사 정보 */}
      {detailTab === "move" && <section className="estimate-move-info">
        <h2>이사 정보</h2>
        {[
          { label: "견적 번호", value: "QT-20260310-0042" },
          { label: "이사일", value: "2026. 03. 18 오전 10:00" },
          { label: "이사 유형", value: "원룸 · 일반포장" },
          { label: "출발지", value: "서울 강남구 테헤란로 123, 301호" },
          { label: "도착지", value: "서울 서초구 서초대로 456, 804호" },
        ].map((r) => (
          <div key={r.label}><span>{r.label}</span><b>{r.value}</b></div>
        ))}
      </section>}

      <Action
        className={`primary form-submit estimate-confirm${confirmed ? " is-disabled" : ""}`}
        disabled={confirmed}
        label="견적 확정"
        onClick={onConfirmEstimate}
      >
        {confirmed ? "견적 확정 완료" : "이 견적으로 확정하기"}
      </Action>
      {showVendorEstimate && (
        <>
          <div className="scrim" onClick={() => setShowVendorEstimate(false)} style={{ zIndex: 60 }} />
          <div className="quote-doc-sheet">
            <div className="quote-doc-head">
              <div className="quote-doc-head-left">
                <strong>명품익스프레스 견적서</strong>
                <span>QT-20260310-0042</span>
              </div>
              <div className="quote-doc-tools">
                <div className="quote-zoom-controls" aria-label="견적서 배율 조절">
                  <Action
                    className="quote-zoom-button"
                    disabled={vendorZoom <= 50}
                    label="견적서 축소"
                    onClick={() => setVendorZoom((zoom) => Math.max(50, zoom - 25))}
                  >
                    −
                  </Action>
                  <Action
                    className="quote-zoom-value"
                    label="견적서 배율 100%로 초기화"
                    onClick={() => setVendorZoom(100)}
                  >
                    {vendorZoom}%
                  </Action>
                  <Action
                    className="quote-zoom-button"
                    disabled={vendorZoom >= 150}
                    label="견적서 확대"
                    onClick={() => setVendorZoom((zoom) => Math.min(150, zoom + 25))}
                  >
                    +
                  </Action>
                </div>
                <Action className="quote-doc-close" label="닫기" onClick={() => setShowVendorEstimate(false)}>×</Action>
              </div>
            </div>
            <div
              className={vendorDocumentDrag.isDragging ? "quote-doc-body designed-scroll is-dragging" : "quote-doc-body designed-scroll"}
              onPointerCancel={vendorDocumentDrag.onPointerCancel}
              onPointerDown={vendorDocumentDrag.onPointerDown}
              onPointerMove={vendorDocumentDrag.onPointerMove}
              onPointerUp={vendorDocumentDrag.onPointerUp}
              ref={vendorDocumentDrag.ref}
            >
              <div className="quote-pan-hint">손가락이나 마우스로 문서를 끌어 이동하세요</div>
              <div
                className="vendor-estimate"
                style={{ "--quote-zoom": vendorZoom / 100 } as React.CSSProperties}
              >
                <div className="vendor-estimate-top">
                  <div className="vendor-brand">
                    <strong>명품 익스프레스</strong>
                    <span>포장이사 전문업체 관허 2015-7호</span>
                    <span>(피해보상)보증보험 가입</span>
                  </div>
                  <div className="vendor-doc-title">
                    <strong>견적서 / 계약서</strong>
                    <span>(ESTIMATE REPORT)</span>
                  </div>
                  <div className="vendor-registration">
                    <div><b>등록 번호</b><span>398-51-00044</span></div>
                    <div><b>사무실전화</b><span>062) 252-0303</span></div>
                    <div><b>대표자전화</b><span>010-9445-8224</span></div>
                  </div>
                </div>
                <div className="vendor-customer-grid">
                  <b>업체명</b><span>명품 익스프레스</span>
                  <b>담당자</b><span>김선국 (님)</span>
                  <b>TEL</b><span>010-9445-8224</span>
                  <b>견적일</b><span>2026. 03. 10.</span>
                  <b>출발지</b><span>서울 강남구 테헤란로 123, 301호</span>
                  <b>작업일</b><span>2026. 03. 18.</span>
                  <b>도착지</b><span>서울 서초구 서초대로 456, 804호</span>
                  <b>운송일</b><span>2026. 03. 18.</span>
                </div>
                <div className="vendor-items">
                  <div className="vendor-items-groups">
                    <b>전자기기</b><b>가구</b><b>생활용품</b><b>기타</b>
                  </div>
                  <div className="vendor-items-head">
                    {Array.from({ length: 4 }).map((_, index) => (
                      <React.Fragment key={index}><b>품목</b><b>수량</b></React.Fragment>
                    ))}
                  </div>
                  {vendorEstimateItems.map((row, index) => (
                    <div className="vendor-items-row" key={index}>
                      {row.map((cell, cellIndex) => <span key={cellIndex}>{cell}</span>)}
                    </div>
                  ))}
                  {Array.from({
                    length: Math.max(0, 8 - vendorEstimateItems.length),
                  }).map((_, index) => (
                    <div className="vendor-items-row" key={`empty-${index}`}>
                      {Array.from({ length: 8 }).map((__, cellIndex) => (
                        <span key={cellIndex} />
                      ))}
                    </div>
                  ))}
                </div>
                <div className="vendor-work-grid">
                  <b className="vendor-vertical-label">작업 정보</b>
                  <div className="vendor-options">
                    <span>벽걸이TV　탈착 ■ / 설치 ■　₩ 20,000</span>
                    <span>에어컨　탈착 □ / 설치 □　₩ 0</span>
                    <span>파손주의 품목 별도 포장</span>
                  </div>
                  <div className="vendor-work-details">
                    <div><b>작업내용</b><span>일반포장</span></div>
                    <div><b>운반방법</b><span>승강기 전 ■ / 후 ■</span></div>
                    <div><b>이사물량</b><span>7.7 CBM</span></div>
                    <div><b>비고</b><span>현장 확인 후 조정 가능</span></div>
                  </div>
                </div>
                <div className="vendor-cost-grid">
                  <div className="vendor-cost-column">
                    <b>A. 작업 비용</b>
                    <div><span>이사비용</span><strong>₩ 390,000</strong></div>
                    <div><span>사다리비용</span><strong>₩ 0</strong></div>
                    <div className="vendor-cost-total"><span>총 비용</span><strong>₩ 410,000</strong></div>
                  </div>
                  <div className="vendor-cost-column">
                    <b>B. 별도 비용</b>
                    <div><span>출발지 사다리(3)층</span><strong>₩ 0</strong></div>
                    <div><span>도착지 사다리(8)층</span><strong>₩ 20,000</strong></div>
                    <div className="vendor-cost-total"><span>사다리 소계</span><strong>₩ 20,000</strong></div>
                  </div>
                </div>
                <div className="vendor-payment-grid">
                  <b>계약금 10%</b><span>₩ 41,000</span>
                  <b className="vendor-balance-label">잔금</b><span className="vendor-balance-value">₩ 369,000</span>
                  <div className="vendor-payment-note">※ 현장 상황 및 요청사항 변경 시 비용이 조정될 수 있습니다.</div>
                </div>
                <div className="vendor-sign-grid">
                  <b>견적 담당자</b><span>김선국　(서명) / H.P　010-9445-8224</span>
                  <b>고객 확인</b><span>김무브　(서명)</span>
                </div>
              </div>
            </div>
            <div className="quote-doc-footer">
              <Action className="outline quote-doc-action" label="PDF 다운로드" onClick={() => setShowVendorEstimate(false)}>
                PDF 다운로드
              </Action>
              <Action className="primary quote-doc-action" label="닫기" onClick={() => setShowVendorEstimate(false)}>
                확인
              </Action>
            </div>
          </div>
        </>
      )}
    </FormPage>
  )
}

function Reservation({ go }: { go: (screen: Screen) => void }) {
  return (
    <FormPage title="예약 일정 조회" onBack={() => go("home")}>
      <div className="signup-copy">
        예약하신 이사 일정을
        <br />
        빠르게 찾아드릴게요.
      </div>
      <Field label="이름" placeholder="이름을 입력해주세요." />
      <Field label="휴대폰 번호" placeholder="휴대폰 번호를 입력해주세요." />
      <Action
        className="primary form-submit"
        label="예약 조회"
        onClick={() => go("move")}
      >
        예약 조회
      </Action>
    </FormPage>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("onboarding")
  const [loggedIn, setLoggedIn] = useState(false)
  const [displayMode, setDisplayMode] = useState<"standard" | "easy">(
    () =>
      window.localStorage.getItem("display-mode") === "easy"
        ? "easy"
        : "standard",
  )
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [signupName, setSignupName] = useState("")
  const [signupPhone, setSignupPhone] = useState("")
  const [userName, setUserName] = useState("김무브")
  const [userPhone, setUserPhone] = useState("010-1234-5678")
  const [connectedSocials, setConnectedSocials] = useState<
    Record<SocialProvider, boolean>
  >({
    kakao: false,
    naver: false,
    apple: false,
  })
  const [estimateStatus, setEstimateStatus] =
    useState<EstimateStatus>("approved")
  const [moveTab, setMoveTab] = useState<MoveTab>("estimate")
  const [loginBackdrop, setLoginBackdrop] = useState<"onboarding" | "home">(
    "onboarding",
  )
  const [detailBackScreen, setDetailBackScreen] = useState<Screen>("home")
  const [reviewBackScreen, setReviewBackScreen] = useState<Screen>("profile")
  const [reservationBackScreen, setReservationBackScreen] =
    useState<Screen>("profile")
  const [quoteBackScreen, setQuoteBackScreen] = useState<Screen>("home")
  const [chatBackScreen, setChatBackScreen] = useState<Screen>("home")
  const [notificationBackScreen, setNotificationBackScreen] =
    useState<Screen>("home")
  const [estimateHistoryBackScreen, setEstimateHistoryBackScreen] =
    useState<Screen>("profile")
  const [estimateDetailBackScreen, setEstimateDetailBackScreen] =
    useState<Screen>("estimates")
  const [unreadNotifications, setUnreadNotifications] = useState(
    () => new Set([1, 4, 6]),
  )
  const [splash, setSplash] = useState(true)
  const [splashFontReady, setSplashFontReady] = useState(false)
  const [splashClosing, setSplashClosing] = useState(false)

  const loginTestAccount = (
    account: TestAccount,
    provider?: SocialProvider,
  ) => {
    setUserName(account === "kimCode" ? "김코드" : "김무브")
    setEstimateStatus(account === "kimCode" ? "confirmed" : "approved")
    setMoveTab(account === "kimCode" ? "booking" : "estimate")
    if (provider) {
      setConnectedSocials((current) => ({ ...current, [provider]: true }))
    }
    setLoggedIn(true)
  }

  const changeDisplayMode = (mode: "standard" | "easy") => {
    setDisplayMode(mode)
    window.localStorage.setItem("display-mode", mode)
  }

  useEffect(() => {
    let active = true
    const timers: number[] = []

    const showSplash = async () => {
      try {
        await Promise.race([
          document.fonts.load('700 26px "Gmarket Sans TTF:Bold"'),
          new Promise((resolve) => {
            timers.push(window.setTimeout(resolve, 450))
          }),
        ])
      } finally {
        if (!active) return
        setSplashFontReady(true)
        timers.push(
          window.setTimeout(() => {
            if (!active) return
            setSplashClosing(true)
            timers.push(
              window.setTimeout(() => {
                if (active) setSplash(false)
              }, 220),
            )
          }, 650),
        )
      }
    }

    showSplash()
    return () => {
      active = false
      timers.forEach((timer) => window.clearTimeout(timer))
    }
  }, [])

  const view = useMemo(() => {
    const go = (nextScreen: Screen) => {
      if (nextScreen !== screen && nextScreen === "detail") {
        setDetailBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "reviews") {
        setReviewBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "reservations" && screen !== "detail") {
        setReservationBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "quote") {
        setQuoteBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "chat") {
        setChatBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "notifications") {
        setNotificationBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "estimates") {
        setEstimateHistoryBackScreen(screen)
      }
      if (nextScreen !== screen && nextScreen === "estimate-detail") {
        setEstimateDetailBackScreen(screen)
      }
      if (nextScreen === "login") {
        if (screen === "home" || screen === "onboarding") {
          setLoginBackdrop(screen)
        }
        setScreen("login")
        return
      }
      if (!loggedIn && protectedScreens.has(nextScreen)) {
        setLoginBackdrop(screen === "home" ? "home" : "onboarding")
        setScreen("login")
        return
      }
      setScreen(nextScreen)
    }
    const confirmEstimate = () => {
      setEstimateStatus("confirmed")
    }
    switch (screen) {
      case "onboarding":
        return <Onboarding go={go} />
      case "home":
        return (
          <Home
            estimateStatus={estimateStatus}
            go={go}
            loggedIn={loggedIn}
            mode={displayMode}
            notificationCount={unreadNotifications.size}
            onModeChange={changeDisplayMode}
            userName={userName}
          />
        )
      case "login":
        return (
          <LoginSheet
            background={
              loginBackdrop === "home" ? (
                <Home
                  estimateStatus={estimateStatus}
                  go={go}
                  loggedIn={false}
                  mode={displayMode}
                  notificationCount={0}
                  onModeChange={changeDisplayMode}
                />
              ) : (
                <Onboarding go={go} />
              )
            }
            go={go}
            onDismiss={() => go(loginBackdrop)}
            onLogin={(account, provider) => {
              loginTestAccount(account, provider)
              go("home")
            }}
          />
        )
      case "phone-login":
        return (
          <PhoneLogin
            go={go}
            onLogin={(phone) => {
              setUserPhone(
                `${phone.slice(0, 3)}-${phone.slice(3, 7)}-${phone.slice(7)}`,
              )
              loginTestAccount(
                phone === "01056781234" ? "kimCode" : "kimMove",
              )
              go("home")
            }}
          />
        )
      case "signup":
        return (
          <Signup
            go={go}
            name={signupName}
            onNameChange={setSignupName}
            onPhoneChange={setSignupPhone}
            phone={signupPhone}
            termsAccepted={termsAccepted}
          />
        )
      case "terms":
        return (
          <Terms
            go={go}
            onAccept={() => {
              setTermsAccepted(true)
              go("signup")
            }}
          />
        )
      case "verify":
        return <Verify go={go} name={signupName} />
      case "welcome":
        return (
          <Welcome
            name={signupName || userName}
            onStart={() => {
              if (signupName) setUserName(signupName)
              if (signupPhone) setUserPhone(signupPhone)
              setEstimateStatus("none")
              setMoveTab("estimate")
              setUnreadNotifications(new Set())
              setLoggedIn(true)
              go("home")
            }}
          />
        )
      case "move":
        return (
          <Move
            estimateStatus={estimateStatus}
            go={go}
            mode={displayMode}
            notificationCount={unreadNotifications.size}
            onConfirmEstimate={confirmEstimate}
            onModeChange={changeDisplayMode}
            onTabChange={setMoveTab}
            tab={moveTab}
          />
        )
      case "quote":
        return (
          <Quote
            go={go}
            mode={displayMode}
            onBack={() => setScreen(quoteBackScreen)}
            onRequestComplete={() => {
              setEstimateStatus("waiting-approval")
              setMoveTab("estimate")
              go("quote-success")
            }}
          />
        )
      case "quote-success":
        return <QuoteSuccess go={go} mode={displayMode} />
      case "chat":
        return (
          <Chat
            estimateStatus={estimateStatus}
            go={go}
            onBack={() => setScreen(chatBackScreen)}
            userName={userName}
          />
        )
      case "profile":
        return (
          <Profile
            go={go}
            mode={displayMode}
            notificationCount={unreadNotifications.size}
            onModeChange={changeDisplayMode}
            phone={userPhone}
            userName={userName}
            logout={() => {
              setLoggedIn(false)
              go("onboarding")
            }}
          />
        )
      case "personal":
        return (
          <PersonalInfo
            go={go}
            onPhoneChange={setUserPhone}
            phone={userPhone}
            userName={userName}
          />
        )
      case "estimates":
        return (
          <EstimateHistory
            estimateStatus={estimateStatus}
            go={go}
            onBack={() => setScreen(estimateHistoryBackScreen)}
          />
        )
      case "reservations":
        return (
          <ReservationHistory
            backTo={reservationBackScreen}
            go={go}
            hasUpcomingReservation={estimateStatus === "confirmed"}
          />
        )
      case "reviews":
        return <ReviewHistory backTo={reviewBackScreen} go={go} />
      case "notifications":
        return (
          <Notifications
            go={go}
            onBack={() => setScreen(notificationBackScreen)}
            setUnread={setUnreadNotifications}
            unread={unreadNotifications}
          />
        )
      case "detail":
        return (
          <Detail
            backTo={detailBackScreen}
            go={go}
            onCancelReservation={() => {
              setEstimateStatus("approved")
              setMoveTab("estimate")
              go("home")
            }}
          />
        )
      case "estimate-detail":
        return (
          <EstimateDetail
            estimateStatus={estimateStatus}
            go={go}
            onBack={() => setScreen(estimateDetailBackScreen)}
            onConfirmEstimate={confirmEstimate}
          />
        )
      case "reservation":
        return <Reservation go={go} />
    }
  }, [
    loggedIn,
    estimateStatus,
    connectedSocials,
    detailBackScreen,
    chatBackScreen,
    estimateDetailBackScreen,
    estimateHistoryBackScreen,
    reviewBackScreen,
    reservationBackScreen,
    quoteBackScreen,
    displayMode,
    loginBackdrop,
    moveTab,
    notificationBackScreen,
    screen,
    signupName,
    signupPhone,
    termsAccepted,
    unreadNotifications,
    userName,
    userPhone,
  ])

  return (
    <div className={displayMode === "easy" ? "app-shell easy-mode" : "app-shell"}>
      {view}
      {splash && (
        <div className={splashClosing ? "splash splash-closing" : "splash"}>
          <BrandMark className="splash-brand-mark" />
          <div
            className={
              splashFontReady ? "splash-title font-ready" : "splash-title"
            }
          >
            명품익스프레스
          </div>
        </div>
      )}
    </div>
  )
}
